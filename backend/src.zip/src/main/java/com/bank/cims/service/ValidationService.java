package com.bank.cims.service;

import com.bank.cims.model.ApprovedInsurer;
import com.bank.cims.model.InsurancePolicy;
import com.bank.cims.repository.ApprovedInsurerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class ValidationService {

    @Autowired
    private ApprovedInsurerRepository approvedInsurerRepository;

    public void validatePolicy(InsurancePolicy policy) {
        if (policy.getInsuredAmount() <= 0) {
            throw new IllegalArgumentException("Insured amount must be strictly greater than 0 ETB.");
        }
        if (policy.getPremium() <= 0) {
            throw new IllegalArgumentException("Policy premium must be strictly greater than 0 ETB.");
        }
        if (policy.getEffectiveDate() == null || policy.getExpiryDate() == null) {
            throw new IllegalArgumentException("Effective date and expiry date are mandatory.");
        }

        LocalDate eff = LocalDate.parse(policy.getEffectiveDate());
        LocalDate exp = LocalDate.parse(policy.getExpiryDate());

        if (exp.isBefore(eff) || exp.isEqual(eff)) {
            throw new IllegalArgumentException("Policy expiry date must be strictly after the effective date.");
        }

        // Validate Insurer Whitelist
        if (policy.getInsurerName() != null && !policy.getInsurerName().isBlank()) {
            boolean approved = approvedInsurerRepository.findByNameIgnoreCase(policy.getInsurerName())
                    .map(ApprovedInsurer::isActive)
                    .orElse(true);
            if (!approved) {
                throw new IllegalArgumentException("Selected insurer '" + policy.getInsurerName() + "' is not on the bank's approved active insurer list.");
            }
        }
    }
}
