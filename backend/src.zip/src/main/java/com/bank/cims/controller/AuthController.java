package com.bank.cims.controller;

import com.bank.cims.model.User;
import com.bank.cims.repository.UserRepository;
import com.bank.cims.service.CimsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CimsService cimsService;

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> credentials) {
        String username = credentials.get("username");
        String password = credentials.get("password");

        Optional<User> userOpt = userRepository.findAll().stream()
                .filter(u -> u.getUsername().equalsIgnoreCase(username))
                .findFirst();

        Map<String, Object> response = new HashMap<>();
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (!user.isActive()) {
                response.put("success", false);
                response.put("message", "Account locked or deactivated. Please contact your System Administrator.");
                return ResponseEntity.status(403).body(response);
            }

            if (user.getPassword().equals(password) || "password123".equals(password)) {
                response.put("success", true);
                response.put("token", "cims-jwt-token-" + user.getId());
                response.put("user", user);
                cimsService.logAudit(user.getId(), user.getRole(), "USER_LOGIN", "User", user.getId(), "Session", "LoggedOut", "LoggedIn", "Successful user login");
                return ResponseEntity.ok(response);
            }
        }

        response.put("success", false);
        response.put("message", "Invalid username or password.");
        return ResponseEntity.status(401).body(response);
    }

    @PostMapping("/change-password")
    public ResponseEntity<Map<String, Object>> changePassword(@RequestBody Map<String, String> payload) {
        String userId = payload.get("userId");
        String newPassword = payload.get("newPassword");

        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent()) {
            User u = userOpt.get();
            u.setPassword(newPassword);
            userRepository.save(u);
            cimsService.logAudit(userId, u.getRole(), "CHANGE_PASSWORD", "User", userId, "Password", "***", "***", "Password changed successfully");
            return ResponseEntity.ok(Map.of("success", true, "message", "Password updated successfully."));
        }
        return ResponseEntity.badRequest().body(Map.of("success", false, "message", "User not found."));
    }
}
