package com.bank.cims.repository;

import com.bank.cims.model.LoanAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LoanAccountRepository extends JpaRepository<LoanAccount, String> {
    List<LoanAccount> findByCustomerId(String customerId);
}
