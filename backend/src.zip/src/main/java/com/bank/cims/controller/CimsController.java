package com.bank.cims.controller;

import com.bank.cims.model.*;
import com.bank.cims.repository.*;
import com.bank.cims.service.CimsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class CimsController {

    @Autowired
    private CimsService cimsService;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OwnershipTransferRepository ownershipTransferRepository;

    @Autowired
    private CollateralRepository collateralRepository;

    @GetMapping("/state")
    public ResponseEntity<Map<String, Object>> getState() {
        return ResponseEntity.ok(cimsService.getFullState());
    }

    // --- Business Segments ---
    @PostMapping("/segments/add")
    public ResponseEntity<Map<String, Object>> addSegment(
            @RequestBody BusinessSegment segment,
            @RequestParam(defaultValue = "SYSADMIN") String userId) {
        cimsService.addBusinessSegment(segment, userId);
        return ResponseEntity.ok(cimsService.getFullState());
    }

    @PostMapping("/segments/toggle-status")
    public ResponseEntity<Map<String, Object>> toggleSegmentStatus(
            @RequestParam String segmentId,
            @RequestParam boolean active,
            @RequestParam(defaultValue = "SYSADMIN") String userId) {
        cimsService.toggleSegmentActiveStatus(segmentId, active, userId);
        return ResponseEntity.ok(cimsService.getFullState());
    }

    // --- Ownership Transfers ---
    @PostMapping("/transfers/initiate")
    public ResponseEntity<Map<String, Object>> initiateTransfer(
            @RequestParam String collateralId,
            @RequestParam String destinationSegment,
            @RequestParam String reason,
            @RequestParam String userId) {
        Optional<Collateral> colOpt = collateralRepository.findById(collateralId);
        if (colOpt.isPresent()) {
            Collateral col = colOpt.get();
            OwnershipTransfer transfer = new OwnershipTransfer(
                "trf-" + System.currentTimeMillis(),
                collateralId,
                col.getOwningSegment(),
                destinationSegment,
                reason,
                userId,
                java.time.LocalDate.now().toString(),
                "Pending",
                "Initiated by " + userId
            );
            ownershipTransferRepository.save(transfer);
            cimsService.logAudit(userId, "CRO", "INITIATE_OWNERSHIP_TRANSFER", "Collateral", collateralId, "Segment", col.getOwningSegment(), destinationSegment, reason);
        }
        return ResponseEntity.ok(cimsService.getFullState());
    }

    @PostMapping("/transfers/approve")
    public ResponseEntity<Map<String, Object>> approveTransfer(
            @RequestParam String transferId,
            @RequestParam String userId) {
        ownershipTransferRepository.findById(transferId).ifPresent(trf -> {
            trf.setStatus("Approved");
            trf.setApprovedBy(userId);
            trf.setApprovedAt(java.time.LocalDate.now().toString());
            ownershipTransferRepository.save(trf);

            collateralRepository.findById(trf.getCollateralId()).ifPresent(col -> {
                String oldSeg = col.getOwningSegment();
                col.setOwningSegment(trf.getDestinationSegment());
                collateralRepository.save(col);
                cimsService.logAudit(userId, "HODEPT", "APPROVE_OWNERSHIP_TRANSFER", "Collateral", col.getId(), "Segment", oldSeg, trf.getDestinationSegment(), "Approved segment transfer");
            });
        });
        return ResponseEntity.ok(cimsService.getFullState());
    }

    @PostMapping("/transfers/reject")
    public ResponseEntity<Map<String, Object>> rejectTransfer(
            @RequestParam String transferId,
            @RequestParam String remarks,
            @RequestParam String userId) {
        ownershipTransferRepository.findById(transferId).ifPresent(trf -> {
            trf.setStatus("Rejected");
            trf.setApprovedBy(userId);
            trf.setApprovedAt(java.time.LocalDate.now().toString());
            trf.setRemarks(remarks);
            ownershipTransferRepository.save(trf);
            cimsService.logAudit(userId, "HODEPT", "REJECT_OWNERSHIP_TRANSFER", "OwnershipTransfer", transferId, "Status", "Pending", "Rejected", remarks);
        });
        return ResponseEntity.ok(cimsService.getFullState());
    }

    // --- Customers ---
    @PostMapping("/customers/register-manual")
    public ResponseEntity<Map<String, Object>> registerManualCustomer(
            @RequestBody Customer customer,
            @RequestParam String userId) {
        if (customer.getId() == null || customer.getId().isBlank()) {
            customer.setId("cust-" + System.currentTimeMillis());
        }
        customer.setSource("Manual");
        customer.setRecordStat("U");
        customer.setAuthStat("U");
        customer.setMakerId(userId);
        customerRepository.save(customer);

        cimsService.submitToWorkflow("PROC_CUSTOMER_REGISTRATION", "Customer", customer.getId(), "Register Customer Manually", "{}", "Manual customer registration", userId, "BRMGR");
        return ResponseEntity.ok(cimsService.getFullState());
    }

    // --- Collateral ---
    @GetMapping("/collateral/validate-release")
    public ResponseEntity<Map<String, Object>> validateRelease(@RequestParam String collateralId) {
        return ResponseEntity.ok(cimsService.validateCollateralRelease(collateralId));
    }

    @PostMapping("/collateral/register-native")
    public ResponseEntity<Map<String, Object>> registerNativeCollateral(
            @RequestBody Collateral collateral,
            @RequestParam String userId) {
        cimsService.registerNativeCollateral(collateral, userId);
        return ResponseEntity.ok(cimsService.getFullState());
    }

    // --- Junction Links ---
    @PostMapping("/links/add")
    public ResponseEntity<Map<String, Object>> addLink(
            @RequestParam String loanId,
            @RequestParam String collateralId,
            @RequestParam double amount,
            @RequestParam String userId) {
        cimsService.addLink(loanId, collateralId, amount, userId);
        return ResponseEntity.ok(cimsService.getFullState());
    }

    @PostMapping("/links/remove")
    public ResponseEntity<Map<String, Object>> removeLink(
            @RequestParam String linkId,
            @RequestParam String userId) {
        cimsService.removeLink(linkId, userId);
        return ResponseEntity.ok(cimsService.getFullState());
    }

    // --- Policy Operations ---
    @PostMapping("/policies/add")
    public ResponseEntity<Map<String, Object>> addPolicy(
            @RequestBody InsurancePolicy policy,
            @RequestParam String userId) {
        cimsService.addPolicy(policy, userId);
        return ResponseEntity.ok(cimsService.getFullState());
    }

    @PostMapping("/policies/submit")
    public ResponseEntity<Map<String, Object>> submitPolicy(
            @RequestParam String policyId,
            @RequestParam String userId) {
        cimsService.submitPolicyForApproval(policyId, userId);
        return ResponseEntity.ok(cimsService.getFullState());
    }

    @PostMapping("/policies/approve")
    public ResponseEntity<Map<String, Object>> approvePolicy(
            @RequestParam String policyId,
            @RequestParam String userId) {
        cimsService.approvePolicy(policyId, userId);
        return ResponseEntity.ok(cimsService.getFullState());
    }

    @PostMapping("/policies/reject")
    public ResponseEntity<Map<String, Object>> rejectPolicy(
            @RequestParam String policyId,
            @RequestParam String comments,
            @RequestParam String userId) {
        cimsService.rejectPolicy(policyId, comments, userId);
        return ResponseEntity.ok(cimsService.getFullState());
    }

    @PostMapping("/policies/amend")
    public ResponseEntity<Map<String, Object>> amendPolicy(
            @RequestParam String policyId,
            @RequestBody InsurancePolicy policy,
            @RequestParam String userId) {
        cimsService.amendPolicy(policyId, policy, userId);
        return ResponseEntity.ok(cimsService.getFullState());
    }

    @PostMapping("/policies/renew")
    public ResponseEntity<Map<String, Object>> renewPolicy(
            @RequestParam String policyId,
            @RequestParam(defaultValue = "0") double newAmount,
            @RequestParam(defaultValue = "0") double newPremium,
            @RequestParam String newExpiryDate,
            @RequestParam String userId) {
        cimsService.renewPolicy(policyId, newAmount, newPremium, newExpiryDate, userId);
        return ResponseEntity.ok(cimsService.getFullState());
    }



    // --- Cron / Scanning ---
    @PostMapping("/cron/run")
    public ResponseEntity<Map<String, Object>> runCron(
            @RequestParam int days,
            @RequestParam String userId) {
        cimsService.scanAndGenerateExceptions();
        return ResponseEntity.ok(Map.of("success", true, "message", "Cron executed for day offset " + days));
    }
}
