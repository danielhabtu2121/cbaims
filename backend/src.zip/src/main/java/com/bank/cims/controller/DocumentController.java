package com.bank.cims.controller;

import com.bank.cims.model.OwnershipDocument;
import com.bank.cims.repository.OwnershipDocumentRepository;
import com.bank.cims.service.CimsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/documents")
@CrossOrigin(origins = "*")
public class DocumentController {

    @Autowired
    private OwnershipDocumentRepository ownershipDocumentRepository;

    @Autowired
    private CimsService cimsService;

    @GetMapping
    public ResponseEntity<List<OwnershipDocument>> getDocuments(
            @RequestParam(required = false) String entityType,
            @RequestParam(required = false) String entityId) {
        if (entityType != null && entityId != null) {
            return ResponseEntity.ok(ownershipDocumentRepository.findByEntityTypeAndEntityId(entityType, entityId));
        }
        return ResponseEntity.ok(ownershipDocumentRepository.findAll());
    }

    @PostMapping("/upload")
    public ResponseEntity<OwnershipDocument> uploadDocument(
            @RequestParam String entityType,
            @RequestParam String entityId,
            @RequestParam String docName,
            @RequestParam String docType,
            @RequestParam(defaultValue = "MGRCOLLDOC") String uploadedBy,
            @RequestParam(required = false) String expiryDate) {
        OwnershipDocument doc = cimsService.uploadDocument(entityType, entityId, docName, docType, uploadedBy, expiryDate);
        return ResponseEntity.ok(doc);
    }

    @PostMapping("/{id}/archive")
    public ResponseEntity<Map<String, Object>> archiveDocument(
            @PathVariable String id,
            @RequestParam String userId) {
        ownershipDocumentRepository.findById(id).ifPresent(d -> {
            d.setStatus("Archived");
            ownershipDocumentRepository.save(d);
            cimsService.logAudit(userId, "MGRCOLLDOC", "ARCHIVE_DOCUMENT", "Document", id, "Status", "Active", "Archived", "Archived document " + d.getName());
        });
        return ResponseEntity.ok(Map.of("success", true, "message", "Document archived."));
    }
}
