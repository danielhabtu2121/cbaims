package com.bank.cims.controller;

import com.bank.cims.model.*;
import com.bank.cims.repository.*;
import com.bank.cims.service.CimsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminConfigController {

    @Autowired
    private BusinessSegmentRepository businessSegmentRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RolePermissionRepository rolePermissionRepository;

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private ApprovalHierarchyConfigRepository approvalHierarchyConfigRepository;

    @Autowired
    private ReminderScheduleRepository reminderScheduleRepository;

    @Autowired
    private ScheduledReportRepository scheduledReportRepository;

    @Autowired
    private ApprovedInsurerRepository approvedInsurerRepository;

    @Autowired
    private CollateralTaxonomyRepository collateralTaxonomyRepository;

    @Autowired
    private MandatoryDocumentRuleRepository mandatoryDocumentRuleRepository;

    @Autowired
    private EscalationRuleRepository escalationRuleRepository;

    @Autowired
    private NotificationTemplateRepository notificationTemplateRepository;

    @Autowired
    private DistrictHierarchyRepository districtHierarchyRepository;

    @Autowired
    private HolidayCalendarRepository holidayCalendarRepository;

    @Autowired
    private SystemParameterRepository systemParameterRepository;

    @Autowired
    private CimsService cimsService;

    // --- Business Segments ---
    @GetMapping("/segments")
    public List<BusinessSegment> getSegments() {
        return businessSegmentRepository.findAll();
    }

    @PostMapping("/segments/save")
    public ResponseEntity<BusinessSegment> saveSegment(@RequestBody BusinessSegment segment, @RequestParam(defaultValue = "SYSADMIN") String adminUserId) {
        if (segment.getId() == null || segment.getId().isBlank()) {
            segment.setId("seg-" + UUID.randomUUID().toString().substring(0, 8));
        }
        BusinessSegment saved = businessSegmentRepository.save(segment);
        cimsService.logAudit(adminUserId, "SYSADMIN", "SAVE_BUSINESS_SEGMENT", "BusinessSegment", saved.getId(), "Segment", "Old", saved.getName(), "Saved segment " + saved.getName());
        return ResponseEntity.ok(saved);
    }

    @PostMapping("/segments/{id}/toggle-status")
    public ResponseEntity<Map<String, Object>> toggleSegmentStatus(@PathVariable String id, @RequestParam boolean active, @RequestParam(defaultValue = "SYSADMIN") String adminUserId) {
        businessSegmentRepository.findById(id).ifPresent(s -> {
            s.setActive(active);
            businessSegmentRepository.save(s);
            cimsService.logAudit(adminUserId, "SYSADMIN", "TOGGLE_SEGMENT_STATUS", "BusinessSegment", id, "Active", String.valueOf(!active), String.valueOf(active), "Toggled business segment active status");
        });
        return ResponseEntity.ok(Map.of("success", true));
    }

    // --- Users ---
    @GetMapping("/users")
    public List<User> getUsers() {
        return userRepository.findAll();
    }

    @PostMapping("/users/save")
    public ResponseEntity<User> saveUser(@RequestBody User user, @RequestParam(defaultValue = "SYSADMIN") String adminUserId) {
        if (user.getId() == null || user.getId().isBlank()) {
            user.setId("usr-" + UUID.randomUUID().toString().substring(0, 8));
        }
        User saved = userRepository.save(user);
        cimsService.logAudit(adminUserId, "SYSADMIN", "SAVE_USER", "User", saved.getId(), "All", "Old", saved.getUsername(), "Saved user " + saved.getUsername());
        return ResponseEntity.ok(saved);
    }

    @PostMapping("/users/{id}/toggle-status")
    public ResponseEntity<Map<String, Object>> toggleUserStatus(@PathVariable String id, @RequestParam boolean active, @RequestParam(defaultValue = "SYSADMIN") String adminUserId) {
        userRepository.findById(id).ifPresent(u -> {
            u.setActive(active);
            userRepository.save(u);
            cimsService.logAudit(adminUserId, "SYSADMIN", "TOGGLE_USER_STATUS", "User", id, "Active", String.valueOf(!active), String.valueOf(active), "Toggled user active status");
        });
        return ResponseEntity.ok(Map.of("success", true));
    }

    // --- Role Permissions ---
    @GetMapping("/permissions")
    public List<RolePermission> getPermissions() {
        return rolePermissionRepository.findAll();
    }

    @PostMapping("/permissions/save")
    public ResponseEntity<RolePermission> savePermission(@RequestBody RolePermission permission, @RequestParam(defaultValue = "SYSADMIN") String adminUserId) {
        if (permission.getId() == null || permission.getId().isBlank()) {
            permission.setId("perm-" + UUID.randomUUID().toString().substring(0, 8));
        }
        RolePermission saved = rolePermissionRepository.save(permission);
        cimsService.logAudit(adminUserId, "SYSADMIN", "SAVE_ROLE_PERMISSION", "RolePermission", saved.getId(), "Permission", "Old", saved.getRoleCode() + ":" + saved.getScreenName(), "Updated role permission");
        return ResponseEntity.ok(saved);
    }

    @PostMapping("/permissions/save-batch")
    public ResponseEntity<List<RolePermission>> savePermissionsBatch(@RequestBody List<RolePermission> permissions, @RequestParam(defaultValue = "SYSADMIN") String adminUserId) {
        for (RolePermission p : permissions) {
            if (p.getId() == null || p.getId().isBlank()) {
                p.setId("perm-" + UUID.randomUUID().toString().substring(0, 8));
            }
        }
        List<RolePermission> saved = rolePermissionRepository.saveAll(permissions);
        cimsService.logAudit(adminUserId, "SYSADMIN", "SAVE_ROLE_PERMISSIONS_BATCH", "RolePermission", "BATCH", "Permissions", "Old", "Count: " + saved.size(), "Batch updated " + saved.size() + " role permissions");
        return ResponseEntity.ok(saved);
    }

    // --- Branches Hierarchy ---
    @GetMapping("/branches")
    public List<Branch> getBranches() {
        return branchRepository.findAll();
    }

    @PostMapping("/branches/save")
    public ResponseEntity<Branch> saveBranch(@RequestBody Branch branch, @RequestParam(defaultValue = "SYSADMIN") String adminUserId) {
        if (branch.getId() == null || branch.getId().isBlank()) {
            branch.setId("brn-" + UUID.randomUUID().toString().substring(0, 8));
        }
        Branch saved = branchRepository.save(branch);
        cimsService.logAudit(adminUserId, "SYSADMIN", "SAVE_BRANCH", "Branch", saved.getId(), "Branch", "Old", saved.getCode(), "Saved branch " + saved.getName());
        return ResponseEntity.ok(saved);
    }

    // --- Approval Hierarchies ---
    @GetMapping("/approval-configs")
    public List<ApprovalHierarchyConfig> getApprovalConfigs() {
        return approvalHierarchyConfigRepository.findAll();
    }

    @PostMapping("/approval-configs/save")
    public ResponseEntity<ApprovalHierarchyConfig> saveApprovalConfig(@RequestBody ApprovalHierarchyConfig config, @RequestParam(defaultValue = "SYSADMIN") String adminUserId) {
        if (config.getId() == null || config.getId().isBlank()) {
            config.setId("ah-" + UUID.randomUUID().toString().substring(0, 8));
        }
        ApprovalHierarchyConfig saved = approvalHierarchyConfigRepository.save(config);
        cimsService.logAudit(adminUserId, "SYSADMIN", "SAVE_APPROVAL_CONFIG", "ApprovalConfig", saved.getId(), "Config", "Old", saved.getTransactionType(), "Saved approval hierarchy config");
        return ResponseEntity.ok(saved);
    }

    // --- Reminder Schedules ---
    @GetMapping("/reminder-schedules")
    public List<ReminderSchedule> getReminderSchedules() {
        return reminderScheduleRepository.findAllByOrderByDaysBeforeExpiryDesc();
    }

    @PostMapping("/reminder-schedules/save")
    public ResponseEntity<ReminderSchedule> saveReminderSchedule(@RequestBody ReminderSchedule schedule, @RequestParam(defaultValue = "SYSADMIN") String adminUserId) {
        if (schedule.getId() == null || schedule.getId().isBlank()) {
            schedule.setId("rem-" + schedule.getDaysBeforeExpiry());
        }
        ReminderSchedule saved = reminderScheduleRepository.save(schedule);
        cimsService.logAudit(adminUserId, "SYSADMIN", "SAVE_REMINDER_SCHEDULE", "ReminderSchedule", saved.getId(), "Days", "Old", String.valueOf(saved.getDaysBeforeExpiry()), "Saved reminder schedule");
        return ResponseEntity.ok(saved);
    }

    // --- Scheduled Reports ---
    @GetMapping("/scheduled-reports")
    public List<ScheduledReport> getScheduledReports() {
        return scheduledReportRepository.findAll();
    }

    @PostMapping("/scheduled-reports/save")
    public ResponseEntity<ScheduledReport> saveScheduledReport(@RequestBody ScheduledReport report, @RequestParam(defaultValue = "SYSADMIN") String adminUserId) {
        if (report.getId() == null || report.getId().isBlank()) {
            report.setId("rep-sched-" + UUID.randomUUID().toString().substring(0, 8));
        }
        ScheduledReport saved = scheduledReportRepository.save(report);
        cimsService.logAudit(adminUserId, "SYSADMIN", "SAVE_SCHEDULED_REPORT", "ScheduledReport", saved.getId(), "Report", "Old", saved.getReportType(), "Scheduled report " + saved.getReportType());
        return ResponseEntity.ok(saved);
    }

    // --- Reference Data ---
    @GetMapping("/insurers")
    public List<ApprovedInsurer> getInsurers() {
        return approvedInsurerRepository.findAll();
    }

    @PostMapping("/insurers/save")
    public ResponseEntity<ApprovedInsurer> saveInsurer(@RequestBody ApprovedInsurer insurer, @RequestParam(defaultValue = "SYSADMIN") String userId) {
        if (insurer.getId() == null || insurer.getId().isBlank()) {
            insurer.setId("ins-" + System.currentTimeMillis());
        }
        ApprovedInsurer saved = approvedInsurerRepository.save(insurer);
        cimsService.logAudit(userId, "SYSADMIN", "ADMIN_SAVE_INSURER", "ApprovedInsurer", saved.getId(), "Name", "Old", saved.getName(), "Saved insurer");
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/taxonomy")
    public List<CollateralTaxonomy> getTaxonomies() {
        return collateralTaxonomyRepository.findAll();
    }

    @PostMapping("/taxonomy/save")
    public ResponseEntity<CollateralTaxonomy> saveTaxonomy(@RequestBody CollateralTaxonomy taxonomy, @RequestParam(defaultValue = "SYSADMIN") String userId) {
        if (taxonomy.getId() == null || taxonomy.getId().isBlank()) {
            taxonomy.setId("tax-" + System.currentTimeMillis());
        }
        CollateralTaxonomy saved = collateralTaxonomyRepository.save(taxonomy);
        cimsService.logAudit(userId, "SYSADMIN", "ADMIN_SAVE_TAXONOMY", "CollateralTaxonomy", saved.getId(), "Taxonomy", "Old", saved.getCategory(), "Saved taxonomy");
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/document-rules")
    public List<MandatoryDocumentRule> getDocumentRules() {
        return mandatoryDocumentRuleRepository.findAll();
    }

    @PostMapping("/document-rules/save")
    public ResponseEntity<MandatoryDocumentRule> saveDocumentRule(@RequestBody MandatoryDocumentRule rule, @RequestParam(defaultValue = "SYSADMIN") String userId) {
        if (rule.getId() == null || rule.getId().isBlank()) {
            rule.setId("doc-r" + System.currentTimeMillis());
        }
        MandatoryDocumentRule saved = mandatoryDocumentRuleRepository.save(rule);
        cimsService.logAudit(userId, "SYSADMIN", "ADMIN_SAVE_DOCUMENT_RULE", "MandatoryDocumentRule", saved.getId(), "Rule", "Old", saved.getCollateralCategory(), "Saved mandatory doc rule");
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/escalation-rules")
    public List<EscalationRule> getEscalationRules() {
        return escalationRuleRepository.findAll();
    }

    @PostMapping("/escalation-rules/save")
    public ResponseEntity<EscalationRule> saveEscalationRule(@RequestBody EscalationRule rule, @RequestParam(defaultValue = "SYSADMIN") String userId) {
        if (rule.getId() == null || rule.getId().isBlank()) {
            rule.setId("esc-" + System.currentTimeMillis());
        }
        EscalationRule saved = escalationRuleRepository.save(rule);
        cimsService.logAudit(userId, "SYSADMIN", "ADMIN_SAVE_ESCALATION_RULE", "EscalationRule", saved.getId(), "Rule", "Old", saved.getEscalationRole(), "Saved escalation rule");
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/templates")
    public List<NotificationTemplate> getTemplates() {
        return notificationTemplateRepository.findAll();
    }

    @PostMapping("/templates/save")
    public ResponseEntity<NotificationTemplate> saveTemplate(@RequestBody NotificationTemplate template, @RequestParam(defaultValue = "SYSADMIN") String userId) {
        if (template.getId() == null || template.getId().isBlank()) {
            template.setId("tmpl-" + System.currentTimeMillis());
        }
        NotificationTemplate saved = notificationTemplateRepository.save(template);
        cimsService.logAudit(userId, "SYSADMIN", "ADMIN_SAVE_TEMPLATE", "NotificationTemplate", saved.getId(), "Template", "Old", saved.getName(), "Saved template");
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/districts")
    public List<DistrictHierarchy> getDistricts() {
        return districtHierarchyRepository.findAll();
    }

    @PostMapping("/districts/save")
    public ResponseEntity<DistrictHierarchy> saveDistrict(@RequestBody DistrictHierarchy district, @RequestParam(defaultValue = "SYSADMIN") String userId) {
        if (district.getId() == null || district.getId().isBlank()) {
            district.setId("dist-" + System.currentTimeMillis());
        }
        DistrictHierarchy saved = districtHierarchyRepository.save(district);
        cimsService.logAudit(userId, "SYSADMIN", "ADMIN_SAVE_DISTRICT", "DistrictHierarchy", saved.getId(), "District", "Old", saved.getDistrictName(), "Saved district");
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/holidays")
    public List<HolidayCalendar> getHolidays() {
        return holidayCalendarRepository.findAll();
    }

    @PostMapping("/holidays/save")
    public ResponseEntity<HolidayCalendar> saveHoliday(@RequestBody HolidayCalendar holiday, @RequestParam(defaultValue = "SYSADMIN") String userId) {
        if (holiday.getId() == null || holiday.getId().isBlank()) {
            holiday.setId("hol-" + System.currentTimeMillis());
        }
        HolidayCalendar saved = holidayCalendarRepository.save(holiday);
        cimsService.logAudit(userId, "SYSADMIN", "ADMIN_SAVE_HOLIDAY", "HolidayCalendar", saved.getId(), "Holiday", "Old", saved.getDescription(), "Saved holiday");
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/parameters")
    public List<SystemParameter> getParameters() {
        return systemParameterRepository.findAll();
    }

    @PostMapping("/parameters/save")
    public ResponseEntity<SystemParameter> saveParameter(@RequestBody SystemParameter param, @RequestParam(defaultValue = "SYSADMIN") String userId) {
        SystemParameter saved = systemParameterRepository.save(param);
        cimsService.logAudit(userId, "SYSADMIN", "ADMIN_SAVE_SYSTEM_PARAMETER", "SystemParameter", saved.getParamKey(), "Parameter", "Old", saved.getParamValue(), "Saved system parameter");
        return ResponseEntity.ok(saved);
    }
}
