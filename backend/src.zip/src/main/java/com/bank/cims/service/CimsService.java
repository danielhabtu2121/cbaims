package com.bank.cims.service;

import com.bank.cims.model.*;
import com.bank.cims.repository.*;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.task.api.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Service
@Transactional
public class CimsService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private LoanAccountRepository loanAccountRepository;

    @Autowired
    private CollateralRepository collateralRepository;

    @Autowired
    private LoanCollateralLinkRepository loanCollateralLinkRepository;

    @Autowired
    private InsurancePolicyRepository insurancePolicyRepository;

    @Autowired
    private PolicyEndorsementRepository policyEndorsementRepository;

    @Autowired
    private ExceptionRequestRepository exceptionRequestRepository;

    @Autowired
    private CimsExceptionRepository cimsExceptionRepository;

    @Autowired
    private AuditLogRepository auditLogRepository;

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private NotificationTemplateRepository notificationTemplateRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RolePermissionRepository rolePermissionRepository;

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private BusinessSegmentRepository businessSegmentRepository;

    @Autowired
    private OwnershipTransferRepository ownershipTransferRepository;

    @Autowired
    private WorkflowTaskRepository workflowTaskRepository;

    @Autowired
    private ApprovalHistoryRepository approvalHistoryRepository;

    @Autowired
    private DelegationRepository delegationRepository;

    @Autowired
    private ApprovalHierarchyConfigRepository approvalHierarchyConfigRepository;

    @Autowired
    private ReminderScheduleRepository reminderScheduleRepository;

    @Autowired
    private ScheduledReportRepository scheduledReportRepository;

    @Autowired
    private OwnershipDocumentRepository ownershipDocumentRepository;

    @Autowired
    private ApprovedInsurerRepository approvedInsurerRepository;

    @Autowired
    private CollateralTaxonomyRepository collateralTaxonomyRepository;

    @Autowired
    private MandatoryDocumentRuleRepository mandatoryDocumentRuleRepository;

    @Autowired
    private HolidayCalendarRepository holidayCalendarRepository;

    @Autowired
    private SystemParameterRepository systemParameterRepository;

    @Autowired
    private CbsCustomerRepository cbsCustomerRepository;

    @Autowired
    private CbsFacilityRepository cbsFacilityRepository;

    @Autowired
    private CbsCollateralRepository cbsCollateralRepository;

    @Autowired
    private CbsSyncLogRepository cbsSyncLogRepository;

    @Autowired
    private CbsSyncService cbsSyncService;

    @Autowired(required = false)
    private FlowableWorkflowService flowableWorkflowService;

    @Autowired
    private ValidationService validationService;

    private String simulatedSystemDate = "2026-08-18";

    public Map<String, Object> getFullState() {
        Map<String, Object> state = new HashMap<>();
        state.put("customers", customerRepository.findAll());
        state.put("facilities", loanAccountRepository.findAll());
        state.put("loans", loanAccountRepository.findAll());
        state.put("collaterals", collateralRepository.findAll());
        state.put("links", loanCollateralLinkRepository.findAll());
        state.put("policies", insurancePolicyRepository.findAll());
        state.put("endorsements", policyEndorsementRepository.findAll());
        state.put("documents", ownershipDocumentRepository.findAll());
        state.put("templates", notificationTemplateRepository.findAll());
        state.put("notifications", notificationRepository.findAllByOrderBySentAtDesc());
        state.put("auditLogs", auditLogRepository.findAll());
        state.put("exceptions", cimsExceptionRepository.findAll());
        state.put("segments", businessSegmentRepository.findAll());
        state.put("branches", branchRepository.findAll());
        state.put("users", userRepository.findAll());
        state.put("rolePermissions", rolePermissionRepository.findAll());
        state.put("workflowTasks", workflowTaskRepository.findAll());
        state.put("approvalHistories", approvalHistoryRepository.findAll());
        state.put("delegations", delegationRepository.findAll());
        state.put("approvalConfigs", approvalHierarchyConfigRepository.findAll());
        state.put("reminderSchedules", reminderScheduleRepository.findAll());
        state.put("scheduledReports", scheduledReportRepository.findAll());
        state.put("insurers", approvedInsurerRepository.findAll());
        state.put("taxonomies", collateralTaxonomyRepository.findAll());
        state.put("mandatoryDocRules", mandatoryDocumentRuleRepository.findAll());
        state.put("holidayCalendars", holidayCalendarRepository.findAll());
        state.put("systemParameters", systemParameterRepository.findAll());
        state.put("cbsSyncLogs", cbsSyncLogRepository.findAllByOrderByTimestampDesc());
        state.put("cbsSync", cbsSyncService.getCbsSyncStatus());
        state.put("systemDate", simulatedSystemDate);
        return state;
    }

    public void logAudit(String userId, String userRole, String actionType, String entityType, String entityId, String fieldName, String oldVal, String newVal, String comments) {
        AuditLog log = new AuditLog();
        log.setId("log-" + System.currentTimeMillis() + "-" + new Random().nextInt(1000));
        log.setTimestamp(LocalDateTime.now().toString());
        log.setUserId(userId != null ? userId : "SYSTEM");
        log.setUserName(userId);
        log.setRoleCode(userRole != null ? userRole : "SYSADMIN");
        log.setIpAddress("127.0.0.1");
        log.setActionType(actionType);
        log.setEntityType(entityType);
        log.setEntityId(entityId);
        log.setFieldName(fieldName);
        log.setOldValue(oldVal);
        log.setNewValue(newVal);
        log.setOldValueState(oldVal);
        log.setNewValueState(newVal);
        log.setComments(comments);
        auditLogRepository.save(log);
    }

    // --- CBS Simulator & Sync Engine ---
    public Map<String, Object> syncCbsCustomer(String customerId, String userId) {
        Map<String, Object> result = new HashMap<>();
        Optional<CbsCustomer> cbsOpt = cbsCustomerRepository.findById(customerId);
        if (cbsOpt.isEmpty()) {
            Optional<CbsCustomer> cbsCifOpt = cbsCustomerRepository.findByCif(customerId);
            if (cbsCifOpt.isPresent()) cbsOpt = cbsCifOpt;
        }

        if (cbsOpt.isPresent()) {
            CbsCustomer cbs = cbsOpt.get();
            Optional<Customer> existing = customerRepository.findAll().stream().filter(c -> c.getCif() != null && c.getCif().equalsIgnoreCase(cbs.getCif())).findFirst();
            Customer c = existing.orElse(new Customer());
            if (c.getId() == null) c.setId("cust-" + System.currentTimeMillis());
            c.setCif(cbs.getCif());
            c.setCustomerType(cbs.getCustomerType());
            c.setName(cbs.getFullName());
            c.setNationalId(cbs.getNationalId());
            c.setBusinessRegNo(cbs.getBusinessRegNo());
            c.setTaxIdNo(cbs.getTaxIdNo());
            c.setDobOrIncorp(cbs.getDobOrIncorp());
            c.setGender(cbs.getGender());
            c.setPhone(cbs.getPhone());
            c.setEmail(cbs.getEmail());
            c.setAddress(cbs.getAddress());
            c.setSegment(cbs.getBusinessSegment());
            c.setBranch(cbs.getBranch());
            c.setStatus(cbs.getCustomerStatus());
            c.setRiskRating(cbs.getRiskRating());
            c.setSource("CBS_SIM");
            c.setCbsSyncStatus("Synced");
            c.setCbsSyncedAt(LocalDateTime.now().toString());
            c.setRecordStat("O");
            c.setAuthStat("A");
            customerRepository.save(c);

            cbs.setSyncStatus("Synced");
            cbs.setSyncedAt(LocalDateTime.now().toString());
            cbsCustomerRepository.save(cbs);

            CbsSyncLog log = new CbsSyncLog("synclog-" + System.currentTimeMillis(), "Customer", cbs.getCif(), "CBS->CIMS", "Success", null);
            cbsSyncLogRepository.save(log);

            logAudit(userId, "SYSADMIN", "CBS_SYNC_CUSTOMER", "Customer", c.getId(), "All", "CBS_SIM", "Synced", "Synchronized customer CIF " + cbs.getCif());
            result.put("success", true);
            result.put("message", "Customer " + cbs.getCif() + " synced successfully.");
        } else {
            result.put("success", false);
            result.put("message", "CBS Customer not found.");
        }
        return result;
    }

    private Customer createShellCustomer(String cif, String segment, String branch, String userId) {
        Customer cust = new Customer();
        cust.setId("cust-" + System.currentTimeMillis() + "-" + new Random().nextInt(1000));
        cust.setCif(cif != null ? cif : "CIF-" + System.currentTimeMillis());
        cust.setName("Borrower " + cust.getCif());
        cust.setCustomerType("Corporate");
        cust.setSegment(segment != null ? segment : "Corporate Banking");
        cust.setBranch(branch != null ? branch : "Main Branch");
        cust.setStatus("Active");
        cust.setRiskRating("Low");
        cust.setSource("CBS_SIM");
        cust.setCbsSyncStatus("Synced");
        cust.setCbsSyncedAt(LocalDateTime.now().toString());
        cust.setRecordStat("O");
        cust.setAuthStat("A");
        return customerRepository.save(cust);
    }

    public Map<String, Object> syncCbsFacility(String facilityId, String userId) {
        Map<String, Object> result = new HashMap<>();
        Optional<CbsFacility> cbsOpt = cbsFacilityRepository.findById(facilityId);
        if (cbsOpt.isEmpty()) {
            Optional<CbsFacility> lineOpt = cbsFacilityRepository.findByLineCode(facilityId);
            if (lineOpt.isPresent()) cbsOpt = lineOpt;
        }

        if (cbsOpt.isPresent()) {
            CbsFacility cbs = cbsOpt.get();
            Optional<LoanAccount> existing = loanAccountRepository.findAll().stream()
                .filter(f -> (f.getLoanReference() != null && f.getLoanReference().equalsIgnoreCase(cbs.getLoanRefNo())) ||
                             (f.getLineCode() != null && f.getLineCode().equalsIgnoreCase(cbs.getLineCode())))
                .findFirst();
            LoanAccount f = existing.orElse(new LoanAccount());
            if (f.getId() == null) f.setId("loan-" + System.currentTimeMillis() + "-" + new Random().nextInt(1000));
            f.setLineCode(cbs.getLineCode() != null ? cbs.getLineCode() : "FAC-" + System.currentTimeMillis());
            f.setLoanReference(cbs.getLoanRefNo() != null ? cbs.getLoanRefNo() : f.getLineCode());

            // Link customer - auto sync from CBS or create shell to guarantee FK constraint
            String customerCif = cbs.getCustomerCif() != null ? cbs.getCustomerCif().trim() : "CIF-DEFAULT";
            Optional<Customer> custOpt = customerRepository.findAll().stream()
                .filter(c -> c.getCif() != null && c.getCif().equalsIgnoreCase(customerCif))
                .findFirst();
            
            Customer customer;
            if (custOpt.isPresent()) {
                customer = custOpt.get();
            } else {
                Optional<CbsCustomer> cbsCustOpt = cbsCustomerRepository.findAll().stream()
                    .filter(c -> c.getCif() != null && c.getCif().equalsIgnoreCase(customerCif))
                    .findFirst();
                if (cbsCustOpt.isPresent()) {
                    syncCbsCustomer(cbsCustOpt.get().getId(), userId);
                    customer = customerRepository.findAll().stream()
                        .filter(c -> c.getCif() != null && c.getCif().equalsIgnoreCase(customerCif))
                        .findFirst()
                        .orElseGet(() -> createShellCustomer(customerCif, cbs.getBusinessSegment(), cbs.getBranch(), userId));
                } else {
                    customer = createShellCustomer(customerCif, cbs.getBusinessSegment(), cbs.getBranch(), userId);
                }
            }
            f.setCustomerId(customer.getId());
            f.setFacilityType(cbs.getFacilityType() != null ? cbs.getFacilityType() : "Term Loan");
            f.setLineCurrency(cbs.getLineCurrency() != null ? cbs.getLineCurrency() : "ETB");
            f.setRevolvingLine(cbs.isRevolvingLine());
            f.setLineStartDate(cbs.getLineStartDate() != null ? cbs.getLineStartDate() : "2026-01-01");
            f.setLineExpiryDate(cbs.getLineExpiryDate() != null ? cbs.getLineExpiryDate() : "2029-01-01");
            f.setApprovedLimit(cbs.getApprovedLimit() > 0 ? cbs.getApprovedLimit() : 10000000.0);
            f.setOutstandingBalance(cbs.getOutstandingAmount() >= 0 ? cbs.getOutstandingAmount() : 5000000.0);
            f.setAvailableAmount(Math.max(0, f.getApprovedLimit() - f.getOutstandingBalance()));
            f.setCollateralContribution(cbs.getCollateralContribution());
            f.setCollateralPct(cbs.getCollateralPct());
            f.setSegment(cbs.getBusinessSegment() != null ? cbs.getBusinessSegment() : "Corporate Banking");
            f.setBranch(cbs.getBranch() != null ? cbs.getBranch() : "Main Branch");
            f.setRmUserId(cbs.getRelationshipManager() != null ? cbs.getRelationshipManager() : "CRO_USER");
            f.setStatus(cbs.getLimitStatus() != null ? cbs.getLimitStatus() : "Active");
            f.setNextReviewDueDate(cbs.getNextReviewDate() != null ? cbs.getNextReviewDate() : "2027-01-01");
            f.setSource("CBS_SIM");
            f.setRecordStat("O");
            f.setAuthStat("A");
            loanAccountRepository.save(f);

            cbs.setSyncStatus("Synced");
            cbs.setSyncedAt(LocalDateTime.now().toString());
            cbsFacilityRepository.save(cbs);

            CbsSyncLog log = new CbsSyncLog("synclog-" + System.currentTimeMillis(), "Facility", f.getLineCode(), "CBS->CIMS", "Success", null);
            cbsSyncLogRepository.save(log);

            logAudit(userId, "SYSADMIN", "CBS_SYNC_FACILITY", "Facility", f.getId(), "All", "CBS_SIM", "Synced", "Synchronized facility Line " + f.getLineCode());
            result.put("success", true);
            result.put("message", "Facility " + f.getLineCode() + " synced successfully.");
        } else {
            result.put("success", false);
            result.put("message", "CBS Facility not found: " + facilityId);
        }
        return result;
    }

    public Map<String, Object> syncCbsCollateral(String collateralId, String userId) {
        Map<String, Object> result = new HashMap<>();
        Optional<CbsCollateral> cbsOpt = cbsCollateralRepository.findById(collateralId);
        if (cbsOpt.isEmpty()) {
            Optional<CbsCollateral> codeOpt = cbsCollateralRepository.findByCollateralCode(collateralId);
            if (codeOpt.isPresent()) cbsOpt = codeOpt;
        }

        if (cbsOpt.isPresent()) {
            CbsCollateral cbs = cbsOpt.get();
            Optional<Collateral> existing = collateralRepository.findAll().stream()
                .filter(c -> c.getCode() != null && c.getCode().equalsIgnoreCase(cbs.getCollateralCode()))
                .findFirst();
            Collateral col = existing.orElse(new Collateral());
            if (col.getId() == null) col.setId("col-" + System.currentTimeMillis() + "-" + new Random().nextInt(1000));
            col.setCode(cbs.getCollateralCode() != null ? cbs.getCollateralCode() : "COL-" + System.currentTimeMillis());
            col.setDescription(cbs.getDescription() != null ? cbs.getDescription() : "Collateral Asset " + col.getCode());
            col.setCategory(cbs.getCategory() != null ? cbs.getCategory() : "Immovable Properties");
            col.setType(col.getCategory());
            col.setCurrency(cbs.getCurrency() != null ? cbs.getCurrency() : "ETB");
            col.setValuationAmount(cbs.getCollateralValue() > 0 ? cbs.getCollateralValue() : 10000000.0);
            col.setHaircut(cbs.getHaircut() >= 0 ? cbs.getHaircut() : 20.0);
            col.setLimitContribution(col.getValuationAmount() * (1.0 - (col.getHaircut() / 100.0)));
            col.setStartDate(cbs.getStartDate() != null ? cbs.getStartDate() : "2026-01-01");
            col.setReviewDate(cbs.getReviewDate() != null ? cbs.getReviewDate() : "2027-01-01");
            col.setOwnerType(cbs.getCollateralType() != null ? cbs.getCollateralType() : "Borrower-owned");
            col.setTangible(cbs.isTangible());
            col.setOwningSegment(cbs.getBusinessSegment() != null ? cbs.getBusinessSegment() : "Corporate Banking");
            col.setBranch(cbs.getBranch() != null ? cbs.getBranch() : "Main Branch");
            col.setZipCode(cbs.getZipCode());
            col.setStatus("Active");
            col.setSource("CBS_SIM");
            col.setRecordStat("O");
            col.setAuthStat("A");

            // Customer Link
            String customerCif = cbs.getCustomerCif() != null ? cbs.getCustomerCif().trim() : "CIF-DEFAULT";
            Optional<Customer> custOpt = customerRepository.findAll().stream()
                .filter(c -> c.getCif() != null && c.getCif().equalsIgnoreCase(customerCif))
                .findFirst();
            Customer customer;
            if (custOpt.isPresent()) {
                customer = custOpt.get();
            } else {
                Optional<CbsCustomer> cbsCustOpt = cbsCustomerRepository.findAll().stream()
                    .filter(c -> c.getCif() != null && c.getCif().equalsIgnoreCase(customerCif))
                    .findFirst();
                if (cbsCustOpt.isPresent()) {
                    syncCbsCustomer(cbsCustOpt.get().getId(), userId);
                    customer = customerRepository.findAll().stream()
                        .filter(c -> c.getCif() != null && c.getCif().equalsIgnoreCase(customerCif))
                        .findFirst()
                        .orElseGet(() -> createShellCustomer(customerCif, col.getOwningSegment(), col.getBranch(), userId));
                } else {
                    customer = createShellCustomer(customerCif, col.getOwningSegment(), col.getBranch(), userId);
                }
            }
            col.setCustomerId(customer.getId());

            // Auto owner from customer if no owners
            if (col.getOwners().isEmpty()) {
                CollateralOwner owner = new CollateralOwner("own-" + System.currentTimeMillis(), customer.getName(), customer.getPhone() != null ? customer.getPhone() : "+251911000000", col.getId(), "Borrower", 100.0);
                owner.setOwnershipType("Borrower-owned");
                owner.setOwnerType(customer.getCustomerType() != null ? customer.getCustomerType() : "Corporate");
                owner.setVerificationStatus("Verified");
                col.getOwners().add(owner);
            }

            collateralRepository.save(col);

            // Auto-link loan if linkedLoanRefs is provided
            if (cbs.getLinkedLoanRefs() != null && !cbs.getLinkedLoanRefs().isBlank()) {
                String ref = cbs.getLinkedLoanRefs().trim();
                Optional<LoanAccount> loanOpt = loanAccountRepository.findAll().stream()
                    .filter(l -> (l.getLoanReference() != null && l.getLoanReference().equalsIgnoreCase(ref)) || 
                                 (l.getLineCode() != null && l.getLineCode().equalsIgnoreCase(ref)))
                    .findFirst();
                if (loanOpt.isPresent()) {
                    String loanId = loanOpt.get().getId();
                    boolean linkExists = loanCollateralLinkRepository.findAll().stream()
                        .anyMatch(lnk -> lnk.getLoanAccountId().equals(loanId) && lnk.getCollateralId().equals(col.getId()));
                    if (!linkExists) {
                        LoanCollateralLink lnk = new LoanCollateralLink("lnk-" + System.currentTimeMillis(), loanId, col.getId(), col.getValuationAmount());
                        lnk.setMakerId(userId);
                        lnk.setRecordStat("O");
                        lnk.setAuthStat("A");
                        loanCollateralLinkRepository.save(lnk);
                    }
                }
            }

            cbs.setSyncStatus("Synced");
            cbs.setSyncedAt(LocalDateTime.now().toString());
            cbsCollateralRepository.save(cbs);

            CbsSyncLog log = new CbsSyncLog("synclog-" + System.currentTimeMillis(), "Collateral", col.getCode(), "CBS->CIMS", "Success", null);
            cbsSyncLogRepository.save(log);

            updateCollateralStatus(col.getId());
            logAudit(userId, "SYSADMIN", "CBS_SYNC_COLLATERAL", "Collateral", col.getId(), "All", "CBS_SIM", "Synced", "Synchronized collateral " + col.getCode());
            result.put("success", true);
            result.put("message", "Collateral " + col.getCode() + " synced successfully.");
        } else {
            result.put("success", false);
            result.put("message", "CBS Collateral not found: " + collateralId);
        }
        return result;
    }

    public Map<String, Object> syncAllPendingCbs(String userId) {
        int custCount = 0;
        int facCount = 0;
        int colCount = 0;

        for (CbsCustomer c : cbsCustomerRepository.findAll()) {
            if (!"Synced".equalsIgnoreCase(c.getSyncStatus())) {
                syncCbsCustomer(c.getId(), userId);
                custCount++;
            }
        }
        for (CbsFacility f : cbsFacilityRepository.findAll()) {
            if (!"Synced".equalsIgnoreCase(f.getSyncStatus())) {
                syncCbsFacility(f.getId(), userId);
                facCount++;
            }
        }
        for (CbsCollateral col : cbsCollateralRepository.findAll()) {
            if (!"Synced".equalsIgnoreCase(col.getSyncStatus())) {
                syncCbsCollateral(col.getId(), userId);
                colCount++;
            }
        }

        Map<String, Object> res = new HashMap<>();
        res.put("success", true);
        res.put("syncedCustomers", custCount);
        res.put("syncedFacilities", facCount);
        res.put("syncedCollaterals", colCount);
        res.put("message", "Batch sync completed: " + custCount + " Customers, " + facCount + " Facilities, " + colCount + " Collaterals.");
        return res;
    }

    // --- Outbound Notifications Engine ---
    public void sendNotification(String channel, String templateCode, String recipient, String recipientName, String subject, String messageBody, String entityType, String entityId) {
        try {
            Notification n = new Notification();
            n.setId("notif-" + System.currentTimeMillis() + "-" + new Random().nextInt(1000));
            n.setChannel(channel != null ? channel : "Email");
            n.setTemplateCode(templateCode != null ? templateCode : "GENERAL_ALERT");
            n.setRecipient(recipient != null ? recipient : "alerts@cims-bank.et");
            n.setRecipientName(recipientName != null ? recipientName : "CIMS User");
            n.setSubject(subject != null ? subject : "CIMS System Notification");
            n.setMessageBody(messageBody != null ? messageBody : "System notification");
            n.setEntityType(entityType);
            n.setEntityId(entityId);
            n.setStatus("Sent");
            n.setSentAt(LocalDateTime.now().toString());
            n.setRetryCount(0);
            notificationRepository.save(n);
        } catch (Exception e) {
            System.err.println("Failed to persist notification: " + e.getMessage());
        }
    }

    // --- Maker-Checker Dual Control & Workflow ---
    public WorkflowTask submitToWorkflow(String processKey, String entityType, String entityId, String actionType, String diffJson, String remarks, String makerId, String candidateRole) {
        WorkflowTask task = new WorkflowTask();
        task.setId("task-" + System.currentTimeMillis() + "-" + new Random().nextInt(1000));
        task.setEntityType(entityType);
        task.setEntityId(entityId);
        task.setActionType(actionType);
        task.setPayloadDiffJson(diffJson);
        task.setRemarks(remarks);
        task.setMakerId(makerId != null ? makerId : "CRO_USER");

        // Dynamically resolve target role and SLA from SysAdmin Approval Hierarchy Configs
        String resolvedRole = candidateRole;
        int sla = 24;
        if (actionType != null) {
            List<ApprovalHierarchyConfig> configs = approvalHierarchyConfigRepository.findAll();
            for (ApprovalHierarchyConfig cfg : configs) {
                if (cfg.isActive() && (actionType.equalsIgnoreCase(cfg.getTransactionType()) ||
                                       (cfg.getTransactionType() != null && actionType.toLowerCase().contains(cfg.getTransactionType().toLowerCase())))) {
                    if (cfg.getLevel1Role() != null && !cfg.getLevel1Role().isBlank()) {
                        resolvedRole = cfg.getLevel1Role();
                        sla = cfg.getSlaHours();
                    }
                    break;
                }
            }
        }
        if (resolvedRole == null || resolvedRole.isBlank()) {
            resolvedRole = "BRMGR";
        }
        task.setCandidateRole(resolvedRole);
        task.setCurrentStep("Checker Review");
        task.setPriority("High");
        task.setStatus("Pending");
        task.setSubmittedAt(LocalDateTime.now().toString());

        if (flowableWorkflowService != null) {
            String procId = flowableWorkflowService.startMakerCheckerProcess(processKey, entityType, entityId, makerId, task.getCandidateRole(), diffJson, remarks);
            task.setProcessInstanceId(procId);
        }

        workflowTaskRepository.save(task);
        logAudit(makerId, "MAKER", "SUBMIT_WORKFLOW_TASK", entityType, entityId, "Status", "Draft", "Pending Approval", "Submitted " + actionType + " to Checker (" + task.getCandidateRole() + ", SLA " + sla + "h)");

        // Outbound Notifications for Checker
        sendNotification(
            "Email",
            "WORKFLOW_CHECKER_ALERT",
            "brmgr@cims-bank.et",
            "Branch Manager Checker",
            "Dual Control Authorization Required: " + actionType,
            "Dear Checker,\n\nA new maker submission requires your dual-control authorization:\n" +
            "• Entity Type: " + entityType + "\n" +
            "• Reference: " + entityId + "\n" +
            "• Action: " + actionType + "\n" +
            "• Submitted By Maker: " + makerId + "\n" +
            "• Remarks: " + (remarks != null ? remarks : "N/A") + "\n\n" +
            "Please log in to CIMS Maker-Checker Inbox or Branch Manager Dashboard to review before authorization.",
            entityType,
            entityId
        );

        sendNotification(
            "SMS",
            "WORKFLOW_CHECKER_SMS",
            "+251911000111",
            "Branch Manager",
            "CIMS Dual-Control Alert",
            "CIMS Alert: Maker " + makerId + " submitted " + actionType + " for " + entityType + " (" + entityId + ") awaiting your authorization.",
            entityType,
            entityId
        );

        return task;
    }

    public void handleWorkflowApproval(String entityType, String entityId, String checkerId, String comments) {
        // Authorize business record
        if ("Insurance Policy".equalsIgnoreCase(entityType) || "Policy".equalsIgnoreCase(entityType)) {
            Optional<InsurancePolicy> pOpt = insurancePolicyRepository.findById(entityId);
            if (pOpt.isPresent()) {
                InsurancePolicy p = pOpt.get();
                p.setStatus("Active");
                p.setRecordStat("O");
                p.setAuthStat("A");
                p.setCheckerId(checkerId);
                p.setCheckerDtStamp(LocalDateTime.now().toString());
                p.setOnceAuth("Y");
                insurancePolicyRepository.save(p);
                updateCollateralStatus(p.getCollateralId());
            }
        } else if ("Collateral".equalsIgnoreCase(entityType)) {
            Optional<Collateral> cOpt = collateralRepository.findById(entityId);
            if (cOpt.isPresent()) {
                Collateral c = cOpt.get();
                c.setRecordStat("O");
                c.setAuthStat("A");
                c.setVerificationStatus("Verified");
                c.setCheckerId(checkerId);
                c.setCheckerDtStamp(LocalDateTime.now().toString());
                c.setOnceAuth("Y");
                collateralRepository.save(c);
                updateCollateralStatus(c.getId());
            }
        } else if ("Customer".equalsIgnoreCase(entityType)) {
            Optional<Customer> cOpt = customerRepository.findById(entityId);
            if (cOpt.isPresent()) {
                Customer c = cOpt.get();
                c.setRecordStat("O");
                c.setAuthStat("A");
                c.setCheckerId(checkerId);
                c.setCheckerDtStamp(LocalDateTime.now().toString());
                c.setOnceAuth("Y");
                customerRepository.save(c);
            }
        }
    }

    public void handleWorkflowRejection(String entityType, String entityId, String checkerId, String comments) {
        if ("Insurance Policy".equalsIgnoreCase(entityType) || "Policy".equalsIgnoreCase(entityType)) {
            Optional<InsurancePolicy> pOpt = insurancePolicyRepository.findById(entityId);
            if (pOpt.isPresent()) {
                InsurancePolicy p = pOpt.get();
                p.setStatus("Rejected");
                p.setRecordStat("R");
                p.setAuthStat("R");
                p.setCheckerId(checkerId);
                p.setCheckerDtStamp(LocalDateTime.now().toString());
                insurancePolicyRepository.save(p);
            }
        } else if ("Collateral".equalsIgnoreCase(entityType)) {
            Optional<Collateral> cOpt = collateralRepository.findById(entityId);
            if (cOpt.isPresent()) {
                Collateral c = cOpt.get();
                c.setStatus("Rejected");
                c.setRecordStat("R");
                c.setAuthStat("R");
                c.setVerificationStatus("Rejected");
                c.setCheckerId(checkerId);
                c.setCheckerDtStamp(LocalDateTime.now().toString());
                collateralRepository.save(c);
            }
        } else if ("Customer".equalsIgnoreCase(entityType)) {
            Optional<Customer> cOpt = customerRepository.findById(entityId);
            if (cOpt.isPresent()) {
                Customer c = cOpt.get();
                c.setRecordStat("R");
                c.setAuthStat("R");
                c.setCheckerId(checkerId);
                c.setCheckerDtStamp(LocalDateTime.now().toString());
                customerRepository.save(c);
            }
        }
    }

    private void validateDualControl(WorkflowTask task, String checkerId) {
        if (task.getMakerId() != null && checkerId != null) {
            String cleanMaker = task.getMakerId().trim().toLowerCase();
            String cleanChecker = checkerId.trim().toLowerCase();
            if (cleanMaker.equals(cleanChecker) ||
                cleanMaker.replace("_user", "").equals(cleanChecker.replace("_user", "")) ||
                cleanMaker.equals(cleanChecker + "_user") ||
                (cleanMaker + "_user").equals(cleanChecker)) {
                throw new IllegalStateException("Dual-Control Violation: Maker (" + task.getMakerId() + ") cannot authorize their own submission. Segregation of duties (Four-Eyes Principle) strictly requires an independent Checker.");
            }
        }
    }

    public void approveWorkflowTask(String taskId, String checkerId, String checkerRole, String comments) {
        Optional<WorkflowTask> taskOpt = workflowTaskRepository.findById(taskId);
        if (taskOpt.isPresent()) {
            WorkflowTask task = taskOpt.get();
            validateDualControl(task, checkerId);

            task.setStatus("Approved");
            task.setCurrentStep("Completed");
            task.setCompletedAt(LocalDateTime.now().toString());
            workflowTaskRepository.save(task);

            ApprovalHistory hist = new ApprovalHistory();
            hist.setId("hist-" + System.currentTimeMillis());
            hist.setWorkflowTaskId(taskId);
            hist.setActorId(checkerId != null ? checkerId : "BRMGR_USER");
            hist.setActorRole(checkerRole != null ? checkerRole : "BRMGR");
            hist.setStepName("Checker Review");
            hist.setDecision("Approved");
            hist.setComments(comments != null ? comments : "Approved by Checker");
            hist.setDecidedAt(LocalDateTime.now().toString());
            approvalHistoryRepository.save(hist);

            handleWorkflowApproval(task.getEntityType(), task.getEntityId(), checkerId, comments);
            logAudit(checkerId, checkerRole, "APPROVE_WORKFLOW_TASK", task.getEntityType(), task.getEntityId(), "Status", "Pending", "Approved", comments);

            // Outbound notification to Maker
            sendNotification(
                "Email",
                "WORKFLOW_APPROVED_EMAIL",
                "maker@cims-bank.et",
                task.getMakerId(),
                "APPROVED: " + task.getActionType() + " for " + task.getEntityType(),
                "Dear Maker (" + task.getMakerId() + "),\n\nYour submitted transaction has been AUTHORIZED by Checker " + checkerId + " (" + (checkerRole != null ? checkerRole : "BRMGR") + ").\n" +
                "• Entity: " + task.getEntityType() + " (" + task.getEntityId() + ")\n" +
                "• Decision: Approved / Authorized\n" +
                "• Checker Comments: " + (comments != null ? comments : "None"),
                task.getEntityType(),
                task.getEntityId()
            );

            sendNotification(
                "SMS",
                "WORKFLOW_APPROVED_SMS",
                "+251911223344",
                task.getMakerId(),
                "CIMS Transaction Approved",
                "CIMS Alert: Your transaction " + task.getActionType() + " (" + task.getEntityId() + ") was AUTHORIZED by " + checkerId + ".",
                task.getEntityType(),
                task.getEntityId()
            );
        }
    }

    public void rejectWorkflowTask(String taskId, String checkerId, String checkerRole, String comments) {
        Optional<WorkflowTask> taskOpt = workflowTaskRepository.findById(taskId);
        if (taskOpt.isPresent()) {
            WorkflowTask task = taskOpt.get();
            validateDualControl(task, checkerId);

            task.setStatus("Rejected");
            task.setCurrentStep("Rejected");
            task.setCompletedAt(LocalDateTime.now().toString());
            workflowTaskRepository.save(task);

            ApprovalHistory hist = new ApprovalHistory();
            hist.setId("hist-" + System.currentTimeMillis());
            hist.setWorkflowTaskId(taskId);
            hist.setActorId(checkerId != null ? checkerId : "BRMGR_USER");
            hist.setActorRole(checkerRole != null ? checkerRole : "BRMGR");
            hist.setStepName("Checker Review");
            hist.setDecision("Rejected");
            hist.setComments(comments != null ? comments : "Rejected by Checker");
            hist.setDecidedAt(LocalDateTime.now().toString());
            approvalHistoryRepository.save(hist);

            handleWorkflowRejection(task.getEntityType(), task.getEntityId(), checkerId, comments);
            logAudit(checkerId, checkerRole, "REJECT_WORKFLOW_TASK", task.getEntityType(), task.getEntityId(), "Status", "Pending", "Rejected", comments);

            // Outbound notification to Maker
            sendNotification(
                "Email",
                "WORKFLOW_REJECTED_EMAIL",
                "maker@cims-bank.et",
                task.getMakerId(),
                "REJECTED: " + task.getActionType() + " for " + task.getEntityType(),
                "Dear Maker (" + task.getMakerId() + "),\n\nYour submitted transaction was REJECTED by Checker " + checkerId + " (" + (checkerRole != null ? checkerRole : "BRMGR") + ").\n" +
                "• Entity: " + task.getEntityType() + " (" + task.getEntityId() + ")\n" +
                "• Rationale: " + (comments != null ? comments : "Disapproved"),
                task.getEntityType(),
                task.getEntityId()
            );
        }
    }

    public void returnWorkflowTask(String taskId, String checkerId, String checkerRole, String correctionNote) {
        Optional<WorkflowTask> taskOpt = workflowTaskRepository.findById(taskId);
        if (taskOpt.isPresent()) {
            WorkflowTask task = taskOpt.get();
            validateDualControl(task, checkerId);

            task.setStatus("Returned");
            task.setCurrentStep("Maker Correction");
            task.setRemarks(correctionNote);
            workflowTaskRepository.save(task);

            ApprovalHistory hist = new ApprovalHistory();
            hist.setId("hist-" + System.currentTimeMillis());
            hist.setWorkflowTaskId(taskId);
            hist.setActorId(checkerId != null ? checkerId : "BRMGR_USER");
            hist.setActorRole(checkerRole != null ? checkerRole : "BRMGR");
            hist.setStepName("Checker Review");
            hist.setDecision("Returned");
            hist.setComments(correctionNote != null ? correctionNote : "Returned for correction");
            hist.setDecidedAt(LocalDateTime.now().toString());
            approvalHistoryRepository.save(hist);

            logAudit(checkerId, checkerRole, "RETURN_WORKFLOW_TASK", task.getEntityType(), task.getEntityId(), "Status", "Pending", "Returned", correctionNote);

            // Outbound notification to Maker
            sendNotification(
                "Email",
                "WORKFLOW_RETURNED_EMAIL",
                "maker@cims-bank.et",
                task.getMakerId(),
                "RETURNED FOR CORRECTION: " + task.getActionType() + " for " + task.getEntityType(),
                "Dear Maker (" + task.getMakerId() + "),\n\nYour submitted transaction has been RETURNED for correction by Checker " + checkerId + ".\n" +
                "• Entity: " + task.getEntityType() + " (" + task.getEntityId() + ")\n" +
                "• Feedback / Required Corrections: " + (correctionNote != null ? correctionNote : "Please review details."),
                task.getEntityType(),
                task.getEntityId()
            );

            sendNotification(
                "SMS",
                "WORKFLOW_RETURNED_SMS",
                "+251911223344",
                task.getMakerId(),
                "CIMS Transaction Returned",
                "CIMS Alert: Transaction " + task.getActionType() + " was returned for correction by " + checkerId + ". Check remarks in CIMS.",
                task.getEntityType(),
                task.getEntityId()
            );
        }
    }

    public void updateCollateralStatus(String collateralId) {
        Optional<Collateral> colOpt = collateralRepository.findById(collateralId);
        if (colOpt.isEmpty()) return;
        Collateral col = colOpt.get();

        double totalInsured = 0;
        List<InsurancePolicy> policies = insurancePolicyRepository.findByCollateralId(collateralId);
        for (InsurancePolicy p : policies) {
            if ("Active".equalsIgnoreCase(p.getStatus())) {
                totalInsured += p.getInsuredAmount();
            }
        }
        col.setInsuredAmount(totalInsured);

        // Compute total outstanding exposure across all linked facilities
        double totalExposure = 0;
        List<LoanCollateralLink> links = loanCollateralLinkRepository.findAll();
        for (LoanCollateralLink l : links) {
            if (collateralId.equals(l.getCollateralId())) {
                Optional<LoanAccount> loan = loanAccountRepository.findById(l.getLoanAccountId());
                if (loan.isPresent()) {
                    totalExposure += loan.get().getOutstandingBalance();
                }
            }
        }

        double coveragePct = 0;
        if (totalExposure > 0) {
            coveragePct = (totalInsured / totalExposure) * 100.0;
        } else if (totalInsured >= col.getValuationAmount()) {
            coveragePct = 100.0;
        }

        col.setNetInsuranceCoveragePct(coveragePct);
        if (totalInsured <= 0) {
            col.setStatus("Uninsured");
            col.setInsuranceStatus("Uninsured");
        } else if (coveragePct >= 100.0) {
            col.setStatus("Insured");
            col.setInsuranceStatus("Fully Insured");
        } else if (coveragePct >= 70.0) {
            col.setStatus("Under-Insured");
            col.setInsuranceStatus("Underinsured");
        } else {
            col.setStatus("Under-Insured");
            col.setInsuranceStatus("Underinsured");
        }
        collateralRepository.save(col);
    }

    // --- BR-01: Business Segments ---
    public void addBusinessSegment(BusinessSegment segment, String userId) {
        segment.setId("seg-" + System.currentTimeMillis());
        segment.setActive(true);
        businessSegmentRepository.save(segment);
        logAudit(userId, "SYSADMIN", "CREATE_BUSINESS_SEGMENT", "BusinessSegment", segment.getId(), "Name", "None", segment.getName(), "Created segment");
    }

    public void toggleSegmentActiveStatus(String segmentId, boolean active, String userId) {
        Optional<BusinessSegment> segOpt = businessSegmentRepository.findById(segmentId);
        if (segOpt.isPresent()) {
            BusinessSegment seg = segOpt.get();
            boolean oldStatus = seg.isActive();
            seg.setActive(active);
            businessSegmentRepository.save(seg);
            logAudit(userId, "SYSADMIN", "TOGGLE_SEGMENT_STATUS", "BusinessSegment", segmentId, "Active", String.valueOf(oldStatus), String.valueOf(active), "Toggled segment active status");
        }
    }

    // --- Native Collateral Registration (RO Maker) ---
    public void registerNativeCollateral(Collateral collateral, String userId) {
        if (collateral.getId() == null || collateral.getId().isBlank()) {
            collateral.setId("col-" + System.currentTimeMillis());
        }
        if (collateral.getCode() == null || collateral.getCode().isBlank()) {
            collateral.setCode("COL-" + (System.currentTimeMillis() % 100000));
        }
        if (collateral.getType() == null || collateral.getType().isBlank()) {
            collateral.setType(collateral.getCategory() != null ? collateral.getCategory() : "Primary Collateral");
        }
        if (collateral.getCategory() == null || collateral.getCategory().isBlank()) {
            collateral.setCategory("Immovable Properties");
        }
        if (collateral.getDescription() == null || collateral.getDescription().isBlank()) {
            collateral.setDescription("Registered Collateral Asset " + collateral.getCode());
        }
        if (collateral.getOwningSegment() == null || collateral.getOwningSegment().isBlank()) {
            collateral.setOwningSegment("Corporate Banking");
        }
        if (collateral.getBranch() == null || collateral.getBranch().isBlank()) {
            collateral.setBranch("Main Branch");
        }
        if (collateral.getOwnerType() == null || collateral.getOwnerType().isBlank()) {
            collateral.setOwnerType("Borrower-owned");
        }
        if (collateral.getCurrency() == null || collateral.getCurrency().isBlank()) {
            collateral.setCurrency("ETB");
        }
        if (collateral.getLimitContribution() == 0 && collateral.getValuationAmount() > 0) {
            collateral.setLimitContribution(collateral.getValuationAmount() * (1.0 - (collateral.getHaircut() / 100.0)));
        }

        collateral.setCreatedBy(userId);
        collateral.setStatus("Uninsured");
        collateral.setInsuranceStatus("Uninsured");
        collateral.setVerificationStatus("Pending");
        collateral.setRecordStat("U");
        collateral.setAuthStat("U");
        collateral.setMakerId(userId);
        collateral.setMakerDtStamp(LocalDateTime.now().toString());
        collateralRepository.save(collateral);

        submitToWorkflow("PROC_COLLATERAL_REGISTRATION", "Collateral", collateral.getId(), "Register Collateral", "{}", "New collateral registration: " + collateral.getCode() + " (" + collateral.getDescription() + ")", userId, "BRMGR");
        logAudit(userId, "CRO", "REGISTER_NATIVE_COLLATERAL", "Collateral", collateral.getId(), "All", "None", collateral.getCode(), "Registered collateral for checker approval");
    }

    // --- Link Operations ---
    public void addLink(String loanId, String collateralId, double amount, String userId) {
        LoanCollateralLink link = new LoanCollateralLink("lnk-" + System.currentTimeMillis(), loanId, collateralId, amount);
        link.setMakerId(userId);
        link.setRecordStat("O");
        link.setAuthStat("A");
        loanCollateralLinkRepository.save(link);
        updateCollateralStatus(collateralId);
        logAudit(userId, "CRO", "CREATE_JUNCTION_LINK", "LoanCollateralLink", link.getId(), "Amount", "0", String.valueOf(amount), "Linked loan " + loanId + " to collateral " + collateralId);
    }

    public void removeLink(String linkId, String userId) {
        Optional<LoanCollateralLink> linkOpt = loanCollateralLinkRepository.findById(linkId);
        if (linkOpt.isPresent()) {
            LoanCollateralLink link = linkOpt.get();
            loanCollateralLinkRepository.deleteById(linkId);
            updateCollateralStatus(link.getCollateralId());
            logAudit(userId, "CRO", "DELETE_JUNCTION_LINK", "LoanCollateralLink", linkId, "Link", linkId, "Deleted", "Removed facility linkage");
        }
    }

    public Map<String, Object> validateCollateralRelease(String collateralId) {
        Map<String, Object> validation = new HashMap<>();
        List<LoanCollateralLink> links = loanCollateralLinkRepository.findAll();
        double pendingExposure = 0;
        List<String> activeLoanNumbers = new ArrayList<>();

        for (LoanCollateralLink link : links) {
            if (link.getCollateralId().equals(collateralId)) {
                Optional<LoanAccount> loanOpt = loanAccountRepository.findById(link.getLoanAccountId());
                if (loanOpt.isPresent() && loanOpt.get().getOutstandingBalance() > 0) {
                    pendingExposure += loanOpt.get().getOutstandingBalance();
                    activeLoanNumbers.add(loanOpt.get().getLoanReference());
                }
            }
        }

        boolean canRelease = (pendingExposure == 0);
        validation.put("canRelease", canRelease);
        validation.put("pendingExposure", pendingExposure);
        validation.put("activeLoans", activeLoanNumbers);
        validation.put("message", canRelease ? "Collateral is clear for release." : "Release blocked: Active outstanding loan obligations remain (" + pendingExposure + " ETB).");
        return validation;
    }

    // --- Policy Operations ---
    public void addPolicy(InsurancePolicy policy, String userId) {
        if (policy.getId() == null || policy.getId().isBlank()) {
            policy.setId("pol-" + System.currentTimeMillis());
        }
        if (policy.getPolicyNumber() == null || policy.getPolicyNumber().isBlank()) {
            policy.setPolicyNumber("POL-" + (System.currentTimeMillis() % 1000000));
        }
        if (policy.getCoverageType() == null || policy.getCoverageType().isBlank()) {
            policy.setCoverageType("Fire & Allied Perils");
        }
        if (policy.getInsurerName() == null || policy.getInsurerName().isBlank()) {
            policy.setInsurerName("Nyala Insurance S.C.");
        }
        if (policy.getEffectiveDate() == null || policy.getEffectiveDate().isBlank()) {
            policy.setEffectiveDate(LocalDate.now().toString());
        }
        if (policy.getExpiryDate() == null || policy.getExpiryDate().isBlank()) {
            policy.setExpiryDate(LocalDate.now().plusYears(1).toString());
        }

        // Safely resolve collateral
        if (policy.getCollateralId() != null && !policy.getCollateralId().isBlank()) {
            Optional<Collateral> colOpt = collateralRepository.findById(policy.getCollateralId());
            if (colOpt.isEmpty()) {
                colOpt = collateralRepository.findByCode(policy.getCollateralId());
            }
            if (colOpt.isPresent()) {
                policy.setCollateralId(colOpt.get().getId());
                if (policy.getCustomerId() == null || policy.getCustomerId().isBlank()) {
                    policy.setCustomerId(colOpt.get().getCustomerId());
                }
            } else {
                // If specific ID wasn't found, find any active collateral or set null
                List<Collateral> allCols = collateralRepository.findAll();
                if (!allCols.isEmpty()) {
                    policy.setCollateralId(allCols.get(0).getId());
                    if (policy.getCustomerId() == null || policy.getCustomerId().isBlank()) {
                        policy.setCustomerId(allCols.get(0).getCustomerId());
                    }
                } else {
                    policy.setCollateralId(null);
                }
            }
        } else {
            List<Collateral> allCols = collateralRepository.findAll();
            if (!allCols.isEmpty()) {
                policy.setCollateralId(allCols.get(0).getId());
                if (policy.getCustomerId() == null || policy.getCustomerId().isBlank()) {
                    policy.setCustomerId(allCols.get(0).getCustomerId());
                }
            }
        }

        boolean isDraft = "Draft".equalsIgnoreCase(policy.getStatus());
        if (isDraft) {
            policy.setStatus("Draft");
            policy.setRecordStat("U");
            policy.setAuthStat("U");
        } else {
            policy.setStatus("Pending Approval");
            policy.setRecordStat("U");
            policy.setAuthStat("U");
        }

        policy.setMakerId(userId);
        policy.setMakerDtStamp(LocalDateTime.now().toString());
        policy.setVersion(1);
        policy.setHistoryJson("[{\"version\":1,\"changedAt\":\"" + LocalDateTime.now() + "\",\"changedBy\":\"" + userId + "\",\"description\":\"Policy Created (" + policy.getStatus() + ")\",\"dataSnapshot\":\"{}\"}]");
        insurancePolicyRepository.save(policy);

        if (!isDraft) {
            submitToWorkflow("PROC_POLICY_REGISTRATION", "Insurance Policy", policy.getId(), "Register Insurance Policy", "{}", "New policy registration: " + policy.getPolicyNumber() + " (" + policy.getCoverageType() + ")", userId, "BRMGR");
            logAudit(userId, "CRO", "SUBMIT_POLICY_CHECKER", "Insurance Policy", policy.getId(), "Status", "Draft", "Pending Approval", "Submitted policy " + policy.getPolicyNumber() + " for checker authorization");
        } else {
            logAudit(userId, "CRO", "CREATE_POLICY_DRAFT", "Insurance Policy", policy.getId(), "Status", "None", "Draft", "Created policy draft " + policy.getPolicyNumber());
        }
    }

    public void submitPolicyForApproval(String policyId, String userId) {
        Optional<InsurancePolicy> policyOpt = insurancePolicyRepository.findById(policyId);
        if (policyOpt.isEmpty()) {
            policyOpt = insurancePolicyRepository.findByPolicyNumber(policyId);
        }
        if (policyOpt.isPresent()) {
            InsurancePolicy policy = policyOpt.get();
            policy.setStatus("Pending Approval");
            policy.setRecordStat("U");
            policy.setAuthStat("U");
            insurancePolicyRepository.save(policy);

            submitToWorkflow("PROC_POLICY_REGISTRATION", "Insurance Policy", policy.getId(), "Register Insurance Policy", "{}", "Submitted policy " + policy.getPolicyNumber() + " for checker authorization", userId, "BRMGR");
            logAudit(userId, "CRO", "SUBMIT_POLICY_CHECKER", "Insurance Policy", policy.getId(), "Status", "Draft", "Pending Approval", "Submitted policy " + policy.getPolicyNumber());
        }
    }

    public void approvePolicy(String policyId, String userId) {
        Optional<InsurancePolicy> policyOpt = insurancePolicyRepository.findById(policyId);
        if (policyOpt.isPresent()) {
            InsurancePolicy policy = policyOpt.get();
            policy.setStatus("Active");
            policy.setRecordStat("O");
            policy.setAuthStat("A");
            policy.setCheckerId(userId);
            policy.setCheckerDtStamp(LocalDateTime.now().toString());
            insurancePolicyRepository.save(policy);
            updateCollateralStatus(policy.getCollateralId());
            logAudit(userId, "BRMGR", "APPROVE_POLICY", "Insurance Policy", policyId, "Status", "Pending Approval", "Active", "Approved policy " + policy.getPolicyNumber());
        }
    }

    public void rejectPolicy(String policyId, String comments, String userId) {
        Optional<InsurancePolicy> policyOpt = insurancePolicyRepository.findById(policyId);
        if (policyOpt.isPresent()) {
            InsurancePolicy policy = policyOpt.get();
            policy.setStatus("Rejected");
            policy.setRecordStat("R");
            policy.setAuthStat("R");
            policy.setCheckerId(userId);
            policy.setCheckerDtStamp(LocalDateTime.now().toString());
            insurancePolicyRepository.save(policy);
            logAudit(userId, "BRMGR", "REJECT_POLICY", "Insurance Policy", policyId, "Status", "Pending Approval", "Rejected", comments);
        }
    }

    public void amendPolicy(String policyId, InsurancePolicy updated, String userId) {
        Optional<InsurancePolicy> policyOpt = insurancePolicyRepository.findById(policyId);
        if (policyOpt.isPresent()) {
            InsurancePolicy policy = policyOpt.get();
            policy.setInsurerName(updated.getInsurerName());
            policy.setInsuredAmount(updated.getInsuredAmount());
            policy.setPremium(updated.getPremium());
            policy.setEffectiveDate(updated.getEffectiveDate());
            policy.setExpiryDate(updated.getExpiryDate());
            policy.setCoverageType(updated.getCoverageType());
            policy.setVersion(policy.getVersion() + 1);
            insurancePolicyRepository.save(policy);
            updateCollateralStatus(policy.getCollateralId());
            logAudit(userId, "CRO", "AMEND_POLICY", "Insurance Policy", policyId, "Version", String.valueOf(policy.getVersion() - 1), String.valueOf(policy.getVersion()), "Amended policy fields");
        }
    }

    public void renewPolicy(String policyId, double newAmount, double newPremium, String newExpiryDate, String userId) {
        Optional<InsurancePolicy> policyOpt = insurancePolicyRepository.findById(policyId);
        if (policyOpt.isPresent()) {
            InsurancePolicy old = policyOpt.get();
            old.setStatus("Renewed");
            insurancePolicyRepository.save(old);

            InsurancePolicy renewed = new InsurancePolicy();
            renewed.setId("pol-" + System.currentTimeMillis());
            renewed.setPolicyNumber(old.getPolicyNumber() + "-R");
            renewed.setCollateralId(old.getCollateralId());
            renewed.setCustomerId(old.getCustomerId());
            renewed.setInsurerName(old.getInsurerName());
            renewed.setCoverageType(old.getCoverageType());
            renewed.setInsuredAmount(newAmount > 0 ? newAmount : old.getInsuredAmount());
            renewed.setPremium(newPremium > 0 ? newPremium : old.getPremium());
            renewed.setEffectiveDate(old.getExpiryDate());
            renewed.setExpiryDate(newExpiryDate);
            renewed.setStatus("Active");
            renewed.setRenewedFromPolicyId(old.getId());
            renewed.setVersion(1);
            renewed.setMakerId(userId);
            renewed.setRecordStat("O");
            renewed.setAuthStat("A");
            insurancePolicyRepository.save(renewed);

            updateCollateralStatus(old.getCollateralId());
            logAudit(userId, "CRO", "RENEW_POLICY", "Insurance Policy", renewed.getId(), "Status", "Old: " + old.getId(), "Renewed", "Renewed policy with new expiry " + newExpiryDate);
        }
    }

    // --- Document Upload & Management ---
    public OwnershipDocument uploadDocument(String entityType, String entityId, String docName, String docType, String uploadedBy, String expiryDate) {
        OwnershipDocument doc = new OwnershipDocument();
        doc.setId("doc-" + System.currentTimeMillis());
        doc.setEntityType(entityType != null ? entityType : "Collateral");
        doc.setEntityId(entityId);
        
        // If entityType is Collateral, try to find by ID or Code
        if ("Collateral".equalsIgnoreCase(entityType)) {
            Optional<Collateral> colOpt = collateralRepository.findById(entityId);
            if (colOpt.isEmpty()) {
                colOpt = collateralRepository.findByCode(entityId);
            }
            if (colOpt.isPresent()) {
                doc.setCollateralId(colOpt.get().getId());
                doc.setEntityId(colOpt.get().getId());
            } else {
                doc.setCollateralId(null);
            }
        } else {
            doc.setCollateralId(null);
        }

        doc.setName(docName != null ? docName : "Document_" + doc.getId());
        doc.setType(docType != null ? docType : "Title Deed");
        doc.setVerificationStatus("Verified");
        doc.setUploadedBy(uploadedBy != null ? uploadedBy : "MGRCOLLDOC");
        doc.setUploadedAt(LocalDateTime.now().toString());
        doc.setUploadDate(LocalDateTime.now().toString());
        doc.setExpiryDate(expiryDate);
        doc.setFileUrl("/api/documents/download/" + doc.getId());
        doc.setStatus("Active");
        doc.setVersion(1);
        ownershipDocumentRepository.save(doc);

        logAudit(uploadedBy, "MGRCOLLDOC", "UPLOAD_DOCUMENT", "Document", doc.getId(), "Name", "None", docName, "Uploaded " + docType + " for " + entityType + " " + entityId);
        
        sendNotification("Email", "DMS_DOCUMENT_UPLOADED", "colldoc@cims-bank.et", "Collateral Documentation Dept", "Document Uploaded: " + doc.getType(), "A new " + doc.getType() + " (" + doc.getName() + ") has been uploaded and verified in the DMS repository for " + entityType + " (" + entityId + ").", "Document", doc.getId());
        
        return doc;
    }

    // --- Exception Detection Engine ---
    public void scanAndGenerateExceptions() {
        // 1. Scan Expired Policies
        LocalDate today = LocalDate.now();
        List<InsurancePolicy> policies = insurancePolicyRepository.findAll();
        for (InsurancePolicy p : policies) {
            if ("Active".equalsIgnoreCase(p.getStatus()) && p.getExpiryDate() != null) {
                try {
                    LocalDate exp = LocalDate.parse(p.getExpiryDate().substring(0, 10));
                    if (exp.isBefore(today)) {
                        String excId = "exc-exp-" + p.getId();
                        if (cimsExceptionRepository.findById(excId).isEmpty()) {
                            CimsException exc = new CimsException();
                            exc.setId(excId);
                            exc.setExceptionType("Expired Policy");
                            exc.setEntityType("Insurance Policy");
                            exc.setEntityId(p.getId());
                            exc.setSeverity("Critical");
                            exc.setDescription("Policy " + p.getPolicyNumber() + " expired on " + p.getExpiryDate() + " and remains unresolved.");
                            exc.setStatus("Open");
                            exc.setAssignedToRole("BRMGR");
                            cimsExceptionRepository.save(exc);
                        }
                    }
                } catch (Exception ignored) {}
            }
        }

        // 2. Scan Underinsured Collateral
        List<Collateral> collaterals = collateralRepository.findAll();
        for (Collateral c : collaterals) {
            if ("Underinsured".equalsIgnoreCase(c.getInsuranceStatus()) || "Under-Insured".equalsIgnoreCase(c.getStatus())) {
                String excId = "exc-under-" + c.getId();
                if (cimsExceptionRepository.findById(excId).isEmpty()) {
                    CimsException exc = new CimsException();
                    exc.setId(excId);
                    exc.setExceptionType("Underinsured Collateral");
                    exc.setEntityType("Collateral");
                    exc.setEntityId(c.getId());
                    exc.setSeverity("High");
                    exc.setDescription("Collateral " + c.getCode() + " has net insurance coverage of " + String.format("%.1f", c.getNetInsuranceCoveragePct()) + "% (below 100% threshold).");
                    exc.setStatus("Open");
                    exc.setAssignedToRole("CRO");
                    cimsExceptionRepository.save(exc);
                }
            }
        }
    }

    public void resolveException(String exceptionId, String correctiveAction, String resolutionNotes, String userId) {
        Optional<CimsException> excOpt = cimsExceptionRepository.findById(exceptionId);
        if (excOpt.isPresent()) {
            CimsException exc = excOpt.get();
            exc.setStatus("Resolved");
            exc.setCorrectiveAction(correctiveAction);
            exc.setResolutionNotes(resolutionNotes);
            exc.setResolvedAt(LocalDateTime.now().toString());
            exc.setResolvedBy(userId);
            cimsExceptionRepository.save(exc);
            logAudit(userId, "COMPLIANCE", "RESOLVE_EXCEPTION", "Exception", exceptionId, "Status", "Open", "Resolved", resolutionNotes);
        }
    }

    public void escalateException(String exceptionId, String escalationRole, String userId) {
        Optional<CimsException> excOpt = cimsExceptionRepository.findById(exceptionId);
        if (excOpt.isPresent()) {
            CimsException exc = excOpt.get();
            exc.setStatus("Escalated");
            exc.setAssignedToRole(escalationRole != null ? escalationRole : "DISTDIR");
            cimsExceptionRepository.save(exc);
            logAudit(userId, "COMPLIANCE", "ESCALATE_EXCEPTION", "Exception", exceptionId, "Status", "Open", "Escalated", "Escalated to " + exc.getAssignedToRole());
        }
    }
}
