package com.bank.cims.service;

import com.bank.cims.model.Customer;
import com.bank.cims.model.LoanAccount;
import com.bank.cims.repository.CustomerRepository;
import com.bank.cims.repository.LoanAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

@Service
@Transactional
public class CbsSyncService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private LoanAccountRepository loanAccountRepository;

    public void processCustomerMasterSync(Customer customer) {
        customerRepository.save(customer);
    }

    public void processLoanFacilitySync(LoanAccount loan) {
        loanAccountRepository.save(loan);
    }

    public Map<String, Object> getCbsSyncStatus() {
        Map<String, Object> status = new HashMap<>();
        status.put("cbsConnected", true);
        status.put("syncMode", "Real-Time Webhooks & Daily Batch Reconciliation");
        status.put("lastSyncTimestamp", java.time.LocalDateTime.now().toString());
        status.put("syncedCustomersCount", customerRepository.count());
        status.put("syncedLoansCount", loanAccountRepository.count());
        return status;
    }
}
