package com.bank.cims.controller;

import com.bank.cims.model.*;
import com.bank.cims.repository.*;
import com.bank.cims.service.CimsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/workflow")
@CrossOrigin(origins = "*")
public class WorkflowController {

    @Autowired
    private WorkflowTaskRepository workflowTaskRepository;

    @Autowired
    private ApprovalHistoryRepository approvalHistoryRepository;

    @Autowired
    private DelegationRepository delegationRepository;

    @Autowired
    private CimsService cimsService;

    @GetMapping("/tasks")
    public ResponseEntity<List<WorkflowTask>> getTasks(
            @RequestParam(required = false) String role,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String makerId) {
        
        if (status != null && !status.isBlank()) {
            return ResponseEntity.ok(workflowTaskRepository.findByStatus(status));
        }
        if (makerId != null && !makerId.isBlank()) {
            return ResponseEntity.ok(workflowTaskRepository.findByMakerId(makerId));
        }
        return ResponseEntity.ok(workflowTaskRepository.findAll());
    }

    @PostMapping("/tasks/{taskId}/approve")
    public ResponseEntity<Map<String, Object>> approveTask(
            @PathVariable String taskId,
            @RequestParam(required = false, defaultValue = "BRMGR_USER") String userId,
            @RequestParam(required = false, defaultValue = "BRMGR") String role,
            @RequestParam(required = false, defaultValue = "Approved by checker") String comments) {
        try {
            cimsService.approveWorkflowTask(taskId, userId, role, comments);
            return ResponseEntity.ok(Map.of("success", true, "message", "Task " + taskId + " approved."));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(403).body(Map.of("success", false, "error", e.getMessage()));
        }
    }

    @PostMapping("/tasks/{taskId}/reject")
    public ResponseEntity<Map<String, Object>> rejectTask(
            @PathVariable String taskId,
            @RequestParam(required = false, defaultValue = "BRMGR_USER") String userId,
            @RequestParam(required = false, defaultValue = "BRMGR") String role,
            @RequestParam(required = false, defaultValue = "Rejected by checker") String comments) {
        try {
            cimsService.rejectWorkflowTask(taskId, userId, role, comments);
            return ResponseEntity.ok(Map.of("success", true, "message", "Task " + taskId + " rejected."));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(403).body(Map.of("success", false, "error", e.getMessage()));
        }
    }

    @PostMapping("/tasks/{taskId}/return")
    public ResponseEntity<Map<String, Object>> returnTask(
            @PathVariable String taskId,
            @RequestParam(required = false, defaultValue = "BRMGR_USER") String userId,
            @RequestParam(required = false, defaultValue = "BRMGR") String role,
            @RequestParam(required = false, defaultValue = "Please review and correct submitted data.") String correctionNote) {
        try {
            cimsService.returnWorkflowTask(taskId, userId, role, correctionNote);
            return ResponseEntity.ok(Map.of("success", true, "message", "Task " + taskId + " returned to maker for correction."));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(403).body(Map.of("success", false, "error", e.getMessage()));
        }
    }

    @PostMapping("/bulk-approve")
    public ResponseEntity<Map<String, Object>> bulkApprove(
            @RequestBody List<String> taskIds,
            @RequestParam(required = false, defaultValue = "BRMGR_USER") String userId,
            @RequestParam(required = false, defaultValue = "BRMGR") String role,
            @RequestParam(required = false, defaultValue = "Bulk approved by checker") String comments) {
        int approved = 0;
        for (String id : taskIds) {
            try {
                cimsService.approveWorkflowTask(id, userId, role, comments);
                approved++;
            } catch (IllegalStateException ignored) {
            }
        }
        return ResponseEntity.ok(Map.of("success", true, "approvedCount", approved));
    }

    @GetMapping("/tasks/{taskId}/history")
    public ResponseEntity<List<ApprovalHistory>> getTaskHistory(@PathVariable String taskId) {
        return ResponseEntity.ok(approvalHistoryRepository.findByWorkflowTaskIdOrderByDecidedAtDesc(taskId));
    }

    // --- Delegations ---
    @GetMapping("/delegations")
    public ResponseEntity<List<Delegation>> getDelegations() {
        return ResponseEntity.ok(delegationRepository.findAll());
    }

    @PostMapping("/delegations")
    public ResponseEntity<Delegation> createDelegation(@RequestBody Delegation delegation) {
        if (delegation.getId() == null || delegation.getId().isBlank()) {
            delegation.setId("del-" + UUID.randomUUID().toString().substring(0, 8));
        }
        delegation.setStatus("Active");
        return ResponseEntity.ok(delegationRepository.save(delegation));
    }

    @PostMapping("/delegations/{id}/revoke")
    public ResponseEntity<Map<String, Object>> revokeDelegation(@PathVariable String id) {
        delegationRepository.findById(id).ifPresent(d -> {
            d.setStatus("Revoked");
            delegationRepository.save(d);
        });
        return ResponseEntity.ok(Map.of("success", true, "message", "Delegation revoked."));
    }
}
