package com.bank.cims.controller;

import com.bank.cims.model.Customer;
import com.bank.cims.model.LoanAccount;
import com.bank.cims.service.CbsSyncService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/cbs")
@CrossOrigin(origins = "*")
public class CbsSyncController {

    @Autowired
    private CbsSyncService cbsSyncService;

    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getSyncStatus() {
        return ResponseEntity.ok(cbsSyncService.getCbsSyncStatus());
    }

    @PostMapping("/webhook/customer")
    public ResponseEntity<String> syncCustomer(@RequestBody Customer customer) {
        cbsSyncService.processCustomerMasterSync(customer);
        return ResponseEntity.ok("Customer master synchronized cleanly.");
    }

    @PostMapping("/webhook/loan")
    public ResponseEntity<String> syncLoan(@RequestBody LoanAccount loan) {
        cbsSyncService.processLoanFacilitySync(loan);
        return ResponseEntity.ok("Loan facility synchronized cleanly.");
    }
}
