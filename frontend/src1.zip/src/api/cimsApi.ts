import {
  Customer,
  LoanAccount,
  Collateral,
  LoanCollateralLink,
  InsurancePolicy,
  PolicyEndorsement,
  OwnershipDocument,
  WorkflowTask,
  CimsException,
  NotificationItem,
  NotificationTemplate,
  AuditLog,
  BusinessSegment,
  Branch,
  RolePermission,
  ApprovalHierarchyConfig,
  ReminderSchedule,
  ScheduledReport,
  ApprovedInsurer,
  CollateralTaxonomy,
  MandatoryDocumentRule,
  HolidayCalendar,
  SystemParameter,
  CbsCustomer,
  CbsFacility,
  CbsCollateral,
  CbsSyncLog,
  Delegation,
} from '../types';

const API_BASE = '/api';

export interface FullCimsState {
  customers: Customer[];
  facilities: LoanAccount[];
  loans: LoanAccount[];
  collaterals: Collateral[];
  links: LoanCollateralLink[];
  policies: InsurancePolicy[];
  endorsements: PolicyEndorsement[];
  documents: OwnershipDocument[];
  templates: NotificationTemplate[];
  notifications: NotificationItem[];
  auditLogs: AuditLog[];
  exceptions: CimsException[];
  segments: BusinessSegment[];
  branches: Branch[];
  users: any[];
  rolePermissions: RolePermission[];
  workflowTasks: WorkflowTask[];
  approvalHistories: any[];
  delegations: Delegation[];
  approvalConfigs: ApprovalHierarchyConfig[];
  reminderSchedules: ReminderSchedule[];
  scheduledReports: ScheduledReport[];
  insurers: ApprovedInsurer[];
  taxonomies: CollateralTaxonomy[];
  mandatoryDocRules: MandatoryDocumentRule[];
  holidayCalendars: HolidayCalendar[];
  systemParameters: SystemParameter[];
  cbsSyncLogs: CbsSyncLog[];
  cbsSync: any;
  systemDate: string;
}

export const cimsApi = {
  async fetchFullState(): Promise<FullCimsState> {
    const res = await fetch(`${API_BASE}/state`);
    if (!res.ok) throw new Error('Failed to fetch system state');
    return res.json();
  },

  // Convenience entity getters (queries state or individual endpoints)
  async getCustomers(): Promise<Customer[]> {
    try {
      const state = await this.fetchFullState();
      return state.customers || [];
    } catch {
      return [];
    }
  },

  async getFacilities(): Promise<LoanAccount[]> {
    try {
      const state = await this.fetchFullState();
      return state.facilities || state.loans || [];
    } catch {
      return [];
    }
  },

  async getCollaterals(): Promise<Collateral[]> {
    try {
      const state = await this.fetchFullState();
      return state.collaterals || [];
    } catch {
      return [];
    }
  },

  async getLinks(): Promise<LoanCollateralLink[]> {
    try {
      const state = await this.fetchFullState();
      return state.links || [];
    } catch {
      return [];
    }
  },

  async getPolicies(): Promise<InsurancePolicy[]> {
    try {
      const state = await this.fetchFullState();
      return state.policies || [];
    } catch {
      return [];
    }
  },

  async getEndorsements(): Promise<PolicyEndorsement[]> {
    try {
      const state = await this.fetchFullState();
      return state.endorsements || [];
    } catch {
      return [];
    }
  },

  async getDocuments(): Promise<OwnershipDocument[]> {
    try {
      const state = await this.fetchFullState();
      return state.documents || [];
    } catch {
      return [];
    }
  },

  async getExceptions(): Promise<CimsException[]> {
    try {
      const state = await this.fetchFullState();
      return state.exceptions || [];
    } catch {
      return [];
    }
  },

  async getNotifications(): Promise<NotificationItem[]> {
    try {
      const state = await this.fetchFullState();
      return state.notifications || [];
    } catch {
      return [];
    }
  },

  async getAuditLogs(): Promise<AuditLog[]> {
    try {
      const state = await this.fetchFullState();
      return state.auditLogs || [];
    } catch {
      return [];
    }
  },

  async getWorkflowTasks(role?: string, status?: string): Promise<WorkflowTask[]> {
    try {
      const params = new URLSearchParams();
      if (role) params.set('role', role);
      if (status) params.set('status', status);
      const res = await fetch(`${API_BASE}/workflow/tasks?${params.toString()}`);
      if (res.ok) return await res.json();
      const state = await this.fetchFullState();
      return state.workflowTasks || [];
    } catch {
      return [];
    }
  },

  async getDelegations(): Promise<Delegation[]> {
    try {
      const state = await this.fetchFullState();
      return state.delegations || [];
    } catch {
      return [];
    }
  },

  async getSegments(): Promise<BusinessSegment[]> {
    try {
      const state = await this.fetchFullState();
      return state.segments || [];
    } catch {
      return [];
    }
  },

  async getBranches(): Promise<Branch[]> {
    try {
      const state = await this.fetchFullState();
      return state.branches || [];
    } catch {
      return [];
    }
  },

  async getPermissions(): Promise<RolePermission[]> {
    try {
      const state = await this.fetchFullState();
      return state.rolePermissions || [];
    } catch {
      return [];
    }
  },

  async getApprovalConfigs(): Promise<ApprovalHierarchyConfig[]> {
    try {
      const state = await this.fetchFullState();
      return state.approvalConfigs || [];
    } catch {
      return [];
    }
  },

  async getReminderSchedules(): Promise<ReminderSchedule[]> {
    try {
      const state = await this.fetchFullState();
      return state.reminderSchedules || [];
    } catch {
      return [];
    }
  },

  async getScheduledReports(): Promise<ScheduledReport[]> {
    try {
      const state = await this.fetchFullState();
      return state.scheduledReports || [];
    } catch {
      return [];
    }
  },

  async getApprovedInsurers(): Promise<ApprovedInsurer[]> {
    try {
      const state = await this.fetchFullState();
      return state.insurers || [];
    } catch {
      return [];
    }
  },

  async getTaxonomies(): Promise<CollateralTaxonomy[]> {
    try {
      const state = await this.fetchFullState();
      return state.taxonomies || [];
    } catch {
      return [];
    }
  },

  async getMandatoryDocRules(): Promise<MandatoryDocumentRule[]> {
    try {
      const state = await this.fetchFullState();
      return state.mandatoryDocRules || [];
    } catch {
      return [];
    }
  },

  async getHolidayCalendars(): Promise<HolidayCalendar[]> {
    try {
      const state = await this.fetchFullState();
      return state.holidayCalendars || [];
    } catch {
      return [];
    }
  },

  async getSystemParameters(): Promise<SystemParameter[]> {
    try {
      const state = await this.fetchFullState();
      return state.systemParameters || [];
    } catch {
      return [];
    }
  },

  // CBS Simulator
  async getCbsCustomers(): Promise<CbsCustomer[]> {
    const res = await fetch(`${API_BASE}/cbs-sim/customers`);
    return res.ok ? res.json() : [];
  },

  async saveCbsCustomer(cust: Partial<CbsCustomer>): Promise<CbsCustomer> {
    const res = await fetch(`${API_BASE}/cbs-sim/customers`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cust),
    });
    return res.json();
  },

  async getCbsFacilities(): Promise<CbsFacility[]> {
    const res = await fetch(`${API_BASE}/cbs-sim/facilities`);
    return res.ok ? res.json() : [];
  },

  async saveCbsFacility(fac: Partial<CbsFacility>): Promise<CbsFacility> {
    const res = await fetch(`${API_BASE}/cbs-sim/facilities`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(fac),
    });
    return res.json();
  },

  async getCbsCollaterals(): Promise<CbsCollateral[]> {
    const res = await fetch(`${API_BASE}/cbs-sim/collaterals`);
    return res.ok ? res.json() : [];
  },

  async saveCbsCollateral(col: Partial<CbsCollateral>): Promise<CbsCollateral> {
    const res = await fetch(`${API_BASE}/cbs-sim/collaterals`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(col),
    });
    return res.json();
  },

  async syncCbsEntity(entityType: string, id: string, userId = 'SYSADMIN'): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${API_BASE}/cbs-integration/sync/${entityType}/${id}?userId=${userId}`, {
      method: 'POST',
    });
    return res.json();
  },

  async syncAllPending(userId = 'SYSADMIN'): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${API_BASE}/cbs-integration/sync-all?userId=${userId}`, {
      method: 'POST',
    });
    return res.json();
  },

  async getCbsSyncLogs(): Promise<CbsSyncLog[]> {
    const res = await fetch(`${API_BASE}/cbs-sim/sync-logs`);
    return res.ok ? res.json() : [];
  },

  // Customer Management
  async registerCustomer(cust: Partial<Customer>, userId = 'CRO_USER'): Promise<any> {
    const res = await fetch(`${API_BASE}/customers/add?userId=${userId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cust),
    });
    return res.json();
  },

  // Collateral Management
  async createCollateral(col: Partial<Collateral>, userId = 'CRO_USER'): Promise<any> {
    const res = await fetch(`${API_BASE}/collateral/register-native?userId=${userId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(col),
    });
    return res.json();
  },

  async addFacilityLink(loanId: string, collateralId: string, amount: number): Promise<any> {
    const res = await fetch(`${API_BASE}/collateral/link-loan?loanId=${loanId}&collateralId=${collateralId}&amount=${amount}`, {
      method: 'POST',
    });
    return res.json();
  },

  async removeFacilityLink(linkId: string): Promise<any> {
    const res = await fetch(`${API_BASE}/collateral/unlink-loan?linkId=${linkId}`, {
      method: 'POST',
    });
    return res.json();
  },

  async validateReleaseCollateral(collateralId: string): Promise<{ canRelease: boolean; pendingExposure: number; activeLoans: string[]; message: string }> {
    const res = await fetch(`${API_BASE}/collateral/validate-release?collateralId=${collateralId}`);
    return res.json();
  },

  async transferCollateralSegment(collateralId: string, destSegment: string, reason: string, userId = 'CRO_USER'): Promise<any> {
    const res = await fetch(`${API_BASE}/collateral/transfer-segment?collateralId=${collateralId}&destSegment=${encodeURIComponent(destSegment)}&reason=${encodeURIComponent(reason)}&userId=${userId}`, {
      method: 'POST',
    });
    return res.json();
  },

  // Policy Lifecycle
  async createPolicyDraft(policy: Partial<InsurancePolicy>, userId = 'CRO_USER'): Promise<any> {
    const res = await fetch(`${API_BASE}/policies/add?userId=${userId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(policy),
    });
    return res.json();
  },

  async submitPolicy(policyId: string, userId = 'CRO_USER'): Promise<any> {
    const res = await fetch(`${API_BASE}/policies/submit?policyId=${policyId}&userId=${userId}`, {
      method: 'POST',
    });
    return res.json();
  },

  async amendPolicy(policyId: string, policy: Partial<InsurancePolicy>, userId = 'CRO_USER'): Promise<any> {
    const res = await fetch(`${API_BASE}/policies/amend?policyId=${policyId}&userId=${userId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(policy),
    });
    return res.json();
  },

  async renewPolicy(policyId: string, newAmount: number, newPremium: number, newExpiryDate: string, userId = 'CRO_USER'): Promise<any> {
    const res = await fetch(`${API_BASE}/policies/renew?policyId=${policyId}&newAmount=${newAmount}&newPremium=${newPremium}&newExpiryDate=${newExpiryDate}&userId=${userId}`, {
      method: 'POST',
    });
    return res.json();
  },

  // Workflow / Dual Control
  async approveWorkflowTask(taskId: string, comments = 'Approved by Checker', userId = 'BRMGR_USER', role = 'BRMGR'): Promise<any> {
    const res = await fetch(`${API_BASE}/workflow/tasks/${taskId}/approve?userId=${userId}&role=${role}&comments=${encodeURIComponent(comments)}`, {
      method: 'POST',
    });
    return res.json();
  },

  async rejectWorkflowTask(taskId: string, comments: string, userId = 'BRMGR_USER', role = 'BRMGR'): Promise<any> {
    const res = await fetch(`${API_BASE}/workflow/tasks/${taskId}/reject?userId=${userId}&role=${role}&comments=${encodeURIComponent(comments)}`, {
      method: 'POST',
    });
    return res.json();
  },

  async returnWorkflowTask(taskId: string, correctionNote: string, userId = 'BRMGR_USER', role = 'BRMGR'): Promise<any> {
    const res = await fetch(`${API_BASE}/workflow/tasks/${taskId}/return?userId=${userId}&role=${role}&correctionNote=${encodeURIComponent(correctionNote)}`, {
      method: 'POST',
    });
    return res.json();
  },

  async bulkApproveWorkflowTasks(taskIds: string[], comments = 'Bulk approved', userId = 'BRMGR_USER', role = 'BRMGR'): Promise<any> {
    const res = await fetch(`${API_BASE}/workflow/bulk-approve?userId=${userId}&role=${role}&comments=${encodeURIComponent(comments)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(taskIds),
    });
    return res.json();
  },

  async createDelegation(delegation: Partial<Delegation>): Promise<Delegation> {
    const res = await fetch(`${API_BASE}/workflow/delegations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(delegation),
    });
    return res.json();
  },

  async revokeDelegation(id: string): Promise<any> {
    const res = await fetch(`${API_BASE}/workflow/delegations/${id}/revoke`, {
      method: 'POST',
    });
    return res.json();
  },

  // Exceptions
  async triggerPortfolioScan(): Promise<any> {
    const res = await fetch(`${API_BASE}/exceptions/scan-now`, { method: 'POST' });
    return res.json();
  },

  async resolveException(id: string, correctiveAction: string, resolutionNotes: string, userId = 'COMPLIANCE_USER'): Promise<any> {
    const res = await fetch(`${API_BASE}/exceptions/${id}/resolve?correctiveAction=${encodeURIComponent(correctiveAction)}&resolutionNotes=${encodeURIComponent(resolutionNotes)}&userId=${userId}`, {
      method: 'POST',
    });
    return res.json();
  },

  async escalateException(id: string, escalationRole: string, userId = 'COMPLIANCE_USER'): Promise<any> {
    const res = await fetch(`${API_BASE}/exceptions/${id}/escalate?escalationRole=${escalationRole}&userId=${userId}`, {
      method: 'POST',
    });
    return res.json();
  },

  // Documents
  async uploadDocument(entityType: string, entityId: string, docName: string, docType: string, expiryDate?: string, userId = 'COLLDOCOFF_USER'): Promise<any> {
    const params = new URLSearchParams({
      entityType,
      entityId,
      docName,
      docType,
      uploadedBy: userId,
    });
    if (expiryDate) params.set('expiryDate', expiryDate);
    const res = await fetch(`${API_BASE}/documents/upload?${params.toString()}`, {
      method: 'POST',
    });
    return res.json();
  },

  // Admin Config
  async saveSegment(seg: Partial<BusinessSegment>, userId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/segments/add?userId=${userId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(seg),
    });
    return res.json();
  },

  async saveUser(user: any, adminUserId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/users/save?adminUserId=${adminUserId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(user),
    });
    return res.json();
  },

  async saveBranch(branch: Partial<Branch>, adminUserId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/branches/save?adminUserId=${adminUserId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(branch),
    });
    return res.json();
  },

  async saveApprovalConfig(config: Partial<ApprovalHierarchyConfig>, adminUserId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/approval-configs/save?adminUserId=${adminUserId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    });
    return res.json();
  },

  async saveReminderSchedule(schedule: Partial<ReminderSchedule>, adminUserId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/reminder-schedules/save?adminUserId=${adminUserId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(schedule),
    });
    return res.json();
  },

  async saveScheduledReport(report: Partial<ScheduledReport>, adminUserId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/scheduled-reports/save?adminUserId=${adminUserId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(report),
    });
    return res.json();
  },

  async saveSystemParameter(param: Partial<SystemParameter>, adminUserId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/parameters/save?userId=${adminUserId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(param),
    });
    return res.json();
  },

  async saveApprovedInsurer(insurer: Partial<ApprovedInsurer>, adminUserId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/insurers/save?adminUserId=${adminUserId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(insurer),
    });
    return res.json();
  },

  async saveRolePermission(permission: Partial<RolePermission>, adminUserId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/permissions/save?adminUserId=${adminUserId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(permission),
    });
    return res.json();
  },

  async saveRolePermissionsBatch(permissions: RolePermission[], adminUserId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/permissions/save-batch?adminUserId=${adminUserId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(permissions),
    });
    return res.json();
  },

  async saveCollateralTaxonomy(taxonomy: Partial<CollateralTaxonomy>, adminUserId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/taxonomy/save?userId=${adminUserId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(taxonomy),
    });
    return res.json();
  },

  async saveMandatoryDocRule(rule: Partial<MandatoryDocumentRule>, adminUserId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/document-rules/save?userId=${adminUserId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(rule),
    });
    return res.json();
  },

  async saveHolidayCalendar(holiday: Partial<HolidayCalendar>, adminUserId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/holidays/save?userId=${adminUserId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(holiday),
    });
    return res.json();
  },

  async toggleSegmentStatus(segmentId: string, active: boolean, userId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/segments/toggle-status?segmentId=${segmentId}&active=${active}&userId=${userId}`, {
      method: 'POST',
    });
    return res.json();
  },

  async toggleUserStatus(userId: string, active: boolean, adminUserId = 'SYSADMIN'): Promise<any> {
    const res = await fetch(`${API_BASE}/admin/users/${userId}/toggle-status?active=${active}&adminUserId=${adminUserId}`, {
      method: 'POST',
    });
    return res.json();
  },
};
