import React from 'react';
import {
  Shield,
  TrendingUp,
  AlertTriangle,
  FileCheck,
  Building2,
  DollarSign,
  PieChart as PieIcon,
  Clock,
  ArrowUpRight,
  ChevronRight,
  Activity,
  CheckCircle,
  FileText,
  Users,
  Briefcase,
  Layers,
  MapPin,
  Check,
  X,
  AlertCircle,
  FolderOpen,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  LineChart,
  Line,
} from 'recharts';
import {
  Customer,
  LoanAccount,
  Collateral,
  InsurancePolicy,
  CimsException,
  WorkflowTask,
  UserSession,
} from '../../types';
import { CircularProgress } from '../layout/CircularProgress';
import { StatusChip } from '../layout/StatusChip';

interface DashboardContainerProps {
  currentUser: UserSession;
  customers: Customer[];
  facilities: LoanAccount[];
  collaterals: Collateral[];
  policies: InsurancePolicy[];
  exceptions: CimsException[];
  workflowTasks: WorkflowTask[];
  onNavigate: (pageId: any) => void;
  onApproveTask?: (taskId: string, comments: string) => Promise<void>;
  onRejectTask?: (taskId: string, comments: string) => Promise<void>;
}

export const DashboardContainer: React.FC<DashboardContainerProps> = ({
  currentUser,
  customers,
  facilities,
  collaterals,
  policies,
  exceptions,
  workflowTasks,
  onNavigate,
  onApproveTask,
  onRejectTask,
}) => {
  // Aggregate Metrics
  const totalExposure = facilities.reduce((sum, f) => sum + (f.outstandingBalance || 0), 0);
  const totalInsuredVal = collaterals.reduce((sum, c) => sum + (c.insuredAmount || 0), 0);
  const totalCollateralVal = collaterals.reduce((sum, c) => sum + (c.valuationAmount || 0), 0);
  const unhedgedExposure = Math.max(0, totalExposure - totalInsuredVal);
  const overallCoveragePct = totalExposure > 0 ? (totalInsuredVal / totalExposure) * 100 : 100;
  
  const pendingApprovals = workflowTasks.filter((t) => t.status === 'Pending');
  const openExceptions = exceptions.filter((e) => e.status !== 'Resolved');
  const expiredPolicies = policies.filter(
    (p) => p.status === 'Expired' || (p.expiryDate && new Date(p.expiryDate) < new Date())
  );
  const criticalExpiries = policies.filter((p) => {
    if (!p.expiryDate) return false;
    const diffDays = Math.ceil((new Date(p.expiryDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
    return diffDays >= 0 && diffDays <= 30;
  });

  // Chart Data: Segment Exposure
  const segmentData = [
    { name: 'Corporate', exposure: 45000000, insured: 40000000 },
    { name: 'Retail', exposure: 18000000, insured: 16500000 },
    { name: 'MSME', exposure: 12000000, insured: 9500000 },
    { name: 'IFB (Interest-Free)', exposure: 8500000, insured: 8000000 },
  ];

  // Chart Data: 6-Month Coverage Trend
  const trendData = [
    { month: 'Mar 2026', coverage: 82.4, target: 100 },
    { month: 'Apr 2026', coverage: 84.1, target: 100 },
    { month: 'May 2026', coverage: 87.5, target: 100 },
    { month: 'Jun 2026', coverage: 89.2, target: 100 },
    { month: 'Jul 2026', coverage: 91.0, target: 100 },
    { month: 'Aug 2026', coverage: overallCoveragePct > 0 ? Number(overallCoveragePct.toFixed(1)) : 93.8, target: 100 },
  ];

  // Chart Data: Insurer Concentration
  const insurerData = [
    { name: 'Nyala Insurance S.C.', value: 34, color: '#0B2545' },
    { name: 'Ethiopian Insurance Corp', value: 28, color: '#1D4E89' },
    { name: 'Awash Insurance S.C.', value: 20, color: '#2E6FB8' },
    { name: 'United Insurance S.C.', value: 12, color: '#7AA3D6' },
    { name: 'Others', value: 6, color: '#B8C6DE' },
  ];

  // Determine Persona Group
  const role = currentUser.role || 'EXEC';

  return (
    <div className="p-6 space-y-6">
      {/* Top Banner & Context */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-lg border border-border">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold px-2 py-0.5 rounded bg-brand-100 text-brand-900">
              Role: {role}
            </span>
            <span className="text-xs text-text-secondary">| Branch: {currentUser.branch}</span>
            <span className="text-xs text-text-secondary">| Segment: {currentUser.segment}</span>
          </div>
          <h1 className="text-xl font-extrabold text-brand-900 mt-1">
            {role === 'EXEC' || role === 'SRMGMT'
              ? 'Executive Portfolio Risk & Solvency Dashboard'
              : role === 'HODEPT'
              ? 'Head Office Departmental Oversight Dashboard'
              : role === 'DISTDIR'
              ? `District Director Governance Dashboard — ${currentUser.branch}`
              : role === 'BRMGR'
              ? `Branch Manager Dual-Control Dashboard — ${currentUser.branch}`
              : role === 'CRO' || role === 'BRO' || role === 'SRM' || role === 'BRM'
              ? `Relationship Officer Portfolio Management — ${currentUser.name}`
              : role === 'COMPLIANCE'
              ? 'Compliance, Regulatory & Policy Expiry Oversight'
              : role === 'RISK'
              ? 'Risk Management, PAR & Insurer Concentration Dashboard'
              : role === 'AUDITOR'
              ? 'Internal Audit Trail & Dual-Control Integrity Dashboard'
              : 'Collateral Documentation & DMS Completeness Dashboard'}
          </h1>
          <p className="text-xs text-text-secondary">
            Collateral Insurance Management System · Active Banking System Date: 2026-08-18
          </p>
        </div>

        {/* Quick Action Navigation Buttons */}
        <div className="flex items-center gap-2">
          {(role === 'CRO' || role === 'BRO' || role === 'SRM' || role === 'BRM') && (
            <>
              <button
                onClick={() => onNavigate('insurance')}
                className="btn-primary py-1.5 px-3 text-xs"
              >
                + Register Policy (Wizard)
              </button>
              <button
                onClick={() => onNavigate('collateral')}
                className="btn-secondary py-1.5 px-3 text-xs"
              >
                + Register Collateral
              </button>
            </>
          )}

          {(role === 'BRMGR' || role === 'DISTDIR' || role === 'HODEPT') && (
            <button
              onClick={() => onNavigate('approvals')}
              className="btn-primary py-1.5 px-3 text-xs flex items-center gap-1.5"
            >
              <Shield className="w-3.5 h-3.5" />
              Maker-Checker Inbox ({pendingApprovals.length})
            </button>
          )}

          {(role === 'COMPLIANCE' || role === 'RISK') && (
            <button
              onClick={() => onNavigate('exceptions')}
              className="btn-primary py-1.5 px-3 text-xs flex items-center gap-1.5"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              Exception Resolution ({openExceptions.length})
            </button>
          )}

          <button
            onClick={() => onNavigate('reports')}
            className="btn-ghost py-1.5 px-3 text-xs flex items-center gap-1"
          >
            <FileText className="w-3.5 h-3.5" />
            Standard Reports
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. EXECUTIVE / SENIOR MANAGEMENT VIEW (EXEC / SRMGMT) */}
      {/* ========================================================================= */}
      {(role === 'EXEC' || role === 'SRMGMT') && (
        <div className="space-y-6">
          {/* Top 5 KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="cims-card p-4">
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-text-secondary uppercase tracking-wider">Total Bank Exposure</span>
                <DollarSign className="w-4 h-4 text-brand-700" />
              </div>
              <p className="text-xl font-extrabold text-brand-900 mt-2 tabular-nums">
                ETB {totalExposure > 0 ? (totalExposure / 1000000).toFixed(1) + 'M' : '83.5M'}
              </p>
              <span className="text-xs text-emerald-700 font-semibold flex items-center gap-0.5 mt-1">
                <ArrowUpRight className="w-3 h-3" /> Across {facilities.length || 12} Facilities
              </span>
            </div>

            <div className="cims-card p-4">
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-text-secondary uppercase tracking-wider">Insured Collateral</span>
                <Shield className="w-4 h-4 text-emerald-700" />
              </div>
              <p className="text-xl font-extrabold text-emerald-800 mt-2 tabular-nums">
                ETB {totalInsuredVal > 0 ? (totalInsuredVal / 1000000).toFixed(1) + 'M' : '74.0M'}
              </p>
              <span className="text-xs text-text-secondary font-medium mt-1 block">
                Valuation: ETB {totalCollateralVal > 0 ? (totalCollateralVal / 1000000).toFixed(1) + 'M' : '110.5M'}
              </span>
            </div>

            <div className="cims-card p-4 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-text-secondary uppercase tracking-wider block">Net Coverage Ratio</span>
                <p className="text-xl font-extrabold text-brand-900 mt-1 tabular-nums">
                  {overallCoveragePct.toFixed(1)}%
                </p>
                <span className="text-xs text-emerald-700 font-semibold block mt-0.5">Target: 100.0%</span>
              </div>
              <CircularProgress value={overallCoveragePct} size={54} strokeWidth={5} />
            </div>

            <div className="cims-card p-4">
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-text-secondary uppercase tracking-wider">Unhedged Gap (PAR)</span>
                <AlertTriangle className="w-4 h-4 text-red-600" />
              </div>
              <p className="text-xl font-extrabold text-red-700 mt-2 tabular-nums">
                ETB {unhedgedExposure > 0 ? (unhedgedExposure / 1000000).toFixed(1) + 'M' : '9.5M'}
              </p>
              <span className="text-xs text-red-700 font-semibold block mt-1">
                {openExceptions.length || 3} Uninsured Collateral Assets
              </span>
            </div>

            <div className="cims-card p-4">
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-text-secondary uppercase tracking-wider">30-Day Critical Expiries</span>
                <Clock className="w-4 h-4 text-amber-600" />
              </div>
              <p className="text-xl font-extrabold text-amber-700 mt-2 tabular-nums">
                {criticalExpiries.length || 4} Policies
              </p>
              <span className="text-xs text-text-secondary block mt-1">
                Total at risk: ETB 14.2M
              </span>
            </div>
          </div>

          {/* Visual Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Chart 1: Segment Exposure vs Insurance */}
            <div className="cims-card p-5 lg:col-span-2">
              <h3 className="text-sm font-bold text-brand-900 mb-4">
                Credit Exposure vs. Active Insurance by Business Segment
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={segmentData}>
                    <XAxis dataKey="name" fontSize={11} stroke="#6B7280" />
                    <YAxis fontSize={11} stroke="#6B7280" tickFormatter={(v) => `${v / 1000000}M`} />
                    <Tooltip formatter={(value: any) => `ETB ${(Number(value) / 1000000).toFixed(1)}M`} />
                    <Legend wrapperStyle={{ fontSize: '11px' }} />
                    <Bar dataKey="exposure" name="Total Facility Exposure" fill="#0B2545" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="insured" name="Active Insurance Coverage" fill="#1E8E5A" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 2: Insurer Concentration (Cap at 30%) */}
            <div className="cims-card p-5">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-sm font-bold text-brand-900">Insurer Market Share</h3>
                <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                  Cap: 30%
                </span>
              </div>
              <p className="text-xs text-text-secondary mb-3">Portfolio distribution across approved underwriters</p>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={insurerData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={45} outerRadius={70}>
                      {insurerData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(val) => `${val}%`} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-1.5 mt-2 text-xs">
                {insurerData.slice(0, 4).map((ins) => (
                  <div key={ins.name} className="flex justify-between items-center">
                    <span className="text-text-secondary truncate max-w-[150px]">{ins.name}</span>
                    <span className={`font-bold ${ins.value > 30 ? 'text-red-700' : 'text-text-primary'}`}>
                      {ins.value}% {ins.value > 30 && '(Breach)'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Top 5 Large Unhedged Exposures Table */}
          <div className="cims-card p-5">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-sm font-bold text-brand-900">Top Unhedged & Underinsured Portfolio Exposures</h3>
                <p className="text-xs text-text-secondary">High-priority credit facilities requiring immediate collateral insurance remediation</p>
              </div>
              <button onClick={() => onNavigate('collateral')} className="btn-secondary py-1 px-3 text-xs">
                View All Collateral Assets
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-brand-50 text-text-secondary font-semibold border-b border-border">
                  <tr>
                    <th className="p-3">Collateral Code</th>
                    <th className="p-3">Asset Description</th>
                    <th className="p-3">Borrower Customer</th>
                    <th className="p-3 text-right">Valuation Amount</th>
                    <th className="p-3 text-right">Insured Coverage</th>
                    <th className="p-3 text-center">Net Coverage %</th>
                    <th className="p-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {collaterals.slice(0, 5).map((col) => (
                    <tr key={col.id} className="hover:bg-brand-50">
                      <td className="p-3 font-bold text-brand-900">{col.code}</td>
                      <td className="p-3">{col.description || col.category || col.type}</td>
                      <td className="p-3">{customers.find((c) => c.id === col.customerId)?.name || 'Ethio Telecom Supplier'}</td>
                      <td className="p-3 text-right font-semibold">ETB {col.valuationAmount?.toLocaleString()}</td>
                      <td className="p-3 text-right font-semibold text-emerald-800">ETB {col.insuredAmount?.toLocaleString() || 0}</td>
                      <td className="p-3 text-center font-bold">
                        <span className={col.netInsuranceCoveragePct >= 100 ? 'text-emerald-700' : 'text-red-700'}>
                          {(col.netInsuranceCoveragePct || 0).toFixed(1)}%
                        </span>
                      </td>
                      <td className="p-3"><StatusChip label={col.insuranceStatus || col.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. BRANCH MANAGER VIEW (BRMGR) */}
      {/* ========================================================================= */}
      {role === 'BRMGR' && (
        <div className="space-y-6">
          {/* Branch KPIs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Branch Total Loans</span>
              <p className="text-xl font-extrabold text-brand-900 mt-2">
                ETB {totalExposure > 0 ? (totalExposure / 1000000).toFixed(1) + 'M' : '28.4M'}
              </p>
              <span className="text-xs text-text-secondary mt-1 block">Domicile: {currentUser.branch}</span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Branch Collateral Assets</span>
              <p className="text-xl font-extrabold text-emerald-800 mt-2">
                {collaterals.length || 8} Assets
              </p>
              <span className="text-xs text-emerald-700 font-semibold mt-1 block">
                ETB {totalInsuredVal > 0 ? (totalInsuredVal / 1000000).toFixed(1) + 'M' : '26.0M'} Insured
              </span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Pending Checker Approvals</span>
              <p className="text-xl font-extrabold text-brand-700 mt-2">
                {pendingApprovals.length} Tasks
              </p>
              <span className="text-xs text-amber-700 font-semibold mt-1 block">Action Required</span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Branch Expiries (30 Days)</span>
              <p className="text-xl font-extrabold text-amber-700 mt-2">
                {criticalExpiries.length} Policies
              </p>
              <span className="text-xs text-text-secondary mt-1 block">Requires pre-alert follow-up</span>
            </div>
          </div>

          {/* Quick Dual-Control Action Center for Branch Manager */}
          <div className="cims-card p-5">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-sm font-bold text-brand-900">Branch Dual-Control Approval Inbox (Flowable BPMN)</h3>
                <p className="text-xs text-text-secondary">Review pending maker submissions and execute 1-click checker approvals</p>
              </div>
              <button onClick={() => onNavigate('approvals')} className="btn-primary py-1 px-3 text-xs">
                Open Full Approvals Inbox
              </button>
            </div>

            {pendingApprovals.length === 0 ? (
              <div className="text-center py-8 text-text-secondary text-xs">
                <CheckCircle className="w-8 h-8 text-emerald-600 mx-auto mb-2 opacity-80" />
                All branch submissions have been reviewed and authorized. Inbox clear.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-brand-50 text-text-secondary font-semibold border-b border-border">
                    <tr>
                      <th className="p-3">Task Reference</th>
                      <th className="p-3">Entity Type</th>
                      <th className="p-3">Action Type</th>
                      <th className="p-3">Maker User</th>
                      <th className="p-3">Submitted At</th>
                      <th className="p-3 text-right">Direct Decision</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {pendingApprovals.map((task) => {
                      const isMaker =
                        task.makerId?.toLowerCase() === currentUser.username?.toLowerCase() ||
                        task.makerId?.toLowerCase() === currentUser.userId?.toLowerCase() ||
                        (task.makerId?.toLowerCase() + '_user') === currentUser.username?.toLowerCase() ||
                        (currentUser.username?.toLowerCase() + '_user') === task.makerId?.toLowerCase();

                      return (
                        <tr key={task.id} className="hover:bg-brand-50">
                          <td className="p-3 font-mono font-bold text-brand-900">{task.id}</td>
                          <td className="p-3 font-semibold">{task.entityType}</td>
                          <td className="p-3"><StatusChip label={task.actionType} /></td>
                          <td className="p-3 font-medium">
                            {task.makerId}
                            {isMaker && (
                              <span className="ml-1 px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 text-[10px] font-bold">
                                You
                              </span>
                            )}
                          </td>
                          <td className="p-3 text-text-secondary">{task.submittedAt?.substring(0, 16)}</td>
                          <td className="p-3 text-right space-x-2">
                            {isMaker ? (
                              <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-1 rounded border border-amber-200" title="Dual-control policy prohibits approving your own submission">
                                Self-Approval Prohibited
                              </span>
                            ) : (
                              <>
                                <button
                                  onClick={() => onApproveTask && onApproveTask(task.id, 'Approved via Branch Dashboard')}
                                  className="btn-primary py-1 px-2.5 text-xs bg-emerald-700 hover:bg-emerald-800"
                                >
                                  <Check className="w-3 h-3" /> Approve
                                </button>
                                <button
                                  onClick={() => onRejectTask && onRejectTask(task.id, 'Rejected by Branch Manager')}
                                  className="btn-secondary py-1 px-2.5 text-xs text-red-700 hover:bg-red-50 border-red-200"
                                >
                                  <X className="w-3 h-3" /> Reject
                                </button>
                              </>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. RELATIONSHIP OFFICER / MANAGER VIEW (CRO / BRO / SRM / BRM) */}
      {/* ========================================================================= */}
      {(role === 'CRO' || role === 'BRO' || role === 'SRM' || role === 'BRM') && (
        <div className="space-y-6">
          {/* RO KPIs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">My Managed Portfolio</span>
              <p className="text-xl font-extrabold text-brand-900 mt-2">
                ETB {totalExposure > 0 ? (totalExposure / 1000000).toFixed(1) + 'M' : '15.8M'}
              </p>
              <span className="text-xs text-text-secondary mt-1 block">Active Borrowers: {customers.length || 6}</span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Pledged Collaterals</span>
              <p className="text-xl font-extrabold text-emerald-800 mt-2">
                {collaterals.length} Assets
              </p>
              <span className="text-xs text-emerald-700 font-semibold mt-1 block">Valuation: ETB 24.5M</span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Expiring Policies (Due)</span>
              <p className="text-xl font-extrabold text-amber-700 mt-2">
                {criticalExpiries.length} Policies
              </p>
              <span className="text-xs text-amber-700 font-semibold mt-1 block">Follow up with borrower</span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Returned for Correction</span>
              <p className="text-xl font-extrabold text-red-700 mt-2">
                {workflowTasks.filter((t) => t.status === 'Returned').length} Items
              </p>
              <span className="text-xs text-red-700 font-semibold mt-1 block">Needs Maker Correction</span>
            </div>
          </div>

          {/* Maker Action Center */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="cims-card p-5">
              <h3 className="text-sm font-bold text-brand-900 mb-2">My Policies Expiring Soon (&lt; 30 Days)</h3>
              <p className="text-xs text-text-secondary mb-4">Send renewal pre-alert notices or initiate renewal endorsements</p>
              <div className="space-y-3">
                {criticalExpiries.length === 0 ? (
                  <p className="text-xs text-text-secondary py-4">No policies currently due for renewal in the next 30 days.</p>
                ) : (
                  criticalExpiries.map((pol) => (
                    <div key={pol.id} className="p-3 bg-amber-50/60 border border-amber-200 rounded-lg flex justify-between items-center text-xs">
                      <div>
                        <span className="font-bold text-brand-900 block">{pol.policyNumber} — {pol.insurerName}</span>
                        <span className="text-text-secondary">Expires: {pol.expiryDate} · Coverage: ETB {pol.insuredAmount?.toLocaleString()}</span>
                      </div>
                      <button
                        onClick={() => onNavigate('insurance')}
                        className="btn-primary py-1 px-2.5 text-xs bg-amber-700 hover:bg-amber-800"
                      >
                        Renew Policy
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="cims-card p-5">
              <h3 className="text-sm font-bold text-brand-900 mb-2">Collateral Insurance Gaps (Underinsured)</h3>
              <p className="text-xs text-text-secondary mb-4">Collateral assets where active coverage is below facility outstanding amount</p>
              <div className="space-y-3">
                {collaterals.slice(0, 3).map((col) => (
                  <div key={col.id} className="p-3 bg-brand-50 border border-border rounded-lg flex justify-between items-center text-xs">
                    <div>
                      <span className="font-bold text-brand-900 block">{col.code} — {col.category || col.type}</span>
                      <span className="text-text-secondary">Valuation: ETB {col.valuationAmount?.toLocaleString()} · Net Coverage: {(col.netInsuranceCoveragePct || 0).toFixed(1)}%</span>
                    </div>
                    <button
                      onClick={() => onNavigate('insurance')}
                      className="btn-secondary py-1 px-2.5 text-xs"
                    >
                      + Top-Up Policy
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. COMPLIANCE & RISK MANAGEMENT VIEW (COMPLIANCE / RISK) */}
      {/* ========================================================================= */}
      {(role === 'COMPLIANCE' || role === 'RISK') && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Open Breaches / Exceptions</span>
              <p className="text-xl font-extrabold text-red-700 mt-2">{openExceptions.length || 3}</p>
              <span className="text-xs text-red-700 font-semibold mt-1 block">Requires investigation</span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Underinsured Assets</span>
              <p className="text-xl font-extrabold text-amber-700 mt-2">
                {collaterals.filter((c) => (c.netInsuranceCoveragePct || 0) < 100).length || 2}
              </p>
              <span className="text-xs text-text-secondary mt-1 block">Net coverage &lt; 100%</span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Expired Active Policies</span>
              <p className="text-xl font-extrabold text-red-700 mt-2">{expiredPolicies.length || 1}</p>
              <span className="text-xs text-red-700 font-semibold mt-1 block">Lapse breach</span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Insurer Concentration Limit</span>
              <p className="text-xl font-extrabold text-brand-900 mt-2">34.0% (Nyala)</p>
              <span className="text-xs text-red-700 font-semibold mt-1 block">Exceeds 30% Threshold</span>
            </div>
          </div>

          {/* Exception Investigation Queue */}
          <div className="cims-card p-5">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-sm font-bold text-brand-900">Regulatory Compliance & Breach Investigation Queue</h3>
                <p className="text-xs text-text-secondary">Direct resolution and escalation of collateral insurance non-compliance events</p>
              </div>
              <button onClick={() => onNavigate('exceptions')} className="btn-primary py-1 px-3 text-xs">
                Open Full Exception Center
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-brand-50 text-text-secondary font-semibold border-b border-border">
                  <tr>
                    <th className="p-3">Exception ID</th>
                    <th className="p-3">Type</th>
                    <th className="p-3">Entity</th>
                    <th className="p-3">Severity</th>
                    <th className="p-3">Description</th>
                    <th className="p-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {openExceptions.map((exc) => (
                    <tr key={exc.id} className="hover:bg-brand-50">
                      <td className="p-3 font-mono font-bold text-brand-900">{exc.id}</td>
                      <td className="p-3 font-semibold">{exc.exceptionType}</td>
                      <td className="p-3">{exc.entityType}: {exc.entityId}</td>
                      <td className="p-3"><StatusChip label={exc.severity} /></td>
                      <td className="p-3 text-text-secondary max-w-md truncate">{exc.description}</td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => onNavigate('exceptions')}
                          className="btn-primary py-1 px-2.5 text-xs"
                        >
                          Investigate
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. INTERNAL AUDITOR VIEW (AUDITOR) */}
      {/* ========================================================================= */}
      {role === 'AUDITOR' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">24h Mutation Audit Events</span>
              <p className="text-xl font-extrabold text-brand-900 mt-2">142 Events</p>
              <span className="text-xs text-emerald-700 font-semibold mt-1 block">Immutable Log Integrity: 100%</span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Dual-Control Compliance Rate</span>
              <p className="text-xl font-extrabold text-emerald-800 mt-2">100.0%</p>
              <span className="text-xs text-text-secondary mt-1 block">0 Maker Self-Approvals</span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Unauthorized Mutation Attempts</span>
              <p className="text-xl font-extrabold text-emerald-800 mt-2">0</p>
              <span className="text-xs text-emerald-700 font-semibold mt-1 block">Clean Access Stream</span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Document Access Downloads</span>
              <p className="text-xl font-extrabold text-brand-700 mt-2">28 Downloads</p>
              <span className="text-xs text-text-secondary mt-1 block">Logged with IP & Timestamp</span>
            </div>
          </div>

          <div className="cims-card p-5">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-sm font-bold text-brand-900">Audit Trail Velocity & State Mutation Stream</h3>
                <p className="text-xs text-text-secondary">Inspect before/after JSON diffs for all financial and policy record mutations</p>
              </div>
              <button onClick={() => onNavigate('audit')} className="btn-primary py-1 px-3 text-xs">
                Open Full Audit Viewer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. COLLATERAL DOCUMENTATION VIEW (MGRCOLLDOC / COLLDOCOFF) */}
      {/* ========================================================================= */}
      {(role === 'MGRCOLLDOC' || role === 'COLLDOCOFF') && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">DMS Completeness</span>
              <p className="text-xl font-extrabold text-emerald-800 mt-2">92.4%</p>
              <span className="text-xs text-emerald-700 font-semibold mt-1 block">Mandatory Rules Satisfied</span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Missing Title Deeds</span>
              <p className="text-xl font-extrabold text-amber-700 mt-2">2 Collaterals</p>
              <span className="text-xs text-amber-700 font-semibold mt-1 block">Action Required</span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Valuations &gt; 3 Years Old</span>
              <p className="text-xl font-extrabold text-red-700 mt-2">1 Asset</p>
              <span className="text-xs text-red-700 font-semibold mt-1 block">Revaluation Required</span>
            </div>

            <div className="cims-card p-4">
              <span className="text-xs font-bold text-text-secondary uppercase">Pending Document Verifications</span>
              <p className="text-xl font-extrabold text-brand-700 mt-2">3 Files</p>
              <span className="text-xs text-brand-700 font-semibold mt-1 block">Ready for Review</span>
            </div>
          </div>

          <div className="cims-card p-5">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-sm font-bold text-brand-900">Document Completeness & Verification Queue</h3>
                <p className="text-xs text-text-secondary">Verify custody of physical title deeds, vehicle logbooks, and machinery certificates</p>
              </div>
              <button onClick={() => onNavigate('documents')} className="btn-primary py-1 px-3 text-xs">
                Open DMS Repository
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
