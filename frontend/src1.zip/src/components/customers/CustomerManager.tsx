import React, { useState } from 'react';
import { Users, Eye, Plus, ShieldCheck, CreditCard, Building2, FileCheck, FolderOpen, History } from 'lucide-react';
import { Customer, LoanAccount, Collateral, InsurancePolicy, OwnershipDocument, UserSession } from '../../types';
import { DataGrid, ColumnDef } from '../layout/DataGrid';
import { StatusChip } from '../layout/StatusChip';

interface CustomerManagerProps {
  customers: Customer[];
  facilities: LoanAccount[];
  collaterals: Collateral[];
  policies: InsurancePolicy[];
  documents: OwnershipDocument[];
  currentUser: UserSession;
  onRegisterManualCustomer: (cust: Partial<Customer>) => Promise<void>;
}

export const CustomerManager: React.FC<CustomerManagerProps> = ({
  customers,
  facilities,
  collaterals,
  policies,
  documents,
  currentUser,
  onRegisterManualCustomer,
}) => {
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [show360Modal, setShow360Modal] = useState(false);
  const [showManualRegModal, setShowManualRegModal] = useState(false);
  const [active360Tab, setActive360Tab] = useState<'overview' | 'facilities' | 'collateral' | 'policies' | 'documents'>('overview');

  const [newCust, setNewCust] = useState<Partial<Customer>>({
    cif: `CIF-${Math.floor(100000 + Math.random() * 900000)}`,
    customerType: 'Individual',
    segment: 'Corporate Banking',
    branch: currentUser.branch || 'Bole Special Branch',
    status: 'Active',
  });

  const isMakerRole = ['CRO', 'BRO', 'SRM', 'BRM', 'SYSADMIN'].includes(currentUser.role);

  const customerColumns: ColumnDef<Customer>[] = [
    { header: 'CIF', accessorKey: 'cif', sortable: true },
    { header: 'Customer Name', accessorKey: 'name', sortable: true },
    { header: 'Type', accessorKey: 'customerType' },
    { header: 'Segment', accessorKey: 'segment' },
    { header: 'Branch', accessorKey: 'branch' },
    { header: 'Phone', accessorKey: 'phone' },
    {
      header: 'Linked Facilities',
      align: 'center',
      cell: (r) => {
        const count = facilities.filter((f) => f.customerId === r.id).length;
        return <span className="font-semibold tabular-nums">{count}</span>;
      },
    },
    {
      header: 'Linked Collateral',
      align: 'center',
      cell: (r) => {
        const count = collaterals.filter((c) => c.customerId === r.id).length;
        return <span className="font-semibold tabular-nums">{count}</span>;
      },
    },
    {
      header: 'Active Policies',
      align: 'center',
      cell: (r) => {
        const custColIds = collaterals.filter((c) => c.customerId === r.id).map((c) => c.id);
        const count = policies.filter((p) => p.customerId === r.id || custColIds.includes(p.collateralId)).length;
        return <span className="font-semibold tabular-nums">{count}</span>;
      },
    },
    {
      header: 'Source',
      accessorKey: 'source',
      cell: (r) => (
        <span style={{ fontSize: '11px', color: '#5B6B82', fontWeight: 600 }}>
          {r.source === 'CBS_SIM' ? 'CBS-Synced' : 'Manual'}
        </span>
      ),
    },
    {
      header: 'Status',
      accessorKey: 'status',
      cell: (r) => <StatusChip label={r.status} />,
    },
    {
      header: 'Action',
      align: 'right',
      cell: (r) => (
        <button
          onClick={(e) => {
            e.stopPropagation();
            setSelectedCustomer(r);
            setShow360Modal(true);
          }}
          className="btn-ghost py-1 px-2 text-xs"
        >
          <Eye className="w-3.5 h-3.5" />
          360 View
        </button>
      ),
    },
  ];

  // Customer 360 linked data
  const linkedFacilities = selectedCustomer ? facilities.filter((f) => f.customerId === selectedCustomer.id) : [];
  const linkedCollaterals = selectedCustomer ? collaterals.filter((c) => c.customerId === selectedCustomer.id) : [];
  const linkedColIds = linkedCollaterals.map((c) => c.id);
  const linkedPolicies = selectedCustomer
    ? policies.filter((p) => p.customerId === selectedCustomer.id || linkedColIds.includes(p.collateralId))
    : [];
  const linkedDocs = selectedCustomer ? documents.filter((d) => d.entityId === selectedCustomer.id || linkedColIds.includes(d.entityId)) : [];

  return (
    <div className="p-6 space-y-6">
      <DataGrid
        title="Customer Master"
        subtitle="Single view of customer portfolio, facilities, collateral, and insurance policies"
        data={customers}
        columns={customerColumns}
        keyExtractor={(c) => c.id}
        onRowClick={(c) => {
          setSelectedCustomer(c);
          setShow360Modal(true);
        }}
        actions={
          isMakerRole ? (
            <button
              onClick={() => {
                setNewCust({
                  cif: `CIF-${Math.floor(100000 + Math.random() * 900000)}`,
                  customerType: 'Individual',
                  segment: 'Corporate Banking',
                  branch: currentUser.branch || 'Bole Special Branch',
                  status: 'Active',
                });
                setShowManualRegModal(true);
              }}
              className="btn-primary py-1.5 px-3 text-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              + Register Customer Manually
            </button>
          ) : undefined
        }
      />

      {/* Customer 360 Modal */}
      {show360Modal && selectedCustomer && (
        <div className="fixed inset-0 bg-brand-900/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl border border-border shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden">
            {/* Header */}
            <div className="p-5 bg-brand-900 text-white flex justify-between items-start">
              <div>
                <div className="flex items-center gap-3">
                  <h2 className="text-lg font-bold">{selectedCustomer.name}</h2>
                  <StatusChip label={selectedCustomer.status} />
                  <span className="text-xs px-2 py-0.5 rounded bg-brand-700 text-white font-medium">
                    {selectedCustomer.segment}
                  </span>
                </div>
                <div className="text-xs text-blue-200 mt-1 flex gap-4">
                  <span>CIF: {selectedCustomer.cif}</span>
                  <span>Branch: {selectedCustomer.branch}</span>
                  <span>
                    Source: {selectedCustomer.source === 'CBS_SIM' ? 'CBS-Synced (18-Aug-2026 06:00)' : 'Manually Registered'}
                  </span>
                </div>
              </div>
              <button onClick={() => setShow360Modal(false)} className="text-white hover:text-gray-300 text-lg">
                ✕
              </button>
            </div>

            {/* 360 Tabs */}
            <div className="flex border-b border-border bg-brand-50 px-6 gap-2 pt-2">
              <button
                onClick={() => setActive360Tab('overview')}
                className={`pb-2.5 px-3 text-xs font-semibold border-b-2 ${
                  active360Tab === 'overview' ? 'border-brand-900 text-brand-900' : 'border-transparent text-text-secondary'
                }`}
              >
                Overview
              </button>
              <button
                onClick={() => setActive360Tab('facilities')}
                className={`pb-2.5 px-3 text-xs font-semibold border-b-2 ${
                  active360Tab === 'facilities' ? 'border-brand-900 text-brand-900' : 'border-transparent text-text-secondary'
                }`}
              >
                Facilities ({linkedFacilities.length})
              </button>
              <button
                onClick={() => setActive360Tab('collateral')}
                className={`pb-2.5 px-3 text-xs font-semibold border-b-2 ${
                  active360Tab === 'collateral' ? 'border-brand-900 text-brand-900' : 'border-transparent text-text-secondary'
                }`}
              >
                Collateral ({linkedCollaterals.length})
              </button>
              <button
                onClick={() => setActive360Tab('policies')}
                className={`pb-2.5 px-3 text-xs font-semibold border-b-2 ${
                  active360Tab === 'policies' ? 'border-brand-900 text-brand-900' : 'border-transparent text-text-secondary'
                }`}
              >
                Insurance Policies ({linkedPolicies.length})
              </button>
              <button
                onClick={() => setActive360Tab('documents')}
                className={`pb-2.5 px-3 text-xs font-semibold border-b-2 ${
                  active360Tab === 'documents' ? 'border-brand-900 text-brand-900' : 'border-transparent text-text-secondary'
                }`}
              >
                Documents ({linkedDocs.length})
              </button>
            </div>

            {/* Tab Contents */}
            <div className="p-6 overflow-y-auto flex-1 space-y-4 text-xs">
              {active360Tab === 'overview' && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="cims-card p-4 space-y-2">
                    <h4 className="font-bold text-text-primary text-xs border-b border-border pb-1">Contact & Demographic</h4>
                    <div><span className="text-text-secondary">Customer Type:</span> <strong>{selectedCustomer.customerType}</strong></div>
                    <div><span className="text-text-secondary">National ID / Passport:</span> <strong>{selectedCustomer.nationalId || '—'}</strong></div>
                    <div><span className="text-text-secondary">Business Registration No:</span> <strong>{selectedCustomer.businessRegNo || '—'}</strong></div>
                    <div><span className="text-text-secondary">Tax Identification No (TIN):</span> <strong>{selectedCustomer.taxIdNo || '—'}</strong></div>
                    <div><span className="text-text-secondary">Phone Number:</span> <strong>{selectedCustomer.phone}</strong></div>
                    <div><span className="text-text-secondary">Email:</span> <strong>{selectedCustomer.email || '—'}</strong></div>
                  </div>
                  <div className="cims-card p-4 space-y-2">
                    <h4 className="font-bold text-text-primary text-xs border-b border-border pb-1">Banking & Risk Profile</h4>
                    <div><span className="text-text-secondary">Business Segment:</span> <strong>{selectedCustomer.segment}</strong></div>
                    <div><span className="text-text-secondary">Domicile Branch:</span> <strong>{selectedCustomer.branch}</strong></div>
                    <div><span className="text-text-secondary">Risk Rating:</span> <strong>{selectedCustomer.riskRating || 'Medium'}</strong></div>
                    <div><span className="text-text-secondary">Address:</span> <strong>{selectedCustomer.address || '—'}</strong></div>
                    <div><span className="text-text-secondary">Registration Source:</span> <strong>{selectedCustomer.source}</strong></div>
                  </div>
                </div>
              )}

              {active360Tab === 'facilities' && (
                <div className="cims-card overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-brand-50 border-b border-border text-text-secondary font-semibold">
                      <tr>
                        <th className="p-2.5">Line Code</th>
                        <th className="p-2.5">Facility Type</th>
                        <th className="p-2.5 text-right">Limit</th>
                        <th className="p-2.5 text-right">Outstanding</th>
                        <th className="p-2.5">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {linkedFacilities.map((f) => (
                        <tr key={f.id} className="hover:bg-brand-50">
                          <td className="p-2.5 font-semibold">{f.lineCode}</td>
                          <td className="p-2.5">{f.facilityType}</td>
                          <td className="p-2.5 text-right tabular-nums">
                            {f.lineCurrency} {f.approvedLimit?.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>
                          <td className="p-2.5 text-right tabular-nums">
                            {f.lineCurrency} {f.outstandingBalance?.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>
                          <td className="p-2.5"><StatusChip label={f.status} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {active360Tab === 'collateral' && (
                <div className="cims-card overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-brand-50 border-b border-border text-text-secondary font-semibold">
                      <tr>
                        <th className="p-2.5">Collateral Code</th>
                        <th className="p-2.5">Description</th>
                        <th className="p-2.5">Category</th>
                        <th className="p-2.5 text-right">Estimated Value</th>
                        <th className="p-2.5">Insurance Status</th>
                        <th className="p-2.5 text-right">Coverage %</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {linkedCollaterals.map((c) => (
                        <tr key={c.id} className="hover:bg-brand-50">
                          <td className="p-2.5 font-semibold">{c.code}</td>
                          <td className="p-2.5">{c.description}</td>
                          <td className="p-2.5">{c.category}</td>
                          <td className="p-2.5 text-right tabular-nums">
                            {c.currency || 'ETB'} {c.valuationAmount?.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>
                          <td className="p-2.5"><StatusChip label={c.insuranceStatus || c.status} /></td>
                          <td className="p-2.5 text-right font-semibold tabular-nums">
                            {(c.netInsuranceCoveragePct || 0).toFixed(1)}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {active360Tab === 'policies' && (
                <div className="cims-card overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-brand-50 border-b border-border text-text-secondary font-semibold">
                      <tr>
                        <th className="p-2.5">Policy Number</th>
                        <th className="p-2.5">Insurer</th>
                        <th className="p-2.5">Coverage Type</th>
                        <th className="p-2.5 text-right">Insured Amount</th>
                        <th className="p-2.5">Expiry Date</th>
                        <th className="p-2.5">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {linkedPolicies.map((p) => (
                        <tr key={p.id} className="hover:bg-brand-50">
                          <td className="p-2.5 font-semibold">{p.policyNumber}</td>
                          <td className="p-2.5">{p.insurerName}</td>
                          <td className="p-2.5">{p.coverageType}</td>
                          <td className="p-2.5 text-right tabular-nums">
                            ETB {p.insuredAmount?.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>
                          <td className="p-2.5">{p.expiryDate}</td>
                          <td className="p-2.5"><StatusChip label={p.status} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {active360Tab === 'documents' && (
                <div className="cims-card overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-brand-50 border-b border-border text-text-secondary font-semibold">
                      <tr>
                        <th className="p-2.5">Document Name</th>
                        <th className="p-2.5">Type</th>
                        <th className="p-2.5">Version</th>
                        <th className="p-2.5">Upload Date</th>
                        <th className="p-2.5">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {linkedDocs.map((d) => (
                        <tr key={d.id} className="hover:bg-brand-50">
                          <td className="p-2.5 font-semibold">{d.name}</td>
                          <td className="p-2.5">{d.type}</td>
                          <td className="p-2.5">v{d.version}</td>
                          <td className="p-2.5">{d.uploadDate?.substring(0, 10)}</td>
                          <td className="p-2.5"><StatusChip label={d.status} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Register Customer Manually Modal (Maker Action) */}
      {showManualRegModal && (
        <div className="fixed inset-0 bg-brand-900/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg border border-border shadow-xl max-w-lg w-full overflow-hidden">
            <div className="p-4 bg-brand-900 text-white flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold">Register Customer Manually</h3>
                <p className="text-[11px] text-blue-200">Routes to Checker Approval before activation</p>
              </div>
              <button onClick={() => setShowManualRegModal(false)} className="text-white hover:text-gray-300">✕</button>
            </div>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                await onRegisterManualCustomer(newCust);
                setShowManualRegModal(false);
              }}
              className="p-5 space-y-4 max-h-[80vh] overflow-y-auto text-xs"
            >
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-text-primary mb-1">CIF (Customer ID) (M)</label>
                  <input
                    type="text"
                    required
                    value={newCust.cif || ''}
                    onChange={(e) => setNewCust({ ...newCust, cif: e.target.value })}
                    className="w-full p-2 border border-border rounded"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-text-primary mb-1">Customer Type (M)</label>
                  <select
                    value={newCust.customerType || 'Individual'}
                    onChange={(e) => setNewCust({ ...newCust, customerType: e.target.value as any })}
                    className="w-full p-2 border border-border rounded"
                  >
                    <option value="Individual">Individual</option>
                    <option value="Business">Business</option>
                    <option value="Government">Government</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-text-primary mb-1">Full Name / Business Name (M)</label>
                <input
                  type="text"
                  required
                  value={newCust.name || ''}
                  onChange={(e) => setNewCust({ ...newCust, name: e.target.value })}
                  className="w-full p-2 border border-border rounded"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-text-primary mb-1">National ID / Passport (O)</label>
                  <input
                    type="text"
                    value={newCust.nationalId || ''}
                    onChange={(e) => setNewCust({ ...newCust, nationalId: e.target.value })}
                    className="w-full p-2 border border-border rounded"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-text-primary mb-1">Business Reg No. (O)</label>
                  <input
                    type="text"
                    value={newCust.businessRegNo || ''}
                    onChange={(e) => setNewCust({ ...newCust, businessRegNo: e.target.value })}
                    className="w-full p-2 border border-border rounded"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-text-primary mb-1">Phone Number (M)</label>
                  <input
                    type="text"
                    required
                    value={newCust.phone || ''}
                    onChange={(e) => setNewCust({ ...newCust, phone: e.target.value })}
                    className="w-full p-2 border border-border rounded"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-text-primary mb-1">Business Segment (M)</label>
                  <select
                    value={newCust.segment || 'Corporate Banking'}
                    onChange={(e) => setNewCust({ ...newCust, segment: e.target.value as any })}
                    className="w-full p-2 border border-border rounded"
                  >
                    <option value="Corporate Banking">Corporate Banking</option>
                    <option value="Retail Banking">Retail Banking</option>
                    <option value="MSME Banking">MSME Banking</option>
                    <option value="Interest-Free Banking (IFB)">Interest-Free Banking (IFB)</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-border">
                <button type="button" onClick={() => setShowManualRegModal(false)} className="btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  Submit to Checker
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
