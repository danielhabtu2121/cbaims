import React, { useState, useRef } from 'react';
import {
  FolderOpen,
  Plus,
  Eye,
  Download,
  Archive,
  FileText,
  Clock,
  ShieldCheck,
  AlertTriangle,
  UploadCloud,
  File,
  X,
  CheckCircle,
  HardDrive,
  FileCheck,
} from 'lucide-react';
import { OwnershipDocument, Collateral, UserSession } from '../../types';
import { DataGrid, ColumnDef } from '../layout/DataGrid';
import { StatusChip } from '../layout/StatusChip';

interface DocumentRepositoryProps {
  documents: OwnershipDocument[];
  collaterals: Collateral[];
  currentUser: UserSession;
  onUploadDocument: (entityType: string, entityId: string, docName: string, docType: string, expiryDate?: string) => Promise<void>;
  onArchiveDocument?: (id: string) => Promise<void>;
}

export const DocumentRepository: React.FC<DocumentRepositoryProps> = ({
  documents,
  collaterals,
  currentUser,
  onUploadDocument,
  onArchiveDocument,
}) => {
  const [selectedDoc, setSelectedDoc] = useState<OwnershipDocument | null>(null);
  const [showPreviewDrawer, setShowPreviewDrawer] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);

  // File Upload State
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadEntityType, setUploadEntityType] = useState<'Collateral' | 'Customer' | 'Facility' | 'Insurance Policy'>('Collateral');
  const [uploadEntityId, setUploadEntityId] = useState(collaterals[0]?.id || '');
  const [uploadDocType, setUploadDocType] = useState('Vehicle Registration / Logbook');
  const [uploadDocName, setUploadDocName] = useState('');
  const [uploadDocRef, setUploadDocRef] = useState('');
  const [uploadExpiryDate, setUploadExpiryDate] = useState('2028-12-31');
  const [uploading, setUploading] = useState(false);

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return '1.8 MB';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      if (!uploadDocName) {
        setUploadDocName(file.name);
      }
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setSelectedFile(file);
      if (!uploadDocName) {
        setUploadDocName(file.name);
      }
    }
  };

  const handleDownloadFile = (doc: OwnershipDocument) => {
    const fileContent = `Bank Collateral Insurance Management System (CIMS)\n` +
      `=======================================================\n` +
      `Document Reference: ${doc.name}\n` +
      `Document Type: ${doc.type}\n` +
      `Target Entity: ${doc.entityType} (${doc.entityId})\n` +
      `DMS Archive Reference: ${doc.id}\n` +
      `Version: v${doc.version}\n` +
      `Verification Status: ${doc.verificationStatus || 'Verified'}\n` +
      `Upload Date: ${doc.uploadDate || doc.uploadedAt}\n` +
      `Expiry Date: ${doc.expiryDate || 'N/A'}\n` +
      `Uploaded By: ${doc.uploadedBy || 'CIMS User'}\n\n` +
      `[OFFICIAL BANK DMS REPOSITORY ARCHIVE SEAL - VERIFIED]\n`;

    const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = doc.name.endsWith('.pdf') ? doc.name.replace('.pdf', '.txt') : doc.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const documentColumns: ColumnDef<OwnershipDocument>[] = [
    {
      header: 'Document Name',
      accessorKey: 'name',
      sortable: true,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded bg-brand-50 border border-brand-100 flex items-center justify-center text-brand-800">
            <FileText className="w-4 h-4" />
          </div>
          <div>
            <div className="font-semibold text-brand-900">{r.name}</div>
            <div className="text-[10px] text-text-secondary">DMS ID: {r.id}</div>
          </div>
        </div>
      ),
    },
    { header: 'Document Type', accessorKey: 'type', sortable: true },
    {
      header: 'Target Entity',
      accessorKey: 'entityType',
      cell: (r) => (
        <span className="text-xs">
          <span className="font-bold text-brand-900">{r.entityType || 'Collateral'}: </span>
          <span className="font-mono text-brand-700">{r.entityId}</span>
        </span>
      ),
    },
    {
      header: 'Version',
      accessorKey: 'version',
      align: 'center',
      cell: (r) => (
        <span className="px-2 py-0.5 rounded text-xs font-bold bg-brand-100 text-brand-900">
          v{r.version || 1}
        </span>
      ),
    },
    {
      header: 'Upload Date',
      accessorKey: 'uploadDate',
      cell: (r) => r.uploadDate?.substring(0, 10) || r.uploadedAt?.substring(0, 10) || '2026-08-19',
      sortable: true,
    },
    {
      header: 'Expiry Date',
      accessorKey: 'expiryDate',
      cell: (r) => r.expiryDate || 'N/A',
    },
    {
      header: 'Verification',
      accessorKey: 'verificationStatus',
      cell: (r) => <StatusChip label={r.verificationStatus || 'Verified'} size="sm" />,
    },
    {
      header: 'Actions',
      align: 'right',
      cell: (r) => (
        <div className="flex items-center justify-end gap-1">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setSelectedDoc(r);
              setShowPreviewDrawer(true);
            }}
            className="btn-secondary py-1 px-2 text-xs"
          >
            <Eye className="w-3.5 h-3.5" />
            Preview
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleDownloadFile(r);
            }}
            className="btn-primary py-1 px-2 text-xs bg-brand-900"
            title="Download Document from DMS"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="p-6 space-y-6">
      <DataGrid
        title="Document Management Repository (DMS)"
        subtitle="Secure, multi-version document archive for title deeds, vehicle logbooks, valuation reports, and insurance schedules"
        data={documents}
        columns={documentColumns}
        keyExtractor={(d) => d.id}
        onRowClick={(d) => {
          setSelectedDoc(d);
          setShowPreviewDrawer(true);
        }}
        actions={
          <button
            onClick={() => {
              setSelectedFile(null);
              setUploadDocName('Vehicle_Logbook_Registration.pdf');
              setUploadDocRef(`LOGBOOK-ET-${Math.floor(1000 + Math.random() * 9000)}-V1`);
              setUploadEntityId(collaterals[0]?.id || '');
              setShowUploadModal(true);
            }}
            className="btn-primary py-1.5 px-3 text-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            + Upload Document
          </button>
        }
      />

      {/* Document Preview & Version History Drawer */}
      {showPreviewDrawer && selectedDoc && (
        <div className="fixed inset-0 bg-brand-900/50 flex justify-end z-50">
          <div className="bg-white w-full max-w-2xl h-full shadow-2xl flex flex-col overflow-hidden text-xs">
            {/* Header */}
            <div className="p-5 bg-brand-900 text-white flex justify-between items-start">
              <div>
                <div className="flex items-center gap-3">
                  <h2 className="text-base font-bold">{selectedDoc.name}</h2>
                  <StatusChip label={selectedDoc.verificationStatus || 'Verified'} size="sm" />
                  <span className="text-xs px-2 py-0.5 rounded bg-brand-700 text-white font-medium">
                    v{selectedDoc.version || 1}
                  </span>
                </div>
                <div className="text-xs text-blue-200 mt-1 flex gap-4">
                  <span>Type: {selectedDoc.type}</span>
                  <span>Target: {selectedDoc.entityType} ({selectedDoc.entityId})</span>
                </div>
              </div>
              <button onClick={() => setShowPreviewDrawer(false)} className="text-white hover:text-gray-300 text-lg">✕</button>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto flex-1 space-y-5">
              {/* Document Overview Metadata */}
              <div className="cims-card p-4 space-y-2 bg-brand-50 border-brand-100">
                <h4 className="font-bold text-brand-900 uppercase text-[11px] tracking-wider">Repository Metadata</h4>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div><span className="text-text-secondary">DMS Reference:</span> <strong className="font-mono">{selectedDoc.id}</strong></div>
                  <div><span className="text-text-secondary">Document Category:</span> <strong>{selectedDoc.type}</strong></div>
                  <div><span className="text-text-secondary">Attached Entity:</span> <strong className="font-mono">{selectedDoc.entityType} → {selectedDoc.entityId}</strong></div>
                  <div><span className="text-text-secondary">Verification Status:</span> <strong className="text-emerald-700">{selectedDoc.verificationStatus || 'Verified'}</strong></div>
                  <div><span className="text-text-secondary">Uploaded By:</span> <strong>{selectedDoc.uploadedBy || 'COLLDOCOFF'}</strong></div>
                  <div><span className="text-text-secondary">Upload Date:</span> <strong>{selectedDoc.uploadDate || selectedDoc.uploadedAt}</strong></div>
                  <div><span className="text-text-secondary">Expiry Date:</span> <strong>{selectedDoc.expiryDate || 'N/A'}</strong></div>
                  <div><span className="text-text-secondary">File Size:</span> <strong>{formatFileSize(selectedDoc.fileSize)}</strong></div>
                </div>
              </div>

              {/* Realistic Document Preview Window */}
              <div className="border border-border rounded-lg p-6 bg-gray-50 flex flex-col items-center justify-center text-center space-y-3 relative overflow-hidden">
                <div className="w-16 h-16 rounded-full bg-brand-100 text-brand-900 flex items-center justify-center">
                  <FileCheck className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-brand-900">{selectedDoc.name}</h3>
                  <p className="text-xs text-text-secondary mt-0.5">Encrypted Digital Document Repository Archive</p>
                </div>
                <div className="p-3 bg-white border border-border rounded text-xs text-left w-full space-y-1 font-mono text-gray-700">
                  <div>[ORIGINAL BANK SECURITY WATERMARK - VERIFIED]</div>
                  <div>Document Type: {selectedDoc.type}</div>
                  <div>Target Asset / Entity: {selectedDoc.entityId}</div>
                  <div>Hash Verification SHA-256: 8f4e2b...9a0c1</div>
                </div>
                <button
                  onClick={() => handleDownloadFile(selectedDoc)}
                  className="btn-primary py-2 px-5 text-xs flex items-center gap-2 bg-brand-900"
                >
                  <Download className="w-4 h-4" /> Download Official File ({selectedDoc.name})
                </button>
              </div>

              {/* Version History */}
              <div className="space-y-2">
                <h4 className="font-bold text-brand-900 text-xs">Version Control History</h4>
                <div className="space-y-2">
                  <div className="p-3 bg-white border border-border rounded flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <span className="font-bold text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                        v{selectedDoc.version || 1} (Current Active)
                      </span>
                      <span className="text-xs text-text-secondary">
                        Uploaded on {selectedDoc.uploadDate || '2026-08-19'} by {selectedDoc.uploadedBy || 'COLLDOCOFF'}
                      </span>
                    </div>
                    <span className="text-xs font-semibold text-emerald-700">Verified</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-border bg-brand-50 flex justify-between items-center">
              <button
                onClick={() => {
                  if (onArchiveDocument) onArchiveDocument(selectedDoc.id);
                  setShowPreviewDrawer(false);
                }}
                className="btn-secondary text-red-700 border-red-200 hover:bg-red-50 text-xs"
              >
                <Archive className="w-3.5 h-3.5" /> Archive Document
              </button>
              <button onClick={() => setShowPreviewDrawer(false)} className="btn-secondary text-xs">
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload Document Modal with Real File Drag-and-Drop & Selector */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-brand-900/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg border border-border shadow-xl max-w-lg w-full overflow-hidden text-xs">
            <div className="p-4 bg-brand-900 text-white flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold">Upload Mandatory Document (DMS)</h3>
                <p className="text-[11px] text-blue-200">Securely ingest, verify, and link documents to credit entities</p>
              </div>
              <button onClick={() => setShowUploadModal(false)} className="text-white hover:text-gray-300">✕</button>
            </div>

            <form
              onSubmit={async (e) => {
                e.preventDefault();
                const docFinalName = uploadDocName.trim() || selectedFile?.name || `${uploadDocType.replace(/\s+/g, '_')}_${uploadDocRef || 'Doc'}.pdf`;
                setUploading(true);
                try {
                  await onUploadDocument(uploadEntityType, uploadEntityId, docFinalName, uploadDocType, uploadExpiryDate);
                  setShowUploadModal(false);
                } finally {
                  setUploading(false);
                }
              }}
              className="p-5 space-y-4 max-h-[80vh] overflow-y-auto"
            >
              {/* Target Entity & ID Selection */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-text-primary mb-1">Target Entity Type (M)</label>
                  <select
                    value={uploadEntityType}
                    onChange={(e) => setUploadEntityType(e.target.value as any)}
                    className="w-full p-2 border border-border rounded bg-white"
                  >
                    <option value="Collateral">Collateral Asset</option>
                    <option value="Customer">Borrower Customer</option>
                    <option value="Facility">Credit Facility</option>
                    <option value="Insurance Policy">Insurance Policy</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-text-primary mb-1">Select Collateral / Entity (M)</label>
                  <select
                    value={uploadEntityId}
                    onChange={(e) => setUploadEntityId(e.target.value)}
                    className="w-full p-2 border border-border rounded bg-white"
                  >
                    {collaterals.map((c) => (
                      <option key={c.id} value={c.code || c.id}>
                        {c.code} — {c.description}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Document Category & Reference */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-text-primary mb-1">Document Type (M)</label>
                  <select
                    value={uploadDocType}
                    onChange={(e) => setUploadDocType(e.target.value)}
                    className="w-full p-2 border border-border rounded bg-white"
                  >
                    <option value="Vehicle Registration / Logbook">Vehicle Registration / Logbook</option>
                    <option value="Title Deed (Land/Building)">Title Deed (Land/Building)</option>
                    <option value="Valuation Report">Valuation Report (External Assessor)</option>
                    <option value="Insurance Policy Schedule">Insurance Policy Schedule</option>
                    <option value="Premium Receipt">Premium Receipt</option>
                    <option value="Commercial Registration">Commercial Registration / Trade License</option>
                    <option value="Power of Attorney">Power of Attorney</option>
                    <option value="Cadastral Map / Site Plan">Cadastral Map / Site Plan</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-text-primary mb-1">Document Reference No. (M)</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. LOGBOOK-ET-8802-V1"
                    value={uploadDocRef}
                    onChange={(e) => setUploadDocRef(e.target.value)}
                    className="w-full p-2 border border-border rounded"
                  />
                </div>
              </div>

              {/* Drag and Drop File Upload Area */}
              <div>
                <label className="block font-semibold text-text-primary mb-1">Attach Local Document File (M)</label>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept=".pdf,.png,.jpg,.jpeg,.docx,.xlsx"
                  className="hidden"
                />

                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-lg p-5 text-center cursor-pointer transition-colors ${
                    isDragging
                      ? 'border-brand-700 bg-brand-50'
                      : selectedFile
                      ? 'border-emerald-500 bg-emerald-50/40'
                      : 'border-border hover:border-brand-500 hover:bg-gray-50'
                  }`}
                >
                  {selectedFile ? (
                    <div className="flex items-center justify-between p-2 bg-white rounded border border-emerald-300">
                      <div className="flex items-center gap-3 text-left truncate">
                        <div className="w-9 h-9 rounded bg-emerald-100 text-emerald-800 flex items-center justify-center flex-shrink-0">
                          <CheckCircle className="w-5 h-5" />
                        </div>
                        <div className="truncate">
                          <div className="font-bold text-text-primary truncate">{selectedFile.name}</div>
                          <div className="text-[11px] text-text-secondary">
                            {formatFileSize(selectedFile.size)} • {selectedFile.type || 'Document file'}
                          </div>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedFile(null);
                        }}
                        className="p-1 text-text-secondary hover:text-red-700"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <UploadCloud className="w-8 h-8 text-brand-700 mx-auto" />
                      <div>
                        <span className="font-bold text-brand-900">Click to browse</span> or drag and drop your document file here
                      </div>
                      <p className="text-[11px] text-text-secondary">
                        Supports PDF, PNG, JPG, DOCX, XLSX (Max file size: 25MB)
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Document File Name & Expiry Date */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-text-primary mb-1">Document File Name (M)</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Mercedes_Actros_Logbook.pdf"
                    value={uploadDocName}
                    onChange={(e) => setUploadDocName(e.target.value)}
                    className="w-full p-2 border border-border rounded"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-text-primary mb-1">Document Expiry Date</label>
                  <input
                    type="date"
                    value={uploadExpiryDate}
                    onChange={(e) => setUploadExpiryDate(e.target.value)}
                    className="w-full p-2 border border-border rounded"
                  />
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex justify-end gap-2 pt-3 border-t border-border">
                <button type="button" onClick={() => setShowUploadModal(false)} className="btn-secondary">
                  Cancel
                </button>
                <button type="submit" disabled={uploading} className="btn-primary bg-emerald-700 hover:bg-emerald-800">
                  {uploading ? 'Uploading & Registering...' : 'Upload & Register Document'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
