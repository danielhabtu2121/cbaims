import React, { useState } from 'react';
import {
  Building2,
  Plus,
  Eye,
  ShieldCheck,
  AlertTriangle,
  Link as LinkIcon,
  FileCheck,
  FolderOpen,
  History,
  Unlock,
  ArrowRightLeft,
  CheckCircle,
  XCircle,
  FileText,
  UserCheck,
} from 'lucide-react';
import {
  Collateral,
  CollateralOwner,
  LoanAccount,
  LoanCollateralLink,
  InsurancePolicy,
  OwnershipDocument,
  CimsException,
  UserSession,
} from '../../types';
import { DataGrid, ColumnDef } from '../layout/DataGrid';
import { StatusChip } from '../layout/StatusChip';
import { CircularProgress } from '../layout/CircularProgress';

interface CollateralManagerProps {
  collaterals: Collateral[];
  facilities: LoanAccount[];
  links: LoanCollateralLink[];
  policies: InsurancePolicy[];
  documents: OwnershipDocument[];
  exceptions: CimsException[];
  currentUser: UserSession;
  onRegisterCollateral: (col: Partial<Collateral>) => Promise<void>;
  onAddLink: (loanId: string, collateralId: string, amount: number) => Promise<void>;
  onRemoveLink: (linkId: string) => Promise<void>;
  onValidateRelease: (collateralId: string) => Promise<{ canRelease: boolean; pendingExposure: number; activeLoans: string[]; message: string }>;
  onInitiateTransfer: (collateralId: string, destSegment: string, reason: string) => Promise<void>;
}

export const CollateralManager: React.FC<CollateralManagerProps> = ({
  collaterals,
  facilities,
  links,
  policies,
  documents,
  exceptions,
  currentUser,
  onRegisterCollateral,
  onAddLink,
  onRemoveLink,
  onValidateRelease,
  onInitiateTransfer,
}) => {
  const [selectedCol, setSelectedCol] = useState<Collateral | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'ownership' | 'links' | 'policies' | 'documents' | 'exceptions'>('details');

  // Action Modals
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [showReleaseModal, setShowReleaseModal] = useState(false);
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [showAddLinkModal, setShowAddLinkModal] = useState(false);
  const [showAddOwnerModal, setShowAddOwnerModal] = useState(false);

  // Form states
  const [newCol, setNewCol] = useState<Partial<Collateral>>({
    category: 'Immovable Properties',
    ownerType: 'Borrower-owned',
    currency: 'ETB',
    valuationAmount: 10000000,
    haircut: 20,
    owningSegment: 'Corporate Banking',
    branch: currentUser.branch || 'Bole Special Branch',
    status: 'Uninsured',
    insuranceStatus: 'Uninsured',
  });

  const [linkLoanId, setLinkLoanId] = useState('');
  const [linkAmount, setLinkAmount] = useState(5000000);
  const [destSegment, setDestSegment] = useState('Retail Banking');
  const [transferReason, setTransferReason] = useState('');
  const [releaseCheck, setReleaseCheck] = useState<{ canRelease: boolean; pendingExposure: number; activeLoans: string[]; message: string } | null>(null);
  const [loadingRelease, setLoadingRelease] = useState(false);

  const isMaker = ['CRO', 'BRO', 'SRM', 'BRM', 'SYSADMIN'].includes(currentUser.role);

  const collateralColumns: ColumnDef<Collateral>[] = [
    { header: 'Collateral Code', accessorKey: 'code', sortable: true },
    { header: 'Description', accessorKey: 'description', sortable: true },
    { header: 'Category', accessorKey: 'category' },
    { header: 'Owner Type', accessorKey: 'ownerType' },
    {
      header: 'Valuation Amount',
      accessorKey: 'valuationAmount',
      align: 'right',
      cell: (r) => `${r.currency || 'ETB'} ${r.valuationAmount?.toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
    },
    {
      header: 'Insured Amount',
      accessorKey: 'insuredAmount',
      align: 'right',
      cell: (r) => `${r.currency || 'ETB'} ${(r.insuredAmount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
    },
    {
      header: 'Coverage %',
      accessorKey: 'netInsuranceCoveragePct',
      align: 'right',
      cell: (r) => (
        <span className="font-semibold tabular-nums" style={{ color: (r.netInsuranceCoveragePct || 0) >= 100 ? '#1E8E5A' : (r.netInsuranceCoveragePct || 0) >= 70 ? '#B8860B' : '#C0362C' }}>
          {(r.netInsuranceCoveragePct || 0).toFixed(1)}%
        </span>
      ),
    },
    {
      header: 'Insurance Status',
      accessorKey: 'insuranceStatus',
      cell: (r) => <StatusChip label={r.insuranceStatus || r.status} />,
    },
    { header: 'Segment', accessorKey: 'owningSegment' },
    { header: 'Branch', accessorKey: 'branch' },
    {
      header: 'Action',
      align: 'right',
      cell: (r) => (
        <button
          onClick={(e) => {
            e.stopPropagation();
            setSelectedCol(r);
            setShowDetailModal(true);
          }}
          className="btn-ghost py-1 px-2 text-xs"
        >
          <Eye className="w-3.5 h-3.5" />
          View
        </button>
      ),
    },
  ];

  // Linked items for selected collateral
  const colLinks = selectedCol ? links.filter((l) => l.collateralId === selectedCol.id) : [];
  const colPolicies = selectedCol ? policies.filter((p) => p.collateralId === selectedCol.id) : [];
  const colDocs = selectedCol ? documents.filter((d) => d.entityId === selectedCol.id || d.collateralId === selectedCol.id) : [];
  const colExceptions = selectedCol ? exceptions.filter((e) => e.entityId === selectedCol.id) : [];

  const handleOpenReleaseModal = async () => {
    if (!selectedCol) return;
    setLoadingRelease(true);
    try {
      const res = await onValidateRelease(selectedCol.id);
      setReleaseCheck(res);
      setShowReleaseModal(true);
    } finally {
      setLoadingRelease(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <DataGrid
        title="Collateral Master"
        subtitle="Manage pledged collateral assets, multi-owner equity, coverage health, and document compliance"
        data={collaterals}
        columns={collateralColumns}
        keyExtractor={(c) => c.id}
        onRowClick={(c) => {
          setSelectedCol(c);
          setShowDetailModal(true);
        }}
        actions={
          isMaker ? (
            <button
              onClick={() => {
                setNewCol({
                  code: `COL-2026-${Math.floor(100000 + Math.random() * 900000)}`,
                  category: 'Immovable Properties',
                  ownerType: 'Borrower-owned',
                  currency: 'ETB',
                  valuationAmount: 12000000,
                  haircut: 20,
                  owningSegment: 'Corporate Banking',
                  branch: currentUser.branch || 'Bole Special Branch',
                  status: 'Uninsured',
                  insuranceStatus: 'Uninsured',
                });
                setShowRegisterModal(true);
              }}
              className="btn-primary py-1.5 px-3 text-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              + Register Native Collateral
            </button>
          ) : undefined
        }
      />

      {/* Collateral Detail Modal */}
      {showDetailModal && selectedCol && (
        <div className="fixed inset-0 bg-brand-900/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl border border-border shadow-2xl max-w-5xl w-full max-h-[92vh] flex flex-col overflow-hidden">
            {/* Header with Circular Gauge */}
            <div className="p-5 bg-brand-900 text-white flex justify-between items-start">
              <div className="flex items-center gap-6">
                <div>
                  <div className="flex items-center gap-3">
                    <h2 className="text-lg font-bold">{selectedCol.code}</h2>
                    <StatusChip label={selectedCol.insuranceStatus || selectedCol.status} />
                    <span className="text-xs px-2 py-0.5 rounded bg-brand-700 text-white font-medium">
                      {selectedCol.owningSegment}
                    </span>
                  </div>
                  <p className="text-xs text-blue-200 mt-1 max-w-xl">{selectedCol.description}</p>
                  <div className="text-xs text-blue-200 mt-1 flex gap-4">
                    <span>Category: {selectedCol.category}</span>
                    <span>Branch: {selectedCol.branch}</span>
                    <span>Owner Type: {selectedCol.ownerType}</span>
                  </div>
                </div>

                {/* Circular Gauge */}
                <div className="bg-brand-800/80 p-2.5 rounded-lg border border-brand-700 flex items-center gap-3">
                  <CircularProgress value={selectedCol.netInsuranceCoveragePct || 0} size={70} strokeWidth={7} />
                  <div className="text-xs space-y-0.5">
                    <div className="text-[10px] uppercase font-bold text-blue-200 tracking-wider">Net Coverage</div>
                    <div className="font-bold text-white tabular-nums">
                      {selectedCol.currency || 'ETB'} {(selectedCol.insuredAmount || 0).toLocaleString()}
                    </div>
                    <div className="text-[10px] text-blue-300">
                      Val: {selectedCol.currency || 'ETB'} {selectedCol.valuationAmount?.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowTransferModal(true)}
                  className="btn-secondary py-1.5 px-3 text-xs bg-brand-800 border-brand-700 text-white hover:bg-brand-700"
                >
                  <ArrowRightLeft className="w-3.5 h-3.5" />
                  Transfer Segment
                </button>
                <button
                  onClick={handleOpenReleaseModal}
                  className="btn-secondary py-1.5 px-3 text-xs bg-brand-800 border-brand-700 text-white hover:bg-brand-700"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  Release Collateral
                </button>
                <button onClick={() => setShowDetailModal(false)} className="text-white hover:text-gray-300 text-lg ml-2">
                  ✕
                </button>
              </div>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-border bg-brand-50 px-6 gap-2 pt-2">
              <button
                onClick={() => setActiveTab('details')}
                className={`pb-2.5 px-3 text-xs font-semibold border-b-2 ${
                  activeTab === 'details' ? 'border-brand-900 text-brand-900' : 'border-transparent text-text-secondary'
                }`}
              >
                Asset Details
              </button>
              <button
                onClick={() => setActiveTab('ownership')}
                className={`pb-2.5 px-3 text-xs font-semibold border-b-2 ${
                  activeTab === 'ownership' ? 'border-brand-900 text-brand-900' : 'border-transparent text-text-secondary'
                }`}
              >
                Ownership & Multi-Owner ({(selectedCol.owners || []).length})
              </button>
              <button
                onClick={() => setActiveTab('links')}
                className={`pb-2.5 px-3 text-xs font-semibold border-b-2 ${
                  activeTab === 'links' ? 'border-brand-900 text-brand-900' : 'border-transparent text-text-secondary'
                }`}
              >
                Linked Facilities ({colLinks.length})
              </button>
              <button
                onClick={() => setActiveTab('policies')}
                className={`pb-2.5 px-3 text-xs font-semibold border-b-2 ${
                  activeTab === 'policies' ? 'border-brand-900 text-brand-900' : 'border-transparent text-text-secondary'
                }`}
              >
                Insurance Policies ({colPolicies.length})
              </button>
              <button
                onClick={() => setActiveTab('documents')}
                className={`pb-2.5 px-3 text-xs font-semibold border-b-2 ${
                  activeTab === 'documents' ? 'border-brand-900 text-brand-900' : 'border-transparent text-text-secondary'
                }`}
              >
                Documents ({colDocs.length})
              </button>
              <button
                onClick={() => setActiveTab('exceptions')}
                className={`pb-2.5 px-3 text-xs font-semibold border-b-2 ${
                  activeTab === 'exceptions' ? 'border-brand-900 text-brand-900' : 'border-transparent text-text-secondary'
                }`}
              >
                Exceptions ({colExceptions.length})
              </button>
            </div>

            {/* Tab Contents */}
            <div className="p-6 overflow-y-auto flex-1 space-y-4 text-xs">
              {activeTab === 'details' && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="cims-card p-4 space-y-2">
                    <h4 className="font-bold text-text-primary text-xs border-b border-border pb-1">Valuation & Risk Controls</h4>
                    <div><span className="text-text-secondary">Valuation Amount:</span> <strong className="tabular-nums">{selectedCol.currency || 'ETB'} {selectedCol.valuationAmount?.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong></div>
                    <div><span className="text-text-secondary">Haircut Applied:</span> <strong className="tabular-nums">{selectedCol.haircut || 0}%</strong></div>
                    <div><span className="text-text-secondary">Limit Contribution:</span> <strong className="tabular-nums">{selectedCol.currency || 'ETB'} {(selectedCol.limitContribution || (selectedCol.valuationAmount * (1 - (selectedCol.haircut || 0) / 100)))?.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong></div>
                    <div><span className="text-text-secondary">Tangible Asset:</span> <strong>{selectedCol.tangible !== false ? 'Yes' : 'No'}</strong></div>
                    <div><span className="text-text-secondary">Start Date:</span> <strong>{selectedCol.startDate || '—'}</strong></div>
                    <div><span className="text-text-secondary">Review Date:</span> <strong>{selectedCol.reviewDate || '—'}</strong></div>
                  </div>
                  <div className="cims-card p-4 space-y-2">
                    <h4 className="font-bold text-text-primary text-xs border-b border-border pb-1">Asset Location & Registry</h4>
                    <div><span className="text-text-secondary">Title Deed Number:</span> <strong>{selectedCol.titleDeedNumber || '—'}</strong></div>
                    <div><span className="text-text-secondary">Registration Number:</span> <strong>{selectedCol.registrationNumber || '—'}</strong></div>
                    <div><span className="text-text-secondary">GPS Coordinates:</span> <strong>{selectedCol.gpsCoordinates || '9.01234, 38.76543'}</strong></div>
                    <div><span className="text-text-secondary">Postal Code / Zip:</span> <strong>{selectedCol.zipCode || '1000'}</strong></div>
                    <div><span className="text-text-secondary">Verification Status:</span> <strong>{selectedCol.verificationStatus || 'Verified'}</strong></div>
                  </div>
                </div>
              )}

              {activeTab === 'ownership' && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-semibold text-text-secondary">
                      Multi-Owner Equity Structure (Total Ownership must equal 100%)
                    </span>
                    {isMaker && (
                      <button
                        onClick={() => setShowAddOwnerModal(true)}
                        className="btn-primary py-1 px-2.5 text-xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        + Add Owner / Record Change
                      </button>
                    )}
                  </div>

                  <div className="cims-card overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-brand-50 border-b border-border text-text-secondary font-semibold">
                        <tr>
                          <th className="p-2.5">Owner Name</th>
                          <th className="p-2.5">Ownership Type</th>
                          <th className="p-2.5">Owner Type</th>
                          <th className="p-2.5">ID Number / TIN</th>
                          <th className="p-2.5">Relationship</th>
                          <th className="p-2.5 text-right">Ownership %</th>
                          <th className="p-2.5">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {(selectedCol.owners || []).length === 0 ? (
                          <tr>
                            <td colSpan={7} className="text-center py-6 text-text-secondary">
                              No explicit owner record found. Defaulting to Borrower 100%.
                            </td>
                          </tr>
                        ) : (
                          (selectedCol.owners || []).map((o, idx) => (
                            <tr key={o.id || idx} className="hover:bg-brand-50">
                              <td className="p-2.5 font-semibold">{o.name}</td>
                              <td className="p-2.5">{o.ownershipType}</td>
                              <td className="p-2.5">{o.ownerType}</td>
                              <td className="p-2.5">{o.idNumber || o.tin || '—'}</td>
                              <td className="p-2.5">{o.relationship}</td>
                              <td className="p-2.5 text-right font-bold tabular-nums">{o.percentage}%</td>
                              <td className="p-2.5"><StatusChip label={o.verificationStatus || 'Verified'} /></td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {activeTab === 'links' && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-semibold text-text-secondary">
                      Credit Facilities Linked to this Collateral (Junction Entity: CLTB_ACC_COLL_LINK_DTLS)
                    </span>
                    {isMaker && (
                      <button
                        onClick={() => {
                          setLinkLoanId(facilities[0]?.id || '');
                          setShowAddLinkModal(true);
                        }}
                        className="btn-primary py-1 px-2.5 text-xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        + Add Facility Link
                      </button>
                    )}
                  </div>

                  <div className="cims-card overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-brand-50 border-b border-border text-text-secondary font-semibold">
                        <tr>
                          <th className="p-2.5">Loan Reference</th>
                          <th className="p-2.5">Facility Type</th>
                          <th className="p-2.5 text-right">Outstanding Balance</th>
                          <th className="p-2.5 text-right">Allocated Amount</th>
                          <th className="p-2.5">Linkage Type</th>
                          {isMaker && <th className="p-2.5 text-right">Action</th>}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {colLinks.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="text-center py-6 text-text-secondary">
                              No facility links configured.
                            </td>
                          </tr>
                        ) : (
                          colLinks.map((l) => {
                            const fac = facilities.find((f) => f.id === l.loanAccountId);
                            return (
                              <tr key={l.id} className="hover:bg-brand-50">
                                <td className="p-2.5 font-semibold">{fac?.loanReference || l.loanAccountId}</td>
                                <td className="p-2.5">{fac?.facilityType || '—'}</td>
                                <td className="p-2.5 text-right tabular-nums">
                                  {fac?.lineCurrency || 'ETB'} {fac?.outstandingBalance?.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                </td>
                                <td className="p-2.5 text-right tabular-nums font-semibold">
                                  ETB {l.allocatedAmount?.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                </td>
                                <td className="p-2.5">{l.linkageType || 'Primary'}</td>
                                {isMaker && (
                                  <td className="p-2.5 text-right">
                                    <button
                                      onClick={() => onRemoveLink(l.id)}
                                      className="text-danger hover:underline font-semibold"
                                    >
                                      Remove
                                    </button>
                                  </td>
                                )}
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {activeTab === 'policies' && (
                <div className="space-y-4">
                  <div className="cims-card overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-brand-50 border-b border-border text-text-secondary font-semibold">
                        <tr>
                          <th className="p-2.5">Policy Number</th>
                          <th className="p-2.5">Insurer Name</th>
                          <th className="p-2.5">Coverage Type</th>
                          <th className="p-2.5 text-right">Insured Amount</th>
                          <th className="p-2.5 text-right">Premium</th>
                          <th className="p-2.5">Expiry Date</th>
                          <th className="p-2.5">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {colPolicies.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="text-center py-6 text-text-secondary">
                              No insurance policies linked to this collateral.
                            </td>
                          </tr>
                        ) : (
                          colPolicies.map((p) => (
                            <tr key={p.id} className="hover:bg-brand-50">
                              <td className="p-2.5 font-semibold">{p.policyNumber}</td>
                              <td className="p-2.5">{p.insurerName}</td>
                              <td className="p-2.5">{p.coverageType}</td>
                              <td className="p-2.5 text-right tabular-nums font-semibold">
                                ETB {p.insuredAmount?.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                              </td>
                              <td className="p-2.5 text-right tabular-nums">
                                ETB {p.premium?.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                              </td>
                              <td className="p-2.5">{p.expiryDate}</td>
                              <td className="p-2.5"><StatusChip label={p.status} /></td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {activeTab === 'documents' && (
                <div className="space-y-4">
                  {/* Mandatory Document Rule Alert */}
                  {colDocs.length === 0 && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-danger">
                      <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                      <span>
                        <strong>Mandatory Document Warning:</strong> Immovable property requires verified Title Deed and Valuation Report.
                      </span>
                    </div>
                  )}

                  <div className="cims-card overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-brand-50 border-b border-border text-text-secondary font-semibold">
                        <tr>
                          <th className="p-2.5">Document Name</th>
                          <th className="p-2.5">Document Type</th>
                          <th className="p-2.5">Version</th>
                          <th className="p-2.5">Upload Date</th>
                          <th className="p-2.5">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {colDocs.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="text-center py-6 text-text-secondary">
                              No documents uploaded for this collateral asset.
                            </td>
                          </tr>
                        ) : (
                          colDocs.map((d) => (
                            <tr key={d.id} className="hover:bg-brand-50">
                              <td className="p-2.5 font-semibold">{d.name}</td>
                              <td className="p-2.5">{d.type}</td>
                              <td className="p-2.5">v{d.version}</td>
                              <td className="p-2.5">{d.uploadDate?.substring(0, 10)}</td>
                              <td className="p-2.5"><StatusChip label={d.status} /></td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {activeTab === 'exceptions' && (
                <div className="cims-card overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-brand-50 border-b border-border text-text-secondary font-semibold">
                      <tr>
                        <th className="p-2.5">Exception Type</th>
                        <th className="p-2.5">Severity</th>
                        <th className="p-2.5">Description</th>
                        <th className="p-2.5">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {colExceptions.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="text-center py-6 text-text-secondary">
                            No open exceptions detected for this collateral.
                          </td>
                        </tr>
                      ) : (
                        colExceptions.map((e) => (
                          <tr key={e.id} className="hover:bg-brand-50">
                            <td className="p-2.5 font-semibold">{e.exceptionType}</td>
                            <td className="p-2.5"><StatusChip label={e.severity} /></td>
                            <td className="p-2.5">{e.description}</td>
                            <td className="p-2.5"><StatusChip label={e.status} /></td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Release Collateral Modal (4-point checklist) */}
      {showReleaseModal && selectedCol && releaseCheck && (
        <div className="fixed inset-0 bg-brand-900/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg border border-border shadow-xl max-w-lg w-full overflow-hidden text-xs">
            <div className="p-4 bg-brand-900 text-white flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold">Release Collateral Validation — {selectedCol.code}</h3>
                <p className="text-[11px] text-blue-200">Automated 4-Point Release Checklist</p>
              </div>
              <button onClick={() => setShowReleaseModal(false)} className="text-white hover:text-gray-300">✕</button>
            </div>
            <div className="p-5 space-y-4">
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-brand-50 rounded border border-border">
                  {releaseCheck.canRelease ? <CheckCircle className="w-5 h-5 text-emerald-600" /> : <XCircle className="w-5 h-5 text-red-600" />}
                  <div>
                    <div className="font-bold text-text-primary">1. Outstanding Facility Balance = 0 ETB</div>
                    <div className="text-text-secondary">
                      {releaseCheck.pendingExposure === 0
                        ? 'All linked facility balances are fully settled.'
                        : `Pending balance remaining: ETB ${releaseCheck.pendingExposure.toLocaleString()}`}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-brand-50 rounded border border-border">
                  {releaseCheck.activeLoans.length === 0 ? <CheckCircle className="w-5 h-5 text-emerald-600" /> : <XCircle className="w-5 h-5 text-red-600" />}
                  <div>
                    <div className="font-bold text-text-primary">2. No Active Pending Loan Obligations</div>
                    <div className="text-text-secondary">
                      {releaseCheck.activeLoans.length === 0 ? 'No active loan references blocking release.' : `Active: ${releaseCheck.activeLoans.join(', ')}`}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-brand-50 rounded border border-border">
                  <CheckCircle className="w-5 h-5 text-emerald-600" />
                  <div>
                    <div className="font-bold text-text-primary">3. No Open Insurance Disputes / Claims</div>
                    <div className="text-text-secondary">All policy endorsements and records resolved.</div>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-brand-50 rounded border border-border">
                  <CheckCircle className="w-5 h-5 text-emerald-600" />
                  <div>
                    <div className="font-bold text-text-primary">4. Checker Dual Authorization Stage</div>
                    <div className="text-text-secondary">Approval routes to Branch Manager / District Director.</div>
                  </div>
                </div>
              </div>

              <div className="p-3 rounded bg-blue-50 border border-blue-200 text-blue-900">
                {releaseCheck.message}
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-border">
                <button onClick={() => setShowReleaseModal(false)} className="btn-secondary">
                  Close
                </button>
                {releaseCheck.canRelease ? (
                  <button
                    onClick={() => {
                      alert('Release request submitted for Branch Manager authorization.');
                      setShowReleaseModal(false);
                    }}
                    className="btn-primary"
                  >
                    Submit Release to Checker
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      alert('Exceptional Release Override request routed to District Director / Head Office.');
                      setShowReleaseModal(false);
                    }}
                    className="btn-destructive"
                  >
                    Request Exceptional Override (DISTDIR / HODEPT)
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Transfer Segment Modal */}
      {showTransferModal && selectedCol && (
        <div className="fixed inset-0 bg-brand-900/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg border border-border shadow-xl max-w-md w-full overflow-hidden text-xs">
            <div className="p-4 bg-brand-900 text-white flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold">Transfer Ownership Segment</h3>
                <p className="text-[11px] text-blue-200">Reassign collateral portfolio ownership</p>
              </div>
              <button onClick={() => setShowTransferModal(false)} className="text-white hover:text-gray-300">✕</button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block font-semibold text-text-primary mb-1">Current Segment</label>
                <input type="text" disabled value={selectedCol.owningSegment} className="w-full p-2 bg-brand-50 border border-border rounded text-text-secondary" />
              </div>
              <div>
                <label className="block font-semibold text-text-primary mb-1">Destination Segment (M)</label>
                <select
                  value={destSegment}
                  onChange={(e) => setDestSegment(e.target.value)}
                  className="w-full p-2 border border-border rounded"
                >
                  <option value="Corporate Banking">Corporate Banking</option>
                  <option value="Retail Banking">Retail Banking</option>
                  <option value="MSME Banking">MSME Banking</option>
                  <option value="Interest-Free Banking (IFB)">Interest-Free Banking (IFB)</option>
                </select>
              </div>
              <div>
                <label className="block font-semibold text-text-primary mb-1">Business Reason (M)</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Justification for reassigning portfolio segment..."
                  value={transferReason}
                  onChange={(e) => setTransferReason(e.target.value)}
                  className="w-full p-2 border border-border rounded"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-border">
                <button onClick={() => setShowTransferModal(false)} className="btn-secondary">
                  Cancel
                </button>
                <button
                  onClick={async () => {
                    if (!transferReason.trim()) {
                      alert('Please specify a transfer reason.');
                      return;
                    }
                    await onInitiateTransfer(selectedCol.id, destSegment, transferReason);
                    setShowTransferModal(false);
                  }}
                  className="btn-primary"
                >
                  Submit for Approval (HODEPT)
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Link Modal */}
      {showAddLinkModal && selectedCol && (
        <div className="fixed inset-0 bg-brand-900/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg border border-border shadow-xl max-w-md w-full overflow-hidden text-xs">
            <div className="p-4 bg-brand-900 text-white flex justify-between items-center">
              <h3 className="text-sm font-bold">Link Credit Facility to {selectedCol.code}</h3>
              <button onClick={() => setShowAddLinkModal(false)} className="text-white hover:text-gray-300">✕</button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block font-semibold text-text-primary mb-1">Select Facility (M)</label>
                <select
                  value={linkLoanId}
                  onChange={(e) => setLinkLoanId(e.target.value)}
                  className="w-full p-2 border border-border rounded"
                >
                  {facilities.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.lineCode} — {f.loanReference} ({f.facilityType})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-text-primary mb-1">Allocated Collateral Amount (ETB) (M)</label>
                <input
                  type="number"
                  required
                  value={linkAmount}
                  onChange={(e) => setLinkAmount(Number(e.target.value))}
                  className="w-full p-2 border border-border rounded tabular-nums"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-border">
                <button onClick={() => setShowAddLinkModal(false)} className="btn-secondary">
                  Cancel
                </button>
                <button
                  onClick={async () => {
                    await onAddLink(linkLoanId || facilities[0]?.id, selectedCol.id, linkAmount);
                    setShowAddLinkModal(false);
                  }}
                  className="btn-primary"
                >
                  Create Facility Link
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Register Native Collateral Modal */}
      {showRegisterModal && (
        <div className="fixed inset-0 bg-brand-900/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg border border-border shadow-xl max-w-lg w-full overflow-hidden text-xs">
            <div className="p-4 bg-brand-900 text-white flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold">Register Native Collateral</h3>
                <p className="text-[11px] text-blue-200">Routes to Branch Manager Checker for authorization</p>
              </div>
              <button onClick={() => setShowRegisterModal(false)} className="text-white hover:text-gray-300">✕</button>
            </div>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                await onRegisterCollateral(newCol);
                setShowRegisterModal(false);
              }}
              className="p-5 space-y-4 max-h-[80vh] overflow-y-auto"
            >
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-text-primary mb-1">Collateral Code (M)</label>
                  <input
                    type="text"
                    required
                    value={newCol.code || ''}
                    onChange={(e) => setNewCol({ ...newCol, code: e.target.value })}
                    className="w-full p-2 border border-border rounded"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-text-primary mb-1">Category (M)</label>
                  <select
                    value={newCol.category || 'Immovable Properties'}
                    onChange={(e) => setNewCol({ ...newCol, category: e.target.value })}
                    className="w-full p-2 border border-border rounded"
                  >
                    <option value="Immovable Properties">Immovable Properties</option>
                    <option value="Movable Properties">Movable Properties</option>
                    <option value="Business Mortgages">Business Mortgages</option>
                    <option value="Financial Assets">Financial Assets</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-text-primary mb-1">Description (M)</label>
                <textarea
                  required
                  rows={2}
                  value={newCol.description || ''}
                  onChange={(e) => setNewCol({ ...newCol, description: e.target.value })}
                  className="w-full p-2 border border-border rounded"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-text-primary mb-1">Valuation Amount (ETB) (M)</label>
                  <input
                    type="number"
                    required
                    value={newCol.valuationAmount || 0}
                    onChange={(e) => setNewCol({ ...newCol, valuationAmount: Number(e.target.value) })}
                    className="w-full p-2 border border-border rounded tabular-nums"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-text-primary mb-1">Owner Type (M)</label>
                  <select
                    value={newCol.ownerType || 'Borrower-owned'}
                    onChange={(e) => setNewCol({ ...newCol, ownerType: e.target.value as any })}
                    className="w-full p-2 border border-border rounded"
                  >
                    <option value="Borrower-owned">Borrower-owned</option>
                    <option value="Third-party-owned">Third-party-owned</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-text-primary mb-1">Title Deed No. (O)</label>
                  <input
                    type="text"
                    value={newCol.titleDeedNumber || ''}
                    onChange={(e) => setNewCol({ ...newCol, titleDeedNumber: e.target.value })}
                    className="w-full p-2 border border-border rounded"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-text-primary mb-1">Registration No. (O)</label>
                  <input
                    type="text"
                    value={newCol.registrationNumber || ''}
                    onChange={(e) => setNewCol({ ...newCol, registrationNumber: e.target.value })}
                    className="w-full p-2 border border-border rounded"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-border">
                <button type="button" onClick={() => setShowRegisterModal(false)} className="btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  Submit to Checker
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
