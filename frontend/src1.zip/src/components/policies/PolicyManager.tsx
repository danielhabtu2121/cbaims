import React, { useState } from 'react';
import {
  FileCheck,
  Plus,
  Eye,
  Edit,
  RotateCw,
  AlertTriangle,
  FilePlus,
  CheckCircle,
  XCircle,
  FileText,
  Clock,
  Shield,
} from 'lucide-react';
import {
  InsurancePolicy,
  PolicyEndorsement,
  Collateral,
  Customer,
  ApprovedInsurer,
  OwnershipDocument,
  UserSession,
} from '../../types';
import { DataGrid, ColumnDef } from '../layout/DataGrid';
import { StatusChip } from '../layout/StatusChip';
import { CircularProgress } from '../layout/CircularProgress';

interface PolicyManagerProps {
  policies: InsurancePolicy[];
  endorsements: PolicyEndorsement[];
  collaterals: Collateral[];
  customers: Customer[];
  insurers: ApprovedInsurer[];
  documents: OwnershipDocument[];
  currentUser: UserSession;
  onCreatePolicyDraft: (policy: Partial<InsurancePolicy>) => Promise<void>;
  onSubmitPolicy: (policyId: string) => Promise<void>;
  onAmendPolicy: (policyId: string, policy: Partial<InsurancePolicy>) => Promise<void>;
  onRenewPolicy: (policyId: string, newAmount: number, newPremium: number, newExpiryDate: string) => Promise<void>;
}

export const PolicyManager: React.FC<PolicyManagerProps> = ({
  policies,
  endorsements,
  collaterals,
  customers,
  insurers,
  documents,
  currentUser,
  onCreatePolicyDraft,
  onSubmitPolicy,
  onAmendPolicy,
  onRenewPolicy,
}) => {
  const [selectedPolicy, setSelectedPolicy] = useState<InsurancePolicy | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showWizardModal, setShowWizardModal] = useState(false);
  const [showAmendModal, setShowAmendModal] = useState(false);
  const [showRenewModal, setShowRenewModal] = useState(false);

  // Wizard state (4-Step Registration)
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3 | 4>(1);
  const [wizardColId, setWizardColId] = useState('');
  const [wizardPolicy, setWizardPolicy] = useState<Partial<InsurancePolicy>>({
    policyNumber: `POL-2026-${Math.floor(100000 + Math.random() * 900000)}`,
    insurerName: insurers[0]?.name || 'Nyala Insurance S.C.',
    coverageType: 'Fire & Allied Perils',
    insuredAmount: 10000000,
    premium: 45000,
    effectiveDate: '2026-08-18',
    expiryDate: '2027-08-18',
    status: 'Draft',
  });

  // Amend & Renew states
  const [amendData, setAmendData] = useState<Partial<InsurancePolicy>>({});
  const [renewAmount, setRenewAmount] = useState(0);
  const [renewPremium, setRenewPremium] = useState(0);
  const [renewExpiryDate, setRenewExpiryDate] = useState('2027-08-18');

  const isMaker = ['CRO', 'BRO', 'SRM', 'BRM', 'SYSADMIN'].includes(currentUser.role);

  // Compute Days to Expiry
  const getDaysToExpiry = (expiryDate?: string) => {
    if (!expiryDate) return 0;
    const diff = new Date(expiryDate).getTime() - new Date().getTime();
    return Math.ceil(diff / (1000 * 3600 * 24));
  };

  const policyColumns: ColumnDef<InsurancePolicy>[] = [
    { header: 'Policy Number', accessorKey: 'policyNumber', sortable: true },
    { header: 'Insurer Name', accessorKey: 'insurerName', sortable: true },
    { header: 'Coverage Type', accessorKey: 'coverageType' },
    {
      header: 'Collateral Code',
      cell: (r) => {
        const col = collaterals.find((c) => c.id === r.collateralId);
        return <span>{col ? col.code : r.collateralId}</span>;
      },
    },
    {
      header: 'Insured Amount',
      accessorKey: 'insuredAmount',
      align: 'right',
      cell: (r) => `ETB ${r.insuredAmount?.toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
    },
    {
      header: 'Premium',
      accessorKey: 'premium',
      align: 'right',
      cell: (r) => `ETB ${r.premium?.toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
    },
    { header: 'Expiry Date', accessorKey: 'expiryDate', sortable: true },
    {
      header: 'Days to Expiry',
      align: 'center',
      cell: (r) => {
        const days = getDaysToExpiry(r.expiryDate);
        let color = '#1E8E5A';
        let bg = '#E5F6ED';
        if (days <= 0) {
          color = '#C0362C';
          bg = '#FCEAE8';
        } else if (days <= 7) {
          color = '#C0362C';
          bg = '#FCEAE8';
        } else if (days <= 30) {
          color = '#B8860B';
          bg = '#FFF6DF';
        }
        return (
          <span
            style={{
              backgroundColor: bg,
              color: color,
              padding: '2px 8px',
              borderRadius: '9999px',
              fontWeight: 700,
              fontSize: '11px',
            }}
            className="tabular-nums"
          >
            {days <= 0 ? 'Expired' : `${days}d`}
          </span>
        );
      },
    },
    {
      header: 'Status',
      accessorKey: 'status',
      cell: (r) => <StatusChip label={r.status} />,
    },
    {
      header: 'Action',
      align: 'right',
      cell: (r) => (
        <div className="flex items-center justify-end gap-1.5">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setSelectedPolicy(r);
              setShowDetailModal(true);
            }}
            className="btn-secondary py-1 px-2.5 text-xs"
          >
            <Eye className="w-3.5 h-3.5" />
            Details
          </button>
          {isMaker && r.status === 'Draft' && (
            <button
              onClick={async (e) => {
                e.stopPropagation();
                await onSubmitPolicy(r.id);
              }}
              className="btn-primary py-1 px-2.5 text-xs bg-brand-900"
              title="Submit policy to Checker for dual control authorization"
            >
              Submit to Checker
            </button>
          )}
          {r.status === 'Active' && isMaker && (
            <>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedPolicy(r);
                  setAmendData({
                    policyNumber: r.policyNumber,
                    insuredAmount: r.insuredAmount,
                    premium: r.premium,
                    coverageType: r.coverageType,
                    insurerName: r.insurerName,
                  });
                  setShowAmendModal(true);
                }}
                className="btn-secondary py-1 px-2 text-xs"
                title="Endorse / Amend Policy"
              >
                <Edit className="w-3.5 h-3.5" />
                Amend
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedPolicy(r);
                  setRenewAmount(r.insuredAmount);
                  setRenewPremium(r.premium);
                  setRenewExpiryDate('2027-08-18');
                  setShowRenewModal(true);
                }}
                className="btn-secondary py-1 px-2 text-xs text-brand-700"
                title="Renew Policy"
              >
                <RotateCw className="w-3.5 h-3.5" />
                Renew
              </button>
            </>
          )}
        </div>
      ),
    },
  ];

  // Wizard Collateral selection details
  const wizardSelectedCol = collaterals.find((c) => c.id === wizardColId);
  const wizardColVal = wizardSelectedCol?.valuationAmount || 0;
  const wizardInsAmount = wizardPolicy.insuredAmount || 0;
  const wizardCoveragePct = wizardColVal > 0 ? (wizardInsAmount / wizardColVal) * 100 : 100;

  // Selected Policy linked items
  const policyEndorsements = selectedPolicy ? endorsements.filter((e) => e.policyId === selectedPolicy.id) : [];
  const policyDocs = selectedPolicy ? documents.filter((d) => d.entityId === selectedPolicy.id) : [];

  return (
    <div className="p-6 space-y-6">
      <DataGrid
        title="Insurance Policies Management"
        subtitle="Full Policy Lifecycle: Registration, Endorsements, Amendments, Renewals, and Coverage Adequacy"
        data={policies}
        columns={policyColumns}
        keyExtractor={(p) => p.id}
        onRowClick={(p) => {
          setSelectedPolicy(p);
          setShowDetailModal(true);
        }}
        actions={
          isMaker ? (
            <button
              onClick={() => {
                setWizardColId(collaterals[0]?.id || '');
                setWizardStep(1);
                setWizardPolicy({
                  policyNumber: `POL-2026-${Math.floor(100000 + Math.random() * 900000)}`,
                  insurerName: insurers[0]?.name || 'Nyala Insurance S.C.',
                  coverageType: 'Fire & Allied Perils',
                  insuredAmount: 10000000,
                  premium: 45000,
                  effectiveDate: '2026-08-18',
                  expiryDate: '2027-08-18',
                  status: 'Draft',
                });
                setShowWizardModal(true);
              }}
              className="btn-primary py-1.5 px-3 text-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              + Register New Policy (Wizard)
            </button>
          ) : undefined
        }
      />

      {/* Policy Detail Modal */}
      {showDetailModal && selectedPolicy && (
        <div className="fixed inset-0 bg-brand-900/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl border border-border shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden text-xs">
            {/* Header */}
            <div className="p-5 bg-brand-900 text-white flex justify-between items-start">
              <div>
                <div className="flex items-center gap-3">
                  <h2 className="text-lg font-bold">{selectedPolicy.policyNumber}</h2>
                  <StatusChip label={selectedPolicy.status} />
                  <span className="text-xs px-2 py-0.5 rounded bg-brand-700 text-white font-medium">
                    v{selectedPolicy.version}
                  </span>
                </div>
                <div className="text-xs text-blue-200 mt-1 flex gap-4">
                  <span>Insurer: {selectedPolicy.insurerName}</span>
                  <span>Coverage: {selectedPolicy.coverageType}</span>
                  <span>Term: {selectedPolicy.effectiveDate} to {selectedPolicy.expiryDate}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2">
                {isMaker && (
                  <>
                    <button
                      onClick={() => {
                        setAmendData(selectedPolicy);
                        setShowAmendModal(true);
                      }}
                      className="btn-secondary py-1.5 px-3 text-xs bg-brand-800 border-brand-700 text-white hover:bg-brand-700"
                    >
                      <Edit className="w-3.5 h-3.5" />
                      Amend Policy
                    </button>
                    <button
                      onClick={() => {
                        setRenewAmount(selectedPolicy.insuredAmount);
                        setRenewPremium(selectedPolicy.premium);
                        setRenewExpiryDate('2027-08-18');
                        setShowRenewModal(true);
                      }}
                      className="btn-secondary py-1.5 px-3 text-xs bg-brand-800 border-brand-700 text-white hover:bg-brand-700"
                    >
                      <RotateCw className="w-3.5 h-3.5" />
                      Renew Policy
                    </button>
                  </>
                )}
                <button onClick={() => setShowDetailModal(false)} className="text-white hover:text-gray-300 text-lg ml-2">
                  ✕
                </button>
              </div>
            </div>

            {/* Body */}
            <div className="p-6 overflow-y-auto flex-1 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="cims-card p-4 space-y-2">
                  <h4 className="font-bold text-text-primary border-b border-border pb-1">Policy Financials & Coverage</h4>
                  <div><span className="text-text-secondary">Insured Amount:</span> <strong className="tabular-nums">ETB {selectedPolicy.insuredAmount?.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong></div>
                  <div><span className="text-text-secondary">Annual Premium:</span> <strong className="tabular-nums">ETB {selectedPolicy.premium?.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong></div>
                  <div><span className="text-text-secondary">Effective Date:</span> <strong>{selectedPolicy.effectiveDate}</strong></div>
                  <div><span className="text-text-secondary">Expiry Date:</span> <strong>{selectedPolicy.expiryDate}</strong></div>
                </div>
                <div className="cims-card p-4 space-y-2">
                  <h4 className="font-bold text-text-primary border-b border-border pb-1">Governance & Audit</h4>
                  <div><span className="text-text-secondary">Collateral ID:</span> <strong>{selectedPolicy.collateralId}</strong></div>
                  <div><span className="text-text-secondary">Maker ID:</span> <strong>{selectedPolicy.makerId || 'System'}</strong></div>
                  <div><span className="text-text-secondary">Checker ID:</span> <strong>{selectedPolicy.checkerId || 'Pending'}</strong></div>
                  <div><span className="text-text-secondary">Record Status:</span> <strong>{selectedPolicy.recordStat === 'O' ? 'Authorized (Open)' : 'Unauthorized'}</strong></div>
                </div>
              </div>

              {/* Endorsements Section */}
              <div className="space-y-2">
                <h4 className="font-bold text-text-primary">Policy Endorsements ({policyEndorsements.length})</h4>
                <div className="cims-card overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-brand-50 border-b border-border text-text-secondary font-semibold">
                      <tr>
                        <th className="p-2.5">Endorsement No.</th>
                        <th className="p-2.5">Description</th>
                        <th className="p-2.5">Effective Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {policyEndorsements.length === 0 ? (
                        <tr>
                          <td colSpan={3} className="text-center py-4 text-text-secondary">
                            No endorsements recorded on this policy.
                          </td>
                        </tr>
                      ) : (
                        policyEndorsements.map((e) => (
                          <tr key={e.id} className="hover:bg-brand-50">
                            <td className="p-2.5 font-semibold">{e.endorsementNo}</td>
                            <td className="p-2.5">{e.description}</td>
                            <td className="p-2.5">{e.effectiveDate}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4-Step Registration Wizard Modal */}
      {showWizardModal && (
        <div className="fixed inset-0 bg-brand-900/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl border border-border shadow-2xl max-w-2xl w-full overflow-hidden text-xs">
            {/* Header */}
            <div className="p-4 bg-brand-900 text-white flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold">Policy Registration Wizard</h3>
                <p className="text-[11px] text-blue-200">Step {wizardStep} of 4</p>
              </div>
              <button onClick={() => setShowWizardModal(false)} className="text-white hover:text-gray-300">✕</button>
            </div>

            {/* Stepper Indicator */}
            <div className="grid grid-cols-4 bg-brand-50 border-b border-border text-center py-2.5 text-[11px] font-semibold">
              <div className={wizardStep === 1 ? 'text-brand-900 font-bold border-b-2 border-brand-900' : 'text-text-secondary'}>
                1. Select Collateral
              </div>
              <div className={wizardStep === 2 ? 'text-brand-900 font-bold border-b-2 border-brand-900' : 'text-text-secondary'}>
                2. Policy Details
              </div>
              <div className={wizardStep === 3 ? 'text-brand-900 font-bold border-b-2 border-brand-900' : 'text-text-secondary'}>
                3. Adequacy Check
              </div>
              <div className={wizardStep === 4 ? 'text-brand-900 font-bold border-b-2 border-brand-900' : 'text-text-secondary'}>
                4. Submit to Checker
              </div>
            </div>

            {/* Step Body */}
            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              {wizardStep === 1 && (
                <div className="space-y-4">
                  <label className="block font-semibold text-text-primary">Select Pledged Collateral Asset (M)</label>
                  <select
                    value={wizardColId}
                    onChange={(e) => {
                      setWizardColId(e.target.value);
                      const col = collaterals.find((c) => c.id === e.target.value);
                      if (col) {
                        setWizardPolicy({ ...wizardPolicy, collateralId: col.id, customerId: col.customerId, insuredAmount: col.valuationAmount });
                      }
                    }}
                    className="w-full p-2.5 border border-border rounded text-xs"
                  >
                    {collaterals.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.code} — {c.description} ({c.currency || 'ETB'} {c.valuationAmount?.toLocaleString()})
                      </option>
                    ))}
                  </select>

                  {wizardSelectedCol && (
                    <div className="cims-card p-4 space-y-2 bg-brand-50">
                      <div><span className="text-text-secondary">Category:</span> <strong>{wizardSelectedCol.category}</strong></div>
                      <div><span className="text-text-secondary">Estimated Valuation:</span> <strong>{wizardSelectedCol.currency || 'ETB'} {wizardSelectedCol.valuationAmount?.toLocaleString()}</strong></div>
                      <div><span className="text-text-secondary">Branch:</span> <strong>{wizardSelectedCol.branch}</strong></div>
                      <div><span className="text-text-secondary">Segment:</span> <strong>{wizardSelectedCol.owningSegment}</strong></div>
                    </div>
                  )}
                </div>
              )}

              {wizardStep === 2 && (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-text-primary mb-1">Policy Number (M)</label>
                      <input
                        type="text"
                        required
                        value={wizardPolicy.policyNumber || ''}
                        onChange={(e) => setWizardPolicy({ ...wizardPolicy, policyNumber: e.target.value })}
                        className="w-full p-2 border border-border rounded"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-text-primary mb-1">Approved Insurer (M)</label>
                      <select
                        value={wizardPolicy.insurerName}
                        onChange={(e) => setWizardPolicy({ ...wizardPolicy, insurerName: e.target.value })}
                        className="w-full p-2 border border-border rounded"
                      >
                        {insurers.map((i) => (
                          <option key={i.id} value={i.name}>
                            {i.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-text-primary mb-1">Coverage Type (M)</label>
                      <select
                        value={wizardPolicy.coverageType}
                        onChange={(e) => setWizardPolicy({ ...wizardPolicy, coverageType: e.target.value })}
                        className="w-full p-2 border border-border rounded"
                      >
                        <option value="Fire & Allied Perils">Fire & Allied Perils</option>
                        <option value="Comprehensive Motor">Comprehensive Motor</option>
                        <option value="Burglary & Housebreaking">Burglary & Housebreaking</option>
                        <option value="Machinery Breakdown">Machinery Breakdown</option>
                        <option value="All Risks">All Risks</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-semibold text-text-primary mb-1">Insured Amount (ETB) (M)</label>
                      <input
                        type="number"
                        required
                        value={wizardPolicy.insuredAmount || 0}
                        onChange={(e) => setWizardPolicy({ ...wizardPolicy, insuredAmount: Number(e.target.value) })}
                        className="w-full p-2 border border-border rounded tabular-nums"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-text-primary mb-1">Effective Date (M)</label>
                      <input
                        type="date"
                        required
                        value={wizardPolicy.effectiveDate || ''}
                        onChange={(e) => setWizardPolicy({ ...wizardPolicy, effectiveDate: e.target.value })}
                        className="w-full p-2 border border-border rounded"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-text-primary mb-1">Expiry Date (M)</label>
                      <input
                        type="date"
                        required
                        value={wizardPolicy.expiryDate || ''}
                        onChange={(e) => setWizardPolicy({ ...wizardPolicy, expiryDate: e.target.value })}
                        className="w-full p-2 border border-border rounded"
                      />
                    </div>
                  </div>
                </div>
              )}

              {wizardStep === 3 && (
                <div className="space-y-4">
                  <div className="cims-card p-4 bg-brand-50 border-brand-100 flex items-center justify-between">
                    <div>
                      <div className="text-[11px] uppercase font-bold text-brand-700 tracking-wider">Coverage Adequacy Evaluation</div>
                      <div className="text-xs text-text-secondary mt-1">Collateral Valuation: <strong>ETB {wizardColVal.toLocaleString()}</strong></div>
                      <div className="text-xs text-text-secondary">Proposed Insured Amount: <strong>ETB {wizardInsAmount.toLocaleString()}</strong></div>
                    </div>
                    <CircularProgress value={wizardCoveragePct} size={80} strokeWidth={8} label="Adequacy %" />
                  </div>

                  <div className={`p-3 rounded-lg border flex items-center gap-2 ${wizardCoveragePct >= 100 ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-amber-50 border-amber-200 text-amber-800'}`}>
                    {wizardCoveragePct >= 100 ? <CheckCircle className="w-5 h-5 flex-shrink-0" /> : <AlertTriangle className="w-5 h-5 flex-shrink-0" />}
                    <span>
                      {wizardCoveragePct >= 100
                        ? 'Policy satisfies 100% full coverage adequacy threshold.'
                        : 'Warning: Proposed insured amount is less than collateral valuation (Underinsured).'}
                    </span>
                  </div>
                </div>
              )}

              {wizardStep === 4 && (
                <div className="space-y-3">
                  <div className="cims-card p-4 space-y-2">
                    <h4 className="font-bold text-text-primary border-b border-border pb-1">Review Policy Summary</h4>
                    <div><span className="text-text-secondary">Policy Number:</span> <strong>{wizardPolicy.policyNumber}</strong></div>
                    <div><span className="text-text-secondary">Insurer:</span> <strong>{wizardPolicy.insurerName}</strong></div>
                    <div><span className="text-text-secondary">Insured Amount:</span> <strong>ETB {wizardInsAmount.toLocaleString()}</strong></div>
                    <div><span className="text-text-secondary">Term:</span> <strong>{wizardPolicy.effectiveDate} to {wizardPolicy.expiryDate}</strong></div>
                  </div>

                  <div className="p-3 bg-blue-50 border border-blue-200 rounded text-blue-900">
                    Submitting this policy will initialize a Flowable BPMN workflow task routed to the Branch Manager Checker for authorization.
                  </div>
                </div>
              )}
            </div>

            {/* Stepper Footer Buttons */}
            <div className="p-4 border-t border-border bg-white flex justify-between">
              <button
                type="button"
                onClick={() => (wizardStep === 1 ? setShowWizardModal(false) : setWizardStep((wizardStep - 1) as any))}
                className="btn-secondary"
              >
                {wizardStep === 1 ? 'Cancel' : 'Back'}
              </button>

              {wizardStep < 4 ? (
                <button
                  type="button"
                  onClick={() => setWizardStep((wizardStep + 1) as any)}
                  className="btn-primary"
                >
                  Continue to Step {wizardStep + 1}
                </button>
              ) : (
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={async () => {
                      await onCreatePolicyDraft({
                        ...wizardPolicy,
                        collateralId: wizardColId || collaterals[0]?.id,
                        status: 'Draft',
                      });
                      setShowWizardModal(false);
                    }}
                    className="btn-secondary"
                  >
                    Save as Draft
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      await onCreatePolicyDraft({
                        ...wizardPolicy,
                        collateralId: wizardColId || collaterals[0]?.id,
                        status: 'Pending Approval',
                      });
                      setShowWizardModal(false);
                    }}
                    className="btn-primary bg-emerald-700 hover:bg-emerald-800"
                  >
                    Submit for Checker Authorization
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Amend Policy Modal */}
      {showAmendModal && selectedPolicy && (
        <div className="fixed inset-0 bg-brand-900/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg border border-border shadow-xl max-w-md w-full overflow-hidden text-xs">
            <div className="p-4 bg-brand-900 text-white flex justify-between items-center">
              <h3 className="text-sm font-bold">Amend Policy — {selectedPolicy.policyNumber}</h3>
              <button onClick={() => setShowAmendModal(false)} className="text-white hover:text-gray-300">✕</button>
            </div>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                await onAmendPolicy(selectedPolicy.id, amendData);
                setShowAmendModal(false);
                setShowDetailModal(false);
              }}
              className="p-5 space-y-3"
            >
              <div>
                <label className="block font-semibold text-text-primary mb-1">Insured Amount (ETB) (M)</label>
                <input
                  type="number"
                  required
                  value={amendData.insuredAmount || 0}
                  onChange={(e) => setAmendData({ ...amendData, insuredAmount: Number(e.target.value) })}
                  className="w-full p-2 border border-border rounded tabular-nums"
                />
              </div>

              <div>
                <label className="block font-semibold text-text-primary mb-1">Annual Premium (ETB) (M)</label>
                <input
                  type="number"
                  required
                  value={amendData.premium || 0}
                  onChange={(e) => setAmendData({ ...amendData, premium: Number(e.target.value) })}
                  className="w-full p-2 border border-border rounded tabular-nums"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-border">
                <button type="button" onClick={() => setShowAmendModal(false)} className="btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  Save Amendment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Renew Policy Modal */}
      {showRenewModal && selectedPolicy && (
        <div className="fixed inset-0 bg-brand-900/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg border border-border shadow-xl max-w-md w-full overflow-hidden text-xs">
            <div className="p-4 bg-brand-900 text-white flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold">Renew Policy — {selectedPolicy.policyNumber}</h3>
                <p className="text-[11px] text-blue-200">Creates renewed policy record for next term</p>
              </div>
              <button onClick={() => setShowRenewModal(false)} className="text-white hover:text-gray-300">✕</button>
            </div>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                await onRenewPolicy(selectedPolicy.id, renewAmount, renewPremium, renewExpiryDate);
                setShowRenewModal(false);
                setShowDetailModal(false);
              }}
              className="p-5 space-y-3"
            >
              <div>
                <label className="block font-semibold text-text-primary mb-1">New Term Expiry Date (M)</label>
                <input
                  type="date"
                  required
                  value={renewExpiryDate}
                  onChange={(e) => setRenewExpiryDate(e.target.value)}
                  className="w-full p-2 border border-border rounded"
                />
              </div>

              <div>
                <label className="block font-semibold text-text-primary mb-1">Renewal Insured Amount (ETB) (M)</label>
                <input
                  type="number"
                  required
                  value={renewAmount}
                  onChange={(e) => setRenewAmount(Number(e.target.value))}
                  className="w-full p-2 border border-border rounded tabular-nums"
                />
              </div>

              <div>
                <label className="block font-semibold text-text-primary mb-1">Renewal Premium (ETB) (M)</label>
                <input
                  type="number"
                  required
                  value={renewPremium}
                  onChange={(e) => setRenewPremium(Number(e.target.value))}
                  className="w-full p-2 border border-border rounded tabular-nums"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-border">
                <button type="button" onClick={() => setShowRenewModal(false)} className="btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  Process Renewal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
