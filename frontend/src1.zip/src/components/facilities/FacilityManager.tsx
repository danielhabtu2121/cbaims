import React, { useState } from 'react';
import { CreditCard, Building2, Eye, ShieldCheck, AlertCircle } from 'lucide-react';
import { LoanAccount, Customer, Collateral, LoanCollateralLink, InsurancePolicy } from '../../types';
import { DataGrid, ColumnDef } from '../layout/DataGrid';
import { StatusChip } from '../layout/StatusChip';
import { CircularProgress } from '../layout/CircularProgress';

interface FacilityManagerProps {
  facilities: LoanAccount[];
  customers: Customer[];
  collaterals: Collateral[];
  links: LoanCollateralLink[];
  policies: InsurancePolicy[];
}

export const FacilityManager: React.FC<FacilityManagerProps> = ({
  facilities,
  customers,
  collaterals,
  links,
  policies,
}) => {
  const [selectedFacility, setSelectedFacility] = useState<LoanAccount | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'collateral'>('details');

  const facilityColumns: ColumnDef<LoanAccount>[] = [
    { header: 'Line Code', accessorKey: 'lineCode', sortable: true },
    { header: 'Loan Ref No.', accessorKey: 'loanReference', sortable: true },
    {
      header: 'Customer',
      cell: (r) => {
        const cust = customers.find((c) => c.id === r.customerId || c.cif === r.customerId);
        return <span>{cust ? cust.name : r.customerId}</span>;
      },
      sortable: true,
    },
    { header: 'Facility Type', accessorKey: 'facilityType' },
    {
      header: 'Approved Limit',
      accessorKey: 'approvedLimit',
      align: 'right',
      cell: (r) => `${r.lineCurrency} ${r.approvedLimit?.toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
    },
    {
      header: 'Outstanding',
      accessorKey: 'outstandingBalance',
      align: 'right',
      cell: (r) => `${r.lineCurrency} ${r.outstandingBalance?.toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
    },
    { header: 'Segment', accessorKey: 'segment' },
    { header: 'Branch', accessorKey: 'branch' },
    {
      header: 'Status',
      accessorKey: 'status',
      cell: (r) => <StatusChip label={r.status} />,
    },
    {
      header: 'Action',
      align: 'right',
      cell: (r) => (
        <button
          onClick={(e) => {
            e.stopPropagation();
            setSelectedFacility(r);
            setShowDetailModal(true);
          }}
          className="btn-ghost py-1 px-2 text-xs"
        >
          <Eye className="w-3.5 h-3.5" />
          View
        </button>
      ),
    },
  ];

  // Linked collateral items for the selected facility
  const facilityLinks = selectedFacility ? links.filter((l) => l.loanAccountId === selectedFacility.id) : [];
  const linkedColIds = facilityLinks.map((l) => l.collateralId);
  const linkedCollaterals = collaterals.filter((c) => linkedColIds.includes(c.id));

  // Compute aggregate metrics
  const totalPledgedValue = linkedCollaterals.reduce((sum, c) => sum + (c.valuationAmount || 0), 0);
  const totalInsuredAmount = linkedCollaterals.reduce((sum, c) => sum + (c.insuredAmount || 0), 0);
  const outstandingExposure = selectedFacility?.outstandingBalance || 0;
  const coveragePct = outstandingExposure > 0 ? (totalInsuredAmount / outstandingExposure) * 100 : totalInsuredAmount > 0 ? 100 : 0;

  return (
    <div className="p-6 space-y-6">
      <DataGrid
        title="Credit Facilities & Loans (GETM_FACILITY)"
        subtitle="Core Banking Credit Lines and Outstanding Balances"
        data={facilities}
        columns={facilityColumns}
        keyExtractor={(f) => f.id}
        onRowClick={(f) => {
          setSelectedFacility(f);
          setShowDetailModal(true);
        }}
      />

      {/* Facility Detail Modal */}
      {showDetailModal && selectedFacility && (
        <div className="fixed inset-0 bg-brand-900/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl border border-border shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden">
            <div className="p-5 bg-brand-900 text-white flex justify-between items-start">
              <div>
                <div className="flex items-center gap-3">
                  <h2 className="text-lg font-bold">{selectedFacility.lineCode} — {selectedFacility.facilityType}</h2>
                  <StatusChip label={selectedFacility.status} />
                </div>
                <div className="text-xs text-blue-200 mt-1 flex gap-4">
                  <span>Loan Ref: {selectedFacility.loanReference}</span>
                  <span>Segment: {selectedFacility.segment}</span>
                  <span>Branch: {selectedFacility.branch}</span>
                </div>
              </div>
              <button onClick={() => setShowDetailModal(false)} className="text-white hover:text-gray-300 text-lg">
                ✕
              </button>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-border bg-brand-50 px-6 gap-2 pt-2">
              <button
                onClick={() => setActiveTab('details')}
                className={`pb-2.5 px-3 text-xs font-semibold border-b-2 ${
                  activeTab === 'details' ? 'border-brand-900 text-brand-900' : 'border-transparent text-text-secondary'
                }`}
              >
                Facility Details (CBS Read-Only)
              </button>
              <button
                onClick={() => setActiveTab('collateral')}
                className={`pb-2.5 px-3 text-xs font-semibold border-b-2 ${
                  activeTab === 'collateral' ? 'border-brand-900 text-brand-900' : 'border-transparent text-text-secondary'
                }`}
              >
                Linked Collateral & Insurance Adequacy ({linkedCollaterals.length})
              </button>
            </div>

            {/* Tab Contents */}
            <div className="p-6 overflow-y-auto flex-1 space-y-4 text-xs">
              {activeTab === 'details' && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="cims-card p-4 space-y-2">
                    <h4 className="font-bold text-text-primary text-xs border-b border-border pb-1">Facility Limits & Balances</h4>
                    <div><span className="text-text-secondary">Approved Limit:</span> <strong className="tabular-nums">{selectedFacility.lineCurrency} {selectedFacility.approvedLimit?.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong></div>
                    <div><span className="text-text-secondary">Outstanding Balance:</span> <strong className="tabular-nums">{selectedFacility.lineCurrency} {selectedFacility.outstandingBalance?.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong></div>
                    <div><span className="text-text-secondary">Available Amount:</span> <strong className="tabular-nums">{selectedFacility.lineCurrency} {selectedFacility.availableAmount?.toLocaleString(undefined, { minimumFractionDigits: 2 })}</strong></div>
                    <div><span className="text-text-secondary">Revolving Line:</span> <strong>{selectedFacility.revolvingLine ? 'Yes' : 'No'}</strong></div>
                  </div>
                  <div className="cims-card p-4 space-y-2">
                    <h4 className="font-bold text-text-primary text-xs border-b border-border pb-1">Schedule & Relationship</h4>
                    <div><span className="text-text-secondary">Start Date:</span> <strong>{selectedFacility.lineStartDate}</strong></div>
                    <div><span className="text-text-secondary">Expiry Date:</span> <strong>{selectedFacility.lineExpiryDate}</strong></div>
                    <div><span className="text-text-secondary">Next Review Date:</span> <strong>{selectedFacility.nextReviewDueDate || '—'}</strong></div>
                    <div><span className="text-text-secondary">Relationship Manager:</span> <strong>{selectedFacility.rmUserId || '—'}</strong></div>
                  </div>
                </div>
              )}

              {activeTab === 'collateral' && (
                <div className="space-y-4">
                  {/* Aggregate Exposure Summary Card */}
                  <div className="cims-card p-4 bg-brand-50 border-brand-100 flex items-center justify-between gap-6">
                    <div className="space-y-1">
                      <div className="text-[11px] font-bold uppercase text-brand-700 tracking-wider">
                        Aggregate Facility Exposure & Coverage Summary
                      </div>
                      <div className="text-xs text-text-secondary">
                        Outstanding Loan Exposure:{' '}
                        <strong className="text-text-primary tabular-nums">
                          {selectedFacility.lineCurrency} {outstandingExposure.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </strong>
                      </div>
                      <div className="text-xs text-text-secondary">
                        Total Pledged Collateral Value:{' '}
                        <strong className="text-text-primary tabular-nums">
                          {selectedFacility.lineCurrency} {totalPledgedValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </strong>
                      </div>
                      <div className="text-xs text-text-secondary">
                        Total Active Insured Amount:{' '}
                        <strong className="text-text-primary tabular-nums">
                          {selectedFacility.lineCurrency} {totalInsuredAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </strong>
                      </div>
                    </div>

                    {/* Circular Coverage Gauge */}
                    <div className="flex items-center gap-4 bg-white p-3 rounded-lg border border-border">
                      <CircularProgress value={coveragePct} size={80} strokeWidth={8} label="Net Coverage" />
                      <div className="text-xs space-y-1">
                        <div className="font-bold text-text-primary">
                          {coveragePct >= 100 ? 'Adequately Insured' : coveragePct >= 70 ? 'Underinsured' : 'Uninsured / Critical'}
                        </div>
                        <div className="text-[11px] text-text-secondary">
                          Required Threshold: 100.0%
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Visual Comparison Bar */}
                  <div className="cims-card p-4 space-y-2">
                    <div className="flex justify-between text-xs font-semibold">
                      <span>Outstanding Exposure: {selectedFacility.lineCurrency} {outstandingExposure.toLocaleString()}</span>
                      <span>Total Insured: {selectedFacility.lineCurrency} {totalInsuredAmount.toLocaleString()} ({coveragePct.toFixed(1)}%)</span>
                    </div>
                    <div className="w-full h-3 bg-red-100 rounded-full overflow-hidden flex">
                      <div
                        className="h-full bg-emerald-500 transition-all duration-500"
                        style={{ width: `${Math.min(100, coveragePct)}%` }}
                      />
                    </div>
                  </div>

                  {/* Linked Collateral Grid */}
                  <div className="cims-card overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-brand-50 border-b border-border text-text-secondary font-semibold">
                        <tr>
                          <th className="p-2.5">Collateral Code</th>
                          <th className="p-2.5">Description</th>
                          <th className="p-2.5">Category</th>
                          <th className="p-2.5 text-right">Valuation Amount</th>
                          <th className="p-2.5 text-right">Allocated Amount</th>
                          <th className="p-2.5">Insurance Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {linkedCollaterals.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="text-center py-6 text-text-secondary">
                              No collateral pledged for this facility.
                            </td>
                          </tr>
                        ) : (
                          linkedCollaterals.map((c) => {
                            const link = facilityLinks.find((l) => l.collateralId === c.id);
                            return (
                              <tr key={c.id} className="hover:bg-brand-50">
                                <td className="p-2.5 font-semibold">{c.code}</td>
                                <td className="p-2.5">{c.description}</td>
                                <td className="p-2.5">{c.category}</td>
                                <td className="p-2.5 text-right tabular-nums">
                                  {c.currency || 'ETB'} {c.valuationAmount?.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                </td>
                                <td className="p-2.5 text-right tabular-nums font-semibold">
                                  {c.currency || 'ETB'} {link?.allocatedAmount?.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                </td>
                                <td className="p-2.5"><StatusChip label={c.insuranceStatus || c.status} /></td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
