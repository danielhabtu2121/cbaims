import React from 'react';
import {
  LayoutDashboard,
  Users,
  CreditCard,
  Building2,
  FileCheck,
  CheckSquare,
  AlertTriangle,
  FolderOpen,
  BarChart3,
  Bell,
  Settings,
  History,
  Cpu,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { RoleCode } from '../../types';

export type NavPageId =
  | 'dashboard'
  | 'customers'
  | 'facilities'
  | 'collateral'
  | 'insurance'
  | 'approvals'
  | 'exceptions'
  | 'documents'
  | 'reports'
  | 'notifications'
  | 'admin'
  | 'audit'
  | 'cbs-sim';

interface NavItemDef {
  id: NavPageId;
  label: string;
  icon: React.ElementType;
  section: string;
  allowedRoles: RoleCode[];
  badgeCount?: number;
}

interface SidebarProps {
  activePage: NavPageId;
  onNavigate: (page: NavPageId) => void;
  userRole: RoleCode;
  pendingApprovalCount?: number;
  openExceptionCount?: number;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activePage,
  onNavigate,
  userRole,
  pendingApprovalCount = 0,
  openExceptionCount = 0,
  collapsed,
  onToggleCollapse,
}) => {
  const allRoles: RoleCode[] = [
    'EXEC',
    'SYSADMIN',
    'SRMGMT',
    'HODEPT',
    'DISTDIR',
    'BRMGR',
    'SRM',
    'BRM',
    'CRO',
    'BRO',
    'MGRCOLLDOC',
    'COLLDOCOFF',
    'COMPLIANCE',
    'RISK',
    'AUDITOR',
    'RDONLY',
  ];

  const navItems: NavItemDef[] = [
    { id: 'dashboard', label: 'My Dashboard', icon: LayoutDashboard, section: 'Core', allowedRoles: allRoles },
    {
      id: 'customers',
      label: 'Customers',
      icon: Users,
      section: 'Portfolios',
      allowedRoles: ['EXEC', 'SRMGMT', 'HODEPT', 'DISTDIR', 'BRMGR', 'SRM', 'BRM', 'CRO', 'BRO', 'COMPLIANCE', 'RISK', 'AUDITOR', 'RDONLY'],
    },
    {
      id: 'facilities',
      label: 'Facilities / Loans',
      icon: CreditCard,
      section: 'Portfolios',
      allowedRoles: ['EXEC', 'SRMGMT', 'HODEPT', 'DISTDIR', 'BRMGR', 'SRM', 'BRM', 'CRO', 'BRO', 'COMPLIANCE', 'RISK', 'AUDITOR', 'RDONLY'],
    },
    {
      id: 'collateral',
      label: 'Collateral',
      icon: Building2,
      section: 'Portfolios',
      allowedRoles: ['EXEC', 'SRMGMT', 'HODEPT', 'DISTDIR', 'BRMGR', 'SRM', 'BRM', 'CRO', 'BRO', 'MGRCOLLDOC', 'COLLDOCOFF', 'COMPLIANCE', 'RISK', 'AUDITOR', 'RDONLY'],
    },
    {
      id: 'insurance',
      label: 'Insurance Policies',
      icon: FileCheck,
      section: 'Portfolios',
      allowedRoles: ['EXEC', 'SRMGMT', 'HODEPT', 'DISTDIR', 'BRMGR', 'SRM', 'BRM', 'CRO', 'BRO', 'COMPLIANCE', 'RISK', 'AUDITOR', 'RDONLY'],
    },
    {
      id: 'approvals',
      label: 'Workflow Approvals',
      icon: CheckSquare,
      section: 'Governance',
      allowedRoles: allRoles,
      badgeCount: pendingApprovalCount,
    },
    {
      id: 'exceptions',
      label: 'Exceptions',
      icon: AlertTriangle,
      section: 'Governance',
      allowedRoles: allRoles,
      badgeCount: openExceptionCount,
    },
    {
      id: 'documents',
      label: 'Documents (DMS)',
      icon: FolderOpen,
      section: 'Governance',
      allowedRoles: allRoles,
    },
    { id: 'reports', label: 'Reports', icon: BarChart3, section: 'Analytics', allowedRoles: allRoles },
    { id: 'audit', label: 'Audit Trail', icon: History, section: 'Analytics', allowedRoles: allRoles },
    { id: 'notifications', label: 'Notifications', icon: Bell, section: 'System', allowedRoles: allRoles },
    { id: 'admin', label: 'Administration', icon: Settings, section: 'System', allowedRoles: ['SYSADMIN'] },
    { id: 'cbs-sim', label: 'CBS Simulator', icon: Cpu, section: 'System', allowedRoles: ['SYSADMIN', 'AUDITOR'] },
  ];

  const visibleItems = navItems.filter((item) => item.allowedRoles.includes(userRole));

  const sections = Array.from(new Set(visibleItems.map((i) => i.section)));

  return (
    <aside
      style={{
        width: collapsed ? '64px' : '240px',
        backgroundColor: '#0B2545',
        color: '#FFFFFF',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        transition: 'width 0.2s ease',
        borderRight: '1px solid #123362',
        position: 'sticky',
        top: '56px',
        height: 'calc(100vh - 56px)',
        overflowY: 'auto',
        overflowX: 'hidden',
        zIndex: 30,
        flexShrink: 0,
      }}
    >
      <div style={{ padding: collapsed ? '12px 6px' : '16px 12px' }}>
        {sections.map((sec) => {
          const itemsInSection = visibleItems.filter((i) => i.section === sec);
          return (
            <div key={sec} style={{ marginBottom: '18px' }}>
              {!collapsed && (
                <div
                  style={{
                    fontSize: '10px',
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    color: '#8A97A8',
                    letterSpacing: '0.8px',
                    padding: '0 10px 6px 10px',
                  }}
                >
                  {sec}
                </div>
              )}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                {itemsInSection.map((item) => {
                  const Icon = item.icon;
                  const isActive = activePage === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => onNavigate(item.id)}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: collapsed ? 'center' : 'space-between',
                        padding: collapsed ? '10px 0' : '9px 12px',
                        borderRadius: '6px',
                        backgroundColor: isActive ? '#123362' : 'transparent',
                        color: isActive ? '#FFFFFF' : '#B8C6DE',
                        fontWeight: isActive ? 700 : 500,
                        fontSize: '13px',
                        border: 'none',
                        borderLeft: isActive ? '4px solid #1D4E89' : '4px solid transparent',
                        cursor: 'pointer',
                        transition: 'all 0.15s ease',
                        width: '100%',
                        textAlign: 'left',
                      }}
                      title={collapsed ? item.label : undefined}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <Icon style={{ width: '18px', height: '18px', color: isActive ? '#FFFFFF' : '#B8C6DE', flexShrink: 0 }} />
                        {!collapsed && <span>{item.label}</span>}
                      </div>

                      {!collapsed && item.badgeCount !== undefined && item.badgeCount > 0 && (
                        <span
                          style={{
                            backgroundColor: item.id === 'exceptions' ? '#C0362C' : '#B8860B',
                            color: '#FFFFFF',
                            fontSize: '10px',
                            fontWeight: 700,
                            borderRadius: '9999px',
                            padding: '1px 6px',
                          }}
                        >
                          {item.badgeCount}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Collapse/Expand Footer Toggle */}
      <div style={{ padding: '12px', borderTop: '1px solid #123362' }}>
        <button
          onClick={onToggleCollapse}
          style={{
            width: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: collapsed ? 'center' : 'flex-start',
            gap: '8px',
            backgroundColor: 'transparent',
            color: '#B8C6DE',
            border: 'none',
            fontSize: '11px',
            cursor: 'pointer',
            padding: '6px 8px',
            borderRadius: '4px',
          }}
        >
          {collapsed ? <ChevronRight style={{ width: '16px', height: '16px' }} /> : <ChevronLeft style={{ width: '16px', height: '16px' }} />}
          {!collapsed && <span>Collapse Sidebar</span>}
        </button>
      </div>
    </aside>
  );
};
