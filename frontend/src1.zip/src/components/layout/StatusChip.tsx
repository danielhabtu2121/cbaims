import React from 'react';

export type StatusVariant =
  | 'success'
  | 'warning'
  | 'danger'
  | 'info'
  | 'neutral';

interface StatusChipProps {
  label: string;
  variant?: StatusVariant;
  size?: 'sm' | 'md';
}

export const StatusChip: React.FC<StatusChipProps> = ({ label, variant, size = 'sm' }) => {
  let resolvedVariant: StatusVariant = variant || 'neutral';

  if (!variant) {
    const l = (label || '').toLowerCase();
    if (l.includes('insured') && !l.includes('under') && !l.includes('un')) resolvedVariant = 'success';
    else if (l.includes('active') || l.includes('approved') || l.includes('verified') || l.includes('synced') || l.includes('fully')) resolvedVariant = 'success';
    else if (l.includes('pending') || l.includes('expiring') || l.includes('under') || l.includes('draft') || l.includes('returned')) resolvedVariant = 'warning';
    else if (l.includes('expired') || l.includes('uninsured') || l.includes('rejected') || l.includes('failed') || l.includes('critical') || l.includes('default') || l.includes('blocked')) resolvedVariant = 'danger';
    else if (l.includes('info') || l.includes('progress') || l.includes('review')) resolvedVariant = 'info';
    else resolvedVariant = 'neutral';
  }

  const styles: Record<StatusVariant, { bg: string; color: string; border: string }> = {
    success: { bg: '#E5F6ED', color: '#1E8E5A', border: '#A6E5C5' },
    warning: { bg: '#FFF6DF', color: '#B8860B', border: '#FCE4A6' },
    danger: { bg: '#FCEAE8', color: '#C0362C', border: '#F5B8B3' },
    info: { bg: '#E8F0FA', color: '#2E6FB8', border: '#B4D2F5' },
    neutral: { bg: '#EEF1F5', color: '#5B6B82', border: '#DCE4EE' },
  };

  const current = styles[resolvedVariant];

  return (
    <span
      style={{
        backgroundColor: current.bg,
        color: current.color,
        border: `1px solid ${current.border}`,
        borderRadius: '9999px',
        padding: size === 'sm' ? '2px 8px' : '4px 12px',
        fontSize: size === 'sm' ? '11px' : '12px',
        fontWeight: 600,
        display: 'inline-flex',
        alignItems: 'center',
        gap: '4px',
        whiteSpace: 'nowrap',
      }}
    >
      <span
        style={{
          width: '6px',
          height: '6px',
          borderRadius: '50%',
          backgroundColor: current.color,
        }}
      />
      {label}
    </span>
  );
};
