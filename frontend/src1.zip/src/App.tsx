import React, { useState, useEffect } from 'react';
import {
  UserSession,
  Customer,
  LoanAccount,
  Collateral,
  LoanCollateralLink,
  InsurancePolicy,
  PolicyEndorsement,
  OwnershipDocument,
  CimsException,
  NotificationItem,
  AuditLog,
  WorkflowTask,
  Delegation,
  BusinessSegment,
  Branch,
  RolePermission,
  ApprovalHierarchyConfig,
  ReminderSchedule,
  ScheduledReport,
  ApprovedInsurer,
  CollateralTaxonomy,
  MandatoryDocumentRule,
  HolidayCalendar,
  SystemParameter,
  CbsCustomer,
  CbsFacility,
  CbsCollateral,
  CbsSyncLog,
  RoleCode,
} from './types';
import { cimsApi } from './api/cimsApi';
import { TopBar } from './components/layout/TopBar';
import { Sidebar, NavPageId } from './components/layout/Sidebar';
import { Breadcrumbs } from './components/layout/Breadcrumbs';
import { NotificationCenter } from './components/layout/NotificationCenter';
import { SessionTimeoutModal } from './components/layout/SessionTimeoutModal';
import { ChangePasswordModal } from './components/layout/ChangePasswordModal';
import { LoginScreen } from './components/auth/LoginScreen';
import { DashboardContainer } from './components/dashboards/DashboardContainer';
import { CustomerManager } from './components/customers/CustomerManager';
import { FacilityManager } from './components/facilities/FacilityManager';
import { CollateralManager } from './components/collateral/CollateralManager';
import { PolicyManager } from './components/policies/PolicyManager';
import { MakerCheckerInbox } from './components/workflow/MakerCheckerInbox';
import { ExceptionManager } from './components/exceptions/ExceptionManager';
import { DocumentRepository } from './components/documents/DocumentRepository';
import { ReportCatalog } from './components/reports/ReportCatalog';
import { AdminPortal } from './components/admin/AdminPortal';
import { AuditTrailViewer } from './components/audit/AuditTrailViewer';
import { NotificationManager } from './components/notifications/NotificationManager';
import { CbsSimulator } from './components/cbs/CbsSimulator';

// 16 Pre-Seeded Bank Personas
const INITIAL_PERSONAS: UserSession[] = [
  {
    userId: 'brmgr_user',
    username: 'brmgr_user',
    name: 'Abebe Bikila',
    role: 'BRMGR',
    roleName: 'Branch Manager',
    branch: 'Bole Special Branch',
    branchCode: 'BOLE-001',
    segment: 'Corporate Banking',
    segmentIds: ['Corporate Banking', 'Retail Banking', 'MSME Banking'],
    token: 'jwt-token-brmgr',
    canApprove: true,
    canCreate: true,
    canEdit: true,
    canDelete: false,
  },
  {
    userId: 'cro_user',
    username: 'cro_user',
    name: 'Derartu Tulu',
    role: 'CRO',
    roleName: 'Corporate Relationship Officer',
    branch: 'Bole Special Branch',
    branchCode: 'BOLE-001',
    segment: 'Corporate Banking',
    segmentIds: ['Corporate Banking'],
    token: 'jwt-token-cro',
    canApprove: false,
    canCreate: true,
    canEdit: true,
    canDelete: false,
  },
  {
    userId: 'exec_user',
    username: 'exec_user',
    name: 'Dr. Haile Gebrselassie',
    role: 'EXEC',
    roleName: 'Executive Director / VP',
    branch: 'Head Office',
    branchCode: 'HQ-001',
    segment: 'Corporate Banking',
    segmentIds: ['Corporate Banking', 'Retail Banking', 'MSME Banking', 'Interest-Free Banking (IFB)'],
    token: 'jwt-token-exec',
    canApprove: true,
    canCreate: false,
    canEdit: false,
    canDelete: false,
  },
  {
    userId: 'distdir_user',
    username: 'distdir_user',
    name: 'Kenenisa Bekele',
    role: 'DISTDIR',
    roleName: 'District Director',
    branch: 'East Addis District',
    branchCode: 'DIST-EAA-01',
    segment: 'Corporate Banking',
    segmentIds: ['Corporate Banking', 'Retail Banking', 'MSME Banking'],
    token: 'jwt-token-distdir',
    canApprove: true,
    canCreate: true,
    canEdit: true,
    canDelete: false,
  },
  {
    userId: 'hodept_user',
    username: 'hodept_user',
    name: 'Tirunesh Dibaba',
    role: 'HODEPT',
    roleName: 'Head Office Department Head',
    branch: 'Head Office',
    branchCode: 'HQ-001',
    segment: 'Corporate Banking',
    segmentIds: ['Corporate Banking', 'Retail Banking', 'MSME Banking', 'Interest-Free Banking (IFB)'],
    token: 'jwt-token-hodept',
    canApprove: true,
    canCreate: true,
    canEdit: true,
    canDelete: false,
  },
  {
    userId: 'srm_user',
    username: 'srm_user',
    name: 'Sileshi Sihine',
    role: 'SRM',
    roleName: 'Senior Relationship Manager',
    branch: 'Bole Special Branch',
    branchCode: 'BOLE-001',
    segment: 'Corporate Banking',
    segmentIds: ['Corporate Banking'],
    token: 'jwt-token-srm',
    canApprove: true,
    canCreate: true,
    canEdit: true,
    canDelete: false,
  },
  {
    userId: 'brm_user',
    username: 'brm_user',
    name: 'Meseret Defar',
    role: 'BRM',
    roleName: 'Branch Relationship Manager',
    branch: 'Bole Special Branch',
    branchCode: 'BOLE-001',
    segment: 'Retail Banking',
    segmentIds: ['Retail Banking'],
    token: 'jwt-token-brm',
    canApprove: true,
    canCreate: true,
    canEdit: true,
    canDelete: false,
  },
  {
    userId: 'bro_user',
    username: 'bro_user',
    name: 'Gete Wami',
    role: 'BRO',
    roleName: 'Branch Relationship Officer',
    branch: 'Bole Special Branch',
    branchCode: 'BOLE-001',
    segment: 'Retail Banking',
    segmentIds: ['Retail Banking'],
    token: 'jwt-token-bro',
    canApprove: false,
    canCreate: true,
    canEdit: true,
    canDelete: false,
  },
  {
    userId: 'mgrcolldoc_user',
    username: 'mgrcolldoc_user',
    name: 'Fatuma Roba',
    role: 'MGRCOLLDOC',
    roleName: 'Manager Collateral & Documentation',
    branch: 'Head Office',
    branchCode: 'HQ-001',
    segment: 'Corporate Banking',
    segmentIds: ['Corporate Banking', 'Retail Banking', 'MSME Banking', 'Interest-Free Banking (IFB)'],
    token: 'jwt-token-mgrcolldoc',
    canApprove: true,
    canCreate: true,
    canEdit: true,
    canDelete: false,
  },
  {
    userId: 'colldocoff_user',
    username: 'colldocoff_user',
    name: 'Gezahegne Abera',
    role: 'COLLDOCOFF',
    roleName: 'Collateral & Documentation Officer',
    branch: 'Head Office',
    branchCode: 'HQ-001',
    segment: 'Corporate Banking',
    segmentIds: ['Corporate Banking', 'Retail Banking', 'MSME Banking'],
    token: 'jwt-token-colldocoff',
    canApprove: false,
    canCreate: true,
    canEdit: true,
    canDelete: false,
  },
  {
    userId: 'compliance_user',
    username: 'compliance_user',
    name: 'Almaz Ayana',
    role: 'COMPLIANCE',
    roleName: 'Compliance Officer',
    branch: 'Head Office',
    branchCode: 'HQ-001',
    segment: 'Corporate Banking',
    segmentIds: ['Corporate Banking', 'Retail Banking', 'MSME Banking', 'Interest-Free Banking (IFB)'],
    token: 'jwt-token-compliance',
    canApprove: true,
    canCreate: false,
    canEdit: false,
    canDelete: false,
  },
  {
    userId: 'risk_user',
    username: 'risk_user',
    name: 'Lelisa Desisa',
    role: 'RISK',
    roleName: 'Risk Management Officer',
    branch: 'Head Office',
    branchCode: 'HQ-001',
    segment: 'Corporate Banking',
    segmentIds: ['Corporate Banking', 'Retail Banking', 'MSME Banking', 'Interest-Free Banking (IFB)'],
    token: 'jwt-token-risk',
    canApprove: false,
    canCreate: false,
    canEdit: false,
    canDelete: false,
  },
  {
    userId: 'auditor_user',
    username: 'auditor_user',
    name: 'Tsegaye Kebede',
    role: 'AUDITOR',
    roleName: 'Internal Auditor',
    branch: 'Head Office',
    branchCode: 'HQ-001',
    segment: 'Corporate Banking',
    segmentIds: ['Corporate Banking', 'Retail Banking', 'MSME Banking', 'Interest-Free Banking (IFB)'],
    token: 'jwt-token-auditor',
    canApprove: false,
    canCreate: false,
    canEdit: false,
    canDelete: false,
  },
  {
    userId: 'sysadmin_user',
    username: 'sysadmin_user',
    name: 'System Administrator',
    role: 'SYSADMIN',
    roleName: 'System Administrator',
    branch: 'Head Office',
    branchCode: 'HQ-001',
    segment: 'Corporate Banking',
    segmentIds: ['Corporate Banking', 'Retail Banking', 'MSME Banking', 'Interest-Free Banking (IFB)'],
    token: 'jwt-token-sysadmin',
    canApprove: true,
    canCreate: true,
    canEdit: true,
    canDelete: true,
  },
  {
    userId: 'srmgmt_user',
    username: 'srmgmt_user',
    name: 'Senior Management Lead',
    role: 'SRMGMT',
    roleName: 'Senior Management',
    branch: 'Head Office',
    branchCode: 'HQ-001',
    segment: 'Corporate Banking',
    segmentIds: ['Corporate Banking', 'Retail Banking', 'MSME Banking', 'Interest-Free Banking (IFB)'],
    token: 'jwt-token-srmgmt',
    canApprove: true,
    canCreate: false,
    canEdit: false,
    canDelete: false,
  },
  {
    userId: 'rdonly_user',
    username: 'rdonly_user',
    name: 'Read Only Viewer',
    role: 'RDONLY',
    roleName: 'Read Only Inspector',
    branch: 'Head Office',
    branchCode: 'HQ-001',
    segment: 'Corporate Banking',
    segmentIds: ['Corporate Banking'],
    token: 'jwt-token-rdonly',
    canApprove: false,
    canCreate: false,
    canEdit: false,
    canDelete: false,
  },
];

export function App() {
  const [currentUser, setCurrentUser] = useState<UserSession | null>(INITIAL_PERSONAS[0]);
  const [activePage, setActivePage] = useState<NavPageId>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [selectedSegment, setSelectedSegment] = useState('Corporate Banking');

  // Modals & Drawers
  const [showNotifications, setShowNotifications] = useState(false);
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [showSessionTimeout, setShowSessionTimeout] = useState(false);

  // Application Data States
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [facilities, setFacilities] = useState<LoanAccount[]>([]);
  const [collaterals, setCollaterals] = useState<Collateral[]>([]);
  const [links, setLinks] = useState<LoanCollateralLink[]>([]);
  const [policies, setPolicies] = useState<InsurancePolicy[]>([]);
  const [endorsements, setEndorsements] = useState<PolicyEndorsement[]>([]);
  const [documents, setDocuments] = useState<OwnershipDocument[]>([]);
  const [exceptions, setExceptions] = useState<CimsException[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [workflowTasks, setWorkflowTasks] = useState<WorkflowTask[]>([]);
  const [delegations, setDelegations] = useState<Delegation[]>([]);
  const [segments, setSegments] = useState<BusinessSegment[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [permissions, setPermissions] = useState<RolePermission[]>([]);
  const [approvalConfigs, setApprovalConfigs] = useState<ApprovalHierarchyConfig[]>([]);
  const [reminderSchedules, setReminderSchedules] = useState<ReminderSchedule[]>([]);
  const [scheduledReports, setScheduledReports] = useState<ScheduledReport[]>([]);
  const [insurers, setInsurers] = useState<ApprovedInsurer[]>([]);
  const [taxonomies, setTaxonomies] = useState<CollateralTaxonomy[]>([]);
  const [mandatoryDocRules, setMandatoryDocRules] = useState<MandatoryDocumentRule[]>([]);
  const [holidayCalendars, setHolidayCalendars] = useState<HolidayCalendar[]>([]);
  const [systemParameters, setSystemParameters] = useState<SystemParameter[]>([]);
  const [cbsCustomers, setCbsCustomers] = useState<CbsCustomer[]>([]);
  const [cbsFacilities, setCbsFacilities] = useState<CbsFacility[]>([]);
  const [cbsCollaterals, setCbsCollaterals] = useState<CbsCollateral[]>([]);
  const [cbsSyncLogs, setCbsSyncLogs] = useState<CbsSyncLog[]>([]);

  // Fetch initial data
  const loadData = async () => {
    try {
      const [
        custRes,
        facRes,
        colRes,
        linkRes,
        polRes,
        endRes,
        docRes,
        excRes,
        notifRes,
        auditRes,
        taskRes,
        delRes,
        segRes,
        brRes,
        permRes,
        apprRes,
        remRes,
        schedRes,
        insRes,
        taxRes,
        mandRes,
        holRes,
        paramRes,
        cbsCustRes,
        cbsFacRes,
        cbsColRes,
        cbsLogRes,
      ] = await Promise.all([
        cimsApi.getCustomers(),
        cimsApi.getFacilities(),
        cimsApi.getCollaterals(),
        cimsApi.getLinks(),
        cimsApi.getPolicies(),
        cimsApi.getEndorsements(),
        cimsApi.getDocuments(),
        cimsApi.getExceptions(),
        cimsApi.getNotifications(),
        cimsApi.getAuditLogs(),
        cimsApi.getWorkflowTasks(),
        cimsApi.getDelegations(),
        cimsApi.getSegments(),
        cimsApi.getBranches(),
        cimsApi.getPermissions(),
        cimsApi.getApprovalConfigs(),
        cimsApi.getReminderSchedules(),
        cimsApi.getScheduledReports(),
        cimsApi.getApprovedInsurers(),
        cimsApi.getTaxonomies(),
        cimsApi.getMandatoryDocRules(),
        cimsApi.getHolidayCalendars(),
        cimsApi.getSystemParameters(),
        cimsApi.getCbsCustomers(),
        cimsApi.getCbsFacilities(),
        cimsApi.getCbsCollaterals(),
        cimsApi.getCbsSyncLogs(),
      ]);

      setCustomers(custRes);
      setFacilities(facRes);
      setCollaterals(colRes);
      setLinks(linkRes);
      setPolicies(polRes);
      setEndorsements(endRes);
      setDocuments(docRes);
      setExceptions(excRes);
      setNotifications(notifRes);
      setAuditLogs(auditRes);
      setWorkflowTasks(taskRes);
      setDelegations(delRes);
      setSegments(segRes);
      setBranches(brRes);
      setPermissions(permRes);
      setApprovalConfigs(apprRes);
      setReminderSchedules(remRes);
      setScheduledReports(schedRes);
      setInsurers(insRes);
      setTaxonomies(taxRes);
      setMandatoryDocRules(mandRes);
      setHolidayCalendars(holRes);
      setSystemParameters(paramRes);
      setCbsCustomers(cbsCustRes);
      setCbsFacilities(cbsFacRes);
      setCbsCollaterals(cbsColRes);
      setCbsSyncLogs(cbsLogRes);
    } catch (err) {
      console.warn('Backend API communication error. Using localized fallback data.');
    }
  };

  useEffect(() => {
    loadData();
  }, [currentUser]);

  // Auth Handlers
  const handleLogin = async (user: string, pass: string) => {
    const matched = INITIAL_PERSONAS.find((p) => p.username === user || p.userId === user);
    if (matched) {
      setCurrentUser(matched);
      return true;
    }
    return false;
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  // CBS Simulator Handlers
  const handleSyncEntity = async (type: string, id: string) => {
    await cimsApi.syncCbsEntity(type, id);
    await loadData();
  };

  const handleSyncAll = async () => {
    await cimsApi.syncAllPending();
    await loadData();
  };

  const handleSaveCbsCustomer = async (cust: Partial<CbsCustomer>) => {
    await cimsApi.saveCbsCustomer(cust);
    await loadData();
  };

  const handleSaveCbsFacility = async (fac: Partial<CbsFacility>) => {
    await cimsApi.saveCbsFacility(fac);
    await loadData();
  };

  const handleSaveCbsCollateral = async (col: Partial<CbsCollateral>) => {
    await cimsApi.saveCbsCollateral(col);
    await loadData();
  };

  // Business Handlers
  const handleRegisterManualCustomer = async (cust: Partial<Customer>) => {
    await cimsApi.registerCustomer(cust);
    await loadData();
  };

  const handleRegisterCollateral = async (col: Partial<Collateral>) => {
    await cimsApi.createCollateral(col);
    await loadData();
  };

  const handleAddLink = async (loanId: string, collateralId: string, amount: number) => {
    await cimsApi.addFacilityLink(loanId, collateralId, amount);
    await loadData();
  };

  const handleRemoveLink = async (linkId: string) => {
    await cimsApi.removeFacilityLink(linkId);
    await loadData();
  };

  const handleValidateRelease = async (collateralId: string) => {
    return await cimsApi.validateReleaseCollateral(collateralId);
  };

  const handleInitiateTransfer = async (collateralId: string, destSeg: string, reason: string) => {
    await cimsApi.transferCollateralSegment(collateralId, destSeg, reason);
    await loadData();
  };

  const handleCreatePolicyDraft = async (pol: Partial<InsurancePolicy>) => {
    await cimsApi.createPolicyDraft(pol, currentUser?.username || 'CRO_USER');
    await loadData();
  };

  const handleSubmitPolicy = async (policyId: string) => {
    await cimsApi.submitPolicy(policyId, currentUser?.username || 'CRO_USER');
    await loadData();
  };

  const handleAmendPolicy = async (policyId: string, pol: Partial<InsurancePolicy>) => {
    await cimsApi.amendPolicy(policyId, pol, currentUser?.username || 'CRO_USER');
    await loadData();
  };

  const handleRenewPolicy = async (policyId: string, amt: number, prem: number, exp: string) => {
    await cimsApi.renewPolicy(policyId, amt, prem, exp, currentUser?.username || 'CRO_USER');
    await loadData();
  };

  const handleApproveTask = async (taskId: string, comments: string) => {
    await cimsApi.approveWorkflowTask(taskId, comments, currentUser?.username || 'BRMGR_USER', currentUser?.role || 'BRMGR');
    await loadData();
  };

  const handleRejectTask = async (taskId: string, comments: string) => {
    await cimsApi.rejectWorkflowTask(taskId, comments, currentUser?.username || 'BRMGR_USER', currentUser?.role || 'BRMGR');
    await loadData();
  };

  const handleReturnTask = async (taskId: string, note: string) => {
    await cimsApi.returnWorkflowTask(taskId, note, currentUser?.username || 'BRMGR_USER', currentUser?.role || 'BRMGR');
    await loadData();
  };

  const handleBulkApprove = async (taskIds: string[], comments: string) => {
    await cimsApi.bulkApproveWorkflowTasks(taskIds, comments, currentUser?.username || 'BRMGR_USER', currentUser?.role || 'BRMGR');
    await loadData();
  };

  const handleCreateDelegation = async (del: Partial<Delegation>) => {
    await cimsApi.createDelegation(del);
    await loadData();
  };

  const handleRevokeDelegation = async (id: string) => {
    await cimsApi.revokeDelegation(id);
    await loadData();
  };

  const handleResolveException = async (id: string, action: string, notes: string) => {
    await cimsApi.resolveException(id, action, notes);
    await loadData();
  };

  const handleEscalateException = async (id: string, role: string) => {
    await cimsApi.escalateException(id, role);
    await loadData();
  };

  const handleScanExceptions = async () => {
    await cimsApi.triggerPortfolioScan();
    await loadData();
  };

  const handleUploadDocument = async (entityType: string, entityId: string, name: string, type: string, expiry?: string) => {
    await cimsApi.uploadDocument(entityType, entityId, name, type, expiry);
    await loadData();
  };

  const handleSaveScheduledReport = async (report: Partial<ScheduledReport>) => {
    await cimsApi.saveScheduledReport(report);
    await loadData();
  };

  const handleSaveSegment = async (seg: Partial<BusinessSegment>) => {
    await cimsApi.saveSegment(seg);
    await loadData();
  };

  const handleToggleSegmentStatus = async (id: string, active: boolean) => {
    await cimsApi.toggleSegmentStatus(id, active);
    await loadData();
  };

  const handleSavePermissionsBatch = async (perms: RolePermission[]) => {
    await cimsApi.saveRolePermissionsBatch(perms);
    await loadData();
  };

  const handleSaveUser = async (user: any) => {
    await cimsApi.saveUser(user);
    await loadData();
  };

  const handleToggleUserStatus = async (userId: string, active: boolean) => {
    await cimsApi.toggleUserStatus(userId, active);
    await loadData();
  };

  const handleSaveBranch = async (branch: Partial<Branch>) => {
    await cimsApi.saveBranch(branch);
    await loadData();
  };

  const handleSaveApprovalConfig = async (cfg: Partial<ApprovalHierarchyConfig>) => {
    await cimsApi.saveApprovalConfig(cfg);
    await loadData();
  };

  const handleSaveReminderSchedule = async (sched: Partial<ReminderSchedule>) => {
    await cimsApi.saveReminderSchedule(sched);
    await loadData();
  };

  const handleSaveParameter = async (param: Partial<SystemParameter>) => {
    await cimsApi.saveSystemParameter(param);
    await loadData();
  };

  const handleSaveInsurer = async (ins: Partial<ApprovedInsurer>) => {
    await cimsApi.saveApprovedInsurer(ins);
    await loadData();
  };

  const handleSaveTaxonomy = async (tax: Partial<CollateralTaxonomy>) => {
    await cimsApi.saveCollateralTaxonomy(tax);
    await loadData();
  };

  const handleSaveMandatoryDocRule = async (rule: Partial<MandatoryDocumentRule>) => {
    await cimsApi.saveMandatoryDocRule(rule);
    await loadData();
  };

  const handleSaveHoliday = async (holiday: Partial<HolidayCalendar>) => {
    await cimsApi.saveHolidayCalendar(holiday);
    await loadData();
  };

  // If not logged in, render Login screen
  if (!currentUser) {
    return (
      <LoginScreen
        onLogin={handleLogin}
        onSelectPersona={(persona) => setCurrentUser(persona)}
        availablePersonas={INITIAL_PERSONAS}
      />
    );
  }

  const unreadNotifs = notifications.filter((n) => n.status !== 'Sent').length;
  const pendingApprovals = workflowTasks.filter((t) => t.status === 'Pending').length;
  const openExceptions = exceptions.filter((e) => e.status !== 'Resolved').length;

  return (
    <div className="min-h-screen bg-brand-50 flex flex-col font-sans text-text-primary">
      {/* TopBar */}
      <TopBar
        currentUser={currentUser}
        allUsers={INITIAL_PERSONAS}
        onSwitchUser={(user) => {
          setCurrentUser(user);
          setSelectedSegment(user.segment || 'Corporate Banking');
        }}
        selectedSegment={selectedSegment}
        onSelectSegment={setSelectedSegment}
        availableSegments={currentUser.segmentIds || ['Corporate Banking']}
        unreadNotificationCount={unreadNotifs}
        pendingApprovalCount={pendingApprovals}
        onOpenNotifications={() => setShowNotifications(true)}
        onOpenApprovals={() => setActivePage('approvals')}
        onChangePassword={() => setShowChangePassword(true)}
        onDelegateAuthority={() => setActivePage('approvals')}
        onLogout={handleLogout}
      />

      {/* Main Workspace Layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          activePage={activePage}
          onNavigate={(page) => setActivePage(page)}
          userRole={currentUser.role}
          pendingApprovalCount={pendingApprovals}
          openExceptionCount={openExceptions}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        />

        {/* Content Area */}
        <main className="flex-1 flex flex-col overflow-y-auto bg-brand-50">
          <Breadcrumbs activePage={activePage} onNavigateHome={() => setActivePage('dashboard')} />

          {/* Page Routing */}
          <div className="flex-1">
            {activePage === 'dashboard' && (
              <DashboardContainer
                currentUser={currentUser}
                customers={customers}
                facilities={facilities}
                collaterals={collaterals}
                policies={policies}
                exceptions={exceptions}
                workflowTasks={workflowTasks}
                onNavigate={(page) => setActivePage(page)}
                onApproveTask={handleApproveTask}
                onRejectTask={handleRejectTask}
              />
            )}

            {activePage === 'customers' && (
              <CustomerManager
                customers={customers}
                facilities={facilities}
                collaterals={collaterals}
                policies={policies}
                documents={documents}
                currentUser={currentUser}
                onRegisterManualCustomer={handleRegisterManualCustomer}
              />
            )}

            {activePage === 'facilities' && (
              <FacilityManager
                facilities={facilities}
                customers={customers}
                collaterals={collaterals}
                links={links}
                policies={policies}
              />
            )}

            {activePage === 'collateral' && (
              <CollateralManager
                collaterals={collaterals}
                facilities={facilities}
                links={links}
                policies={policies}
                documents={documents}
                exceptions={exceptions}
                currentUser={currentUser}
                onRegisterCollateral={handleRegisterCollateral}
                onAddLink={handleAddLink}
                onRemoveLink={handleRemoveLink}
                onValidateRelease={handleValidateRelease}
                onInitiateTransfer={handleInitiateTransfer}
              />
            )}

            {activePage === 'insurance' && (
              <PolicyManager
                policies={policies}
                endorsements={endorsements}
                collaterals={collaterals}
                customers={customers}
                insurers={insurers}
                documents={documents}
                currentUser={currentUser}
                onCreatePolicyDraft={handleCreatePolicyDraft}
                onSubmitPolicy={handleSubmitPolicy}
                onAmendPolicy={handleAmendPolicy}
                onRenewPolicy={handleRenewPolicy}
              />
            )}

            {activePage === 'approvals' && (
              <MakerCheckerInbox
                tasks={workflowTasks}
                delegations={delegations}
                allUsers={INITIAL_PERSONAS}
                currentUser={currentUser}
                onApproveTask={handleApproveTask}
                onRejectTask={handleRejectTask}
                onReturnTask={handleReturnTask}
                onBulkApprove={handleBulkApprove}
                onCreateDelegation={handleCreateDelegation}
                onRevokeDelegation={handleRevokeDelegation}
              />
            )}

            {activePage === 'exceptions' && (
              <ExceptionManager
                exceptions={exceptions}
                currentUser={currentUser}
                onResolveException={handleResolveException}
                onEscalateException={handleEscalateException}
                onScanNow={handleScanExceptions}
              />
            )}

            {activePage === 'documents' && (
              <DocumentRepository
                documents={documents}
                collaterals={collaterals}
                currentUser={currentUser}
                onUploadDocument={handleUploadDocument}
              />
            )}

            {activePage === 'reports' && (
              <ReportCatalog
                customers={customers}
                facilities={facilities}
                collaterals={collaterals}
                policies={policies}
                exceptions={exceptions}
                auditLogs={auditLogs}
                scheduledReports={scheduledReports}
                currentUser={currentUser}
                onSaveScheduledReport={handleSaveScheduledReport}
              />
            )}

            {activePage === 'admin' && (
              <AdminPortal
                segments={segments}
                branches={branches}
                permissions={permissions}
                approvalConfigs={approvalConfigs}
                reminderSchedules={reminderSchedules}
                scheduledReports={scheduledReports}
                insurers={insurers}
                taxonomies={taxonomies}
                mandatoryDocRules={mandatoryDocRules}
                holidayCalendars={holidayCalendars}
                systemParameters={systemParameters}
                allUsers={INITIAL_PERSONAS}
                currentUser={currentUser}
                onSaveSegment={handleSaveSegment}
                onToggleSegmentStatus={handleToggleSegmentStatus}
                onSavePermissionsBatch={handleSavePermissionsBatch}
                onSaveUser={handleSaveUser}
                onToggleUserStatus={handleToggleUserStatus}
                onSaveBranch={handleSaveBranch}
                onSaveApprovalConfig={handleSaveApprovalConfig}
                onSaveReminderSchedule={handleSaveReminderSchedule}
                onSaveParameter={handleSaveParameter}
                onSaveInsurer={handleSaveInsurer}
                onSaveTaxonomy={handleSaveTaxonomy}
                onSaveMandatoryDocRule={handleSaveMandatoryDocRule}
                onSaveHoliday={handleSaveHoliday}
              />
            )}

            {activePage === 'audit' && (
              <AuditTrailViewer auditLogs={auditLogs} currentUser={currentUser} />
            )}

            {activePage === 'notifications' && (
              <NotificationManager
                notifications={notifications}
                currentUser={currentUser}
                onTriggerScan={handleScanExceptions}
              />
            )}

            {activePage === 'cbs-sim' && (
              <CbsSimulator
                customers={cbsCustomers}
                facilities={cbsFacilities}
                collaterals={cbsCollaterals}
                syncLogs={cbsSyncLogs}
                onSyncEntity={handleSyncEntity}
                onSyncAll={handleSyncAll}
                onSaveCustomer={handleSaveCbsCustomer}
                onSaveFacility={handleSaveCbsFacility}
                onSaveCollateral={handleSaveCbsCollateral}
              />
            )}
          </div>
        </main>
      </div>

      {/* Global Modals */}
      <NotificationCenter
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
        notifications={notifications}
      />

      <ChangePasswordModal
        isOpen={showChangePassword}
        onClose={() => setShowChangePassword(false)}
        onSubmit={async () => true}
      />

      <SessionTimeoutModal
        isOpen={showSessionTimeout}
        onStayLoggedIn={() => setShowSessionTimeout(false)}
        onLogout={handleLogout}
      />
    </div>
  );
}

export default App;

